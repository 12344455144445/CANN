from pathlib import Path
import hashlib,json,difflib
import numpy as np
R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
a=base.index('// Exact round-to-nearest-even division by the odd integer 127')
b=base.index('// Exact fp32 rint',a)
helper=base[a:b]
text=base[:a]+base[b:]
pos=text.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
text=text[:pos]+helper+text[pos:]
a=text.index('    LocalTensor<float> scaleDivisorLocal = halfBuffer.Get<float>();')
b=text.index('    // [OPT-V45-B1]',a)
vector_scale=text[a:b]
new='''    bool useShortScalarScale = rows <= 4U;
    if (useShortScalarScale) {
        for (uint32_t row = 0; row < rows; ++row) {
            union { float value; uint32_t bits; } maximum;
            maximum.value = rowMaxLocal.GetValue(row);
            // Zero uses the existing override; all nonzero divisors remain normal.
            const uint32_t absolute = maximum.bits & 0x7fffffffU;
            if (absolute != 0U && (absolute < 0x04000000U || absolute >= 0x7f800000U)) {
                useShortScalarScale = false;
                break;
            }
        }
    }
    if (useShortScalarScale) {
        for (uint32_t row = 0; row < rows; ++row) {
            const float maximum = rowMaxLocal.GetValue(row);
            rowScaleLocal.SetValue(row, maximum > 0.0f ? QmqScaleBy127Exact(maximum) : 1.0f);
        }
        PipeBarrier<PIPE_ALL>();
    } else {
'''+''.join('    '+line for line in vector_scale.splitlines(True))+'''    }
'''
text=text[:a]+new+text[b:]
# Preserve the existing exact helper; only move its definition to precede use.
assert text.count(helper)==1
assert text.replace(new,vector_scale).replace(helper,'')==base.replace(helper,'')
# Independently compare the helper's integer construction with correctly rounded FP32 division.
rng=np.random.default_rng(1091012)
bits=np.concatenate([rng.integers(0x04000000,0x7f800000,1000000,dtype=np.uint32),
    np.array([0,0x04000000,0x04000001,0x7f7fffff],np.uint32),
    np.concatenate([np.arange((e<<23)+0x7e0000-4,(e<<23)+0x7e0000+5,dtype=np.uint32) for e in range(8,254)])])
e=(bits>>23)&255;m=(bits&0x7fffff)|np.where(e==0,0,0x800000).astype(np.uint32)
high=m>=16646144
shift=np.where(e<=7,np.where(e==0,0,e-1),np.where(high,6,7)).astype(np.uint64)
numerator=m.astype(np.uint64)<<shift
q=numerator//127;q+=(numerator-q*127)*2>127
out_e=np.where(e<=7,0,e-np.where(high,6,7)).astype(np.uint64)
carry=(out_e!=0)&(q==0x1000000);q=np.where(carry,q>>1,q);out_e+=carry
actual=np.where(out_e==0,q,(out_e<<23)|(q&0x7fffff)).astype(np.uint32)
expected=(bits.view(np.float32)/np.float32(127)).view(np.uint32)
assert np.array_equal(actual,expected)
nonzero=bits!=0;assert np.all(actual[nonzero]>=0x800000)
folder=R/'v109_short_scalar_scale_20261012';folder.mkdir(exist_ok=True)
assert not (folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code','change':'For <=4 local rows with safe normal final scales, reuse existing exact integer /127 helper instead of vector correction setup',
 'bounds_guard':'Zero or maximum bits in [0x04000000,0x7f800000); otherwise original vector scale algorithm',
 'CPU_exact_scale_values':len(bits),'scope_inverse_proof':True,'precision_helpers_unchanged':True,
 'extra_UB_bytes':0,'new_vs_v70':'Only short scale calculation changes; retains original two-pass dequant/quantization and division fallback',
 'device':'PENDING: guard avoids subnormal vector/scalar differences but compiler and NPU correctness still require verification'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('只优化本AIV分区<=4行的除127尺度计算，重用tiny已用的整数精确算法；最终scale非normal的最大值回退原Vector算法。15/15零错误并多点加速后原样复测，不能把CPU逐位验证当NPU证明。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
