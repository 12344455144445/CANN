﻿param([Parameter(Mandatory=$true)][string]$CandidateFolder)
$ErrorActionPreference = 'Stop'
$candidatePath = Join-Path $CandidateFolder 'kernel.asc'
if (-not (Test-Path -LiteralPath $candidatePath)) { throw 'Candidate source missing' }
if ((Test-Path -LiteralPath (Join-Path $CandidateFolder 'submission_info.json')) -or (Test-Path -LiteralPath (Join-Path $CandidateFolder 'submission_attempt.json'))) {
    throw 'Candidate already has a submission record; create a new repeat folder to preserve evidence'
}
python -X utf8 '.\work\round5_check_budget.py' $CandidateFolder
if ($LASTEXITCODE -ne 0) { throw 'Candidate review or daily budget check failed' }
$lastOwnSubmission = $null
foreach($infoPath in (Get-ChildItem -LiteralPath '.\work' -Directory | ForEach-Object {Join-Path $_.FullName 'submission_info.json'})) {
    if (-not (Test-Path -LiteralPath $infoPath)) { continue }
    $entry = Get-Content -LiteralPath $infoPath -Raw -Encoding utf8 | ConvertFrom-Json
    if (-not $entry.captured_at) { continue }
    $stamp = [DateTime]::ParseExact($entry.captured_at, 'yyyy-MM-dd HH:mm:ss', [Globalization.CultureInfo]::InvariantCulture)
    if ($null -eq $lastOwnSubmission -or $stamp -gt $lastOwnSubmission) { $lastOwnSubmission = $stamp }
}
if ($null -ne $lastOwnSubmission) {
    $remaining = [Math]::Ceiling(($lastOwnSubmission.AddMinutes(3) - (Get-Date)).TotalSeconds)
    while ($remaining -gt 0) {
        Write-Output "Keeping submission spacing: $remaining seconds remaining"
        Start-Sleep -Seconds ([Math]::Min(30, $remaining))
        $remaining = [Math]::Ceiling(($lastOwnSubmission.AddMinutes(3) - (Get-Date)).TotalSeconds)
    }
}
Add-Type -AssemblyName UIAutomationClient
$win = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]5705316)
if ($win.Current.Name -notlike '*Microsoft*Edge*') { throw 'Target is not the confirmed Edge browser' }
python '.\work\round5_ui_browser.py' navigate 'https://cannjudge.cn/public/op_challenge_hangxia_prelim/quantmatmulreluquant/submit'
if ($LASTEXITCODE -ne 0) { throw 'Browser navigation failed' }
$file = $win.FindFirst([System.Windows.Automation.TreeScope]::Descendants,(New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty,'kernel.asc')))
for ($attempt=0; $null -eq $file -and $attempt -lt 10; $attempt++) {
    Start-Sleep -Seconds 1
    $file = $win.FindFirst([System.Windows.Automation.TreeScope]::Descendants,(New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty,'kernel.asc')))
}
if ($null -eq $file) { throw 'Kernel tab not available' }
$file.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
Start-Sleep -Seconds 3
python '.\work\round5_ui_browser.py' click 1300 490
if ($LASTEXITCODE -ne 0) { throw 'Editor focus failed' }
python '.\work\round5_ui_browser.py' copyall
if ($LASTEXITCODE -ne 0) { throw 'Existing source backup failed' }
Get-Clipboard -Raw | Set-Content -LiteralPath (Join-Path $CandidateFolder 'pre_edit_source.asc') -Encoding utf8 -NoNewline
$taskCandidateText = Get-Content -LiteralPath $candidatePath -Raw -Encoding utf8
$taskClipboardReady = $false
for($taskClipboardAttempt=0; $taskClipboardAttempt -lt 5; $taskClipboardAttempt++) {
    try {
        Set-Clipboard -Value $taskCandidateText
        $taskClipboardReady = $true
        break
    } catch {
        if($taskClipboardAttempt -eq 4){throw}
        Start-Sleep -Milliseconds 300
    }
}
if(-not $taskClipboardReady){throw 'Source clipboard preparation failed; no submission sent'}
python '.\work\round5_ui_browser.py' replaceall
if ($LASTEXITCODE -ne 0) { throw 'Source replacement failed' }
python '.\work\round5_ui_browser.py' copyall
if ($LASTEXITCODE -ne 0) { throw 'Source copy failed' }
$expected = (Get-Content -LiteralPath $candidatePath -Raw -Encoding utf8).Replace("`r`n","`n")
$actual = (Get-Clipboard -Raw).Replace("`r`n","`n")
if ($expected -cne $actual) { throw 'Browser source does not match candidate; submission aborted' }
Get-Clipboard -Raw | Set-Content -LiteralPath (Join-Path $CandidateFolder 'web_verified.asc') -Encoding utf8 -NoNewline
$button = $win.FindFirst([System.Windows.Automation.TreeScope]::Descendants,(New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty,'提交代码')))
if ($null -eq $button) { throw 'Submit button missing; no submission sent' }
@{state='submit_invocation_started';started_at=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $CandidateFolder 'submission_attempt.json') -Encoding utf8
$button.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
Start-Sleep -Seconds 2
$address = $win.FindFirst([System.Windows.Automation.TreeScope]::Descendants,(New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty,'地址和搜索栏')))
python -X utf8 '.\work\round5_ui_browser.py' copyurl
if ($LASTEXITCODE -ne 0) { throw 'Submission URL read failed' }
$url = (Get-Clipboard -Raw).Trim()
Write-Output "Verified candidate source. Browser URL: $url"
if ($url -match '/submission/') {
    @{url=$url;captured_at=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $CandidateFolder 'submission_info.json') -Encoding utf8
    @{state='url_captured';url=$url;started_at=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $CandidateFolder 'submission_attempt.json') -Encoding utf8
}
else { throw 'No independent submission URL captured; inspect the visible page before any retry' }

python '.\work\round5_ui_browser.py' snapshot
