from pathlib import Path
import hashlib, json, difflib

root = Path(__file__).resolve().parent
base = (root/'v111_general_odd_cast_20261012/kernel.asc').read_text(encoding='utf-8')
old_alias = '                LocalTensor<float> activationLocal = inputLocal.ReinterpretCast<float>();'
new_alias = '''                // Keep dequantized activations in their original FP32 buffer.
                // The consumed INT32 workspace bank becomes the quotient buffer.
                LocalTensor<float> activationLocal = fp32Local;
                fp32Local = inputLocal.ReinterpretCast<float>();'''
old_copy = '''                DataCopy(activationLocal, fp32Local, pairCount);
                PipeBarrier<PIPE_V>();'''
assert base.count(old_alias) == base.count(old_copy) == 1
text = base.replace(old_alias, new_alias).replace(old_copy, '')
assert text.replace(new_alias, old_alias).replace(
    '                LocalTensor<uint8_t> correctionMaskLocal = correctionMaskBuffer.Get<uint8_t>();\n\n',
    '                LocalTensor<uint8_t> correctionMaskLocal = correctionMaskBuffer.Get<uint8_t>();\n'+old_copy+'\n'
) == base

# Actual live source dependencies: retained activations and quotient occupy
# separate allocations, and scratch never aliases either one.
start = text.index(new_alias)
end = text.index('                workspaceQueue.FreeTensor(inputLocal);', start)
live = text[start:end]
assert 'QmqDiv(fp32Local, activationLocal, divisorLocal, pairCount);' in live
assert 'activationLocal.GetValue(lane)' in live
assert 'Cast(halfLocal, fp32Local, RoundMode::CAST_ODD, pairCount);' in live
assert 'Cast(inputLocal, fp32Local' not in live
assert 'DataCopy(activationLocal' not in live
assert 'LocalTensor<float> residualLocal = reduceBuffer.Get<float>();' in live
assert 'LocalTensor<float> scratchLocal = halfBuffer.Get<float>();' in live

folder = root/'v116_quotient_bank_reuse_20261012'
folder.mkdir(exist_ok=True)
assert not (folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text, encoding='utf-8', newline='\n')
review = {
    'review_pass': True,
    'sha256': hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base': 'v111_general_odd_cast_20261012',
    'only_change': 'Swap activation/quotient storage roles to remove one UB DataCopy and its dependency barrier per output batch.',
    'exact_source_inverse': True,
    'precision_operations_unchanged': True,
    'activation_lifetime': 'Original fp32Buffer retains ReLU activations through all scalar near-half repairs. QmqDiv destination is the consumed INT32 workspace bank reinterpreted as FP32.',
    'disjoint_live_allocations': ['activation=fp32Buffer', 'quotient=current workspaceQueue bank', 'residual=reduceBuffer', 'divisor/floor scratch=halfBuffer', 'mask=correctionMaskBuffer', 'output=outputQueue'],
    'queue_lifetime': 'Next workspace input is already enqueued in the other depth-2 bank. Current bank is not freed until half CAST_ODD completed with the existing PIPE_V barrier and output was copied.',
    'UB_allocations_unchanged': True,
    'round_odd_proof_reused_from_v111': True,
    'device': 'PENDING; offline dependency/source audit cannot validate NPU compiler scheduling or performance.',
}
(folder/'review_checks.json').write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True), text.splitlines(True), fromfile='v111', tofile=folder.name)), encoding='utf-8')
(folder/'SUBMIT.md').write_text('独立从数据流推导：保留原FP32反量化激活；消费完的workspace队列块用作除法结果。消除每包一次UB复制与其依赖屏障，不改变任何计算顺序、精度保护或分配。第二输入仍预取到另一队列块。设备正确性和性能待评测。', encoding='utf-8')
print(json.dumps(review, ensure_ascii=False))
