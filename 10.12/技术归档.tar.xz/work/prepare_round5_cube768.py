from pathlib import Path
import json,hashlib,difflib

root=Path(__file__).resolve().parent
base=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='''    if (n >= 512U) {
        if (tilingApi.SetFixSplit(-1, 512, -1) == -1) {'''
new='''    const int32_t preferredBaseN = n >= 768U ? 768 : 512;
    if (n >= 512U) {
        if (tilingApi.SetFixSplit(-1, preferredBaseN, -1) == -1) {'''
assert base.count(old)==1
text=base.replace(old,new)
old_get='''    AscendC::tiling::TCubeTiling tiling;
    if (tilingApi.GetTiling(tiling) == -1 || tiling.usedCoreNum == 0 ||'''
new_get='''    AscendC::tiling::TCubeTiling tiling;
    int32_t tilingStatus = tilingApi.GetTiling(tiling);
    if (tilingStatus == -1 && preferredBaseN == 768) {
        // Use the tested tile if the API cannot fit the larger base block.
        if (tilingApi.SetFixSplit(-1, 512, -1) == -1) {
            tilingApi.SetFixSplit(-1, -1, -1);
        }
        tilingStatus = tilingApi.GetTiling(tiling);
    }
    if (tilingStatus == -1 || tiling.usedCoreNum == 0 ||'''
assert base.count(old_get)==1
text=text.replace(old_get,new_get)
assert text.replace(new,old).replace(new_get,old_get)==base
for n in range(1,13001):
    preferred=768 if n>=768 else 512
    if n>=512:assert preferred%32==0 and preferred<=((n+31)//32)*32
folder=root/'v122_cube_baseN768_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91_latest_control_20261012','only_change':'Host preferred Cube baseN512 ->768 for N>=768; API failure retries tested512.',
 'exact_source_inverse':True,'all_device_functions_precision_mapping_and_workspace_byte_identical':True,
 'baseN_alignment_range_checks':13000,'N512_to767_unchanged':True,
 'tiling_coherence':'K/L1 schedule and baseM are derived by GetTiling. Preserve singleCoreN==N and all existing core/tail guards. No manual editing of TCubeTiling fields.',
 'hypothesis':'Intermediate N tile reduces loop/header overhead relative512 while avoiding the full1024 jump previously tested; memory/compute balance must be measured.',
 'API_source':'https://www.hiascend.com/document/detail/en/CANNCommunityEdition/910/API/ascendcopapi/docs/en/api/SIMD-API/advanced_api/matrix_compute/Matmul-Tiling/SetFixSplit.md',
 'limitation':'Offline N alignment checks cannot calculate actual L0C/L1 residency or speed. The API validates tiling; device regression remains pending.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('矩阵分块新诊断：N>=768采用中间分块768列，K/L1等配套参数完全由Tiling API生成。API生成失败时重试已验证512。host分行与全部设备函数不变。比较15点，不能因减少块数直接断言提速。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
