from pathlib import Path
import json,hashlib,difflib
R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
general=(R/'v111_general_odd_cast_20261012/kernel.asc').read_text(encoding='utf-8')
proof=json.loads((R/'v111_general_odd_cast_20261012/review_checks.json').read_text(encoding='utf-8'))
old='''    auto quantizedInts=activationLocal.ReinterpretCast<int32_t>();
    Cast(quantizedInts,quantLocal,RoundMode::CAST_RINT,quantCount);
    PipeBarrier<PIPE_V>();
    SetDeqScale(static_cast<half>(1.0f));
    auto halfOutput=quantScratch.ReinterpretCast<half>();
    Cast(halfOutput,quantizedInts,RoundMode::CAST_NONE,quantCount);'''
new='''    // Clipped [0,127] values preserve integer RINT through round-to-odd HALF.
    auto halfOutput=quantScratch.ReinterpretCast<half>();
    Cast(halfOutput,quantLocal,RoundMode::CAST_ODD,quantCount);'''
assert base.count(old)==1 and general.count(old)==1
assert base.index('Mins(quantLocal,quantLocal,127.0f,quantCount);')<base.index(old)
for name,parent in [('v112_tiny_odd_cast_20261012',base),('v113_all_odd_cast_20261012',general)]:
    candidate=parent.replace(old,new)
    assert candidate.replace(new,old)==parent
    folder=R/name;folder.mkdir(exist_ok=True)
    assert not(folder/'submission_attempt.json').exists()
    (folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
    review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
     'base':'v91 latest code' if name.startswith('v112') else 'v111 general ODD (15/15 passed)',
     'change':'Tiny clipped quantized FP32 -> HALF CAST_ODD -> INT8 CAST_RINT',
     'only_tiny_conversion_changed_from_parent':True,'CPU_conversion_values':proof['CPU_conversion_values'],
     'math_proof':proof['proof'],'same_clipped_float_domain_as_general':True,
     'alias':'quantScratch is separate quarter of quantBuffer; no remaining residual/scratch readers after final clipping',
     'UB_allocations_unchanged':True,'API_source':proof['API_source'],
     'device':'PENDING: changing tiny output requires independent NPU correctness/performance verification'}
    (folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'source.diff').write_text(''.join(difflib.unified_diff(parent.splitlines(True),candidate.splitlines(True),fromfile='parent',tofile=name)),encoding='utf-8')
    (folder/'SUBMIT.md').write_text('仅tiny输出转换换成CAST_ODD HALF后RINT INT8。量化FP32先夹紧[0,127]，数学证明与v111一致，tiny计算和近半整数修正未变。v112独立验证tiny，v113组合已通过设备验证的general版本，仍须15/15与收益复测。',encoding='utf-8')
    print(name,review['sha256'])
