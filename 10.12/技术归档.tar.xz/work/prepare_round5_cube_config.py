from pathlib import Path
import hashlib,json,difflib

root=Path(__file__).resolve().parent
base=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='constexpr auto kInt8MatmulConfig = CFG_MDL;'
assert base.count(old)==1
docs='https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0622.html'

variants=[
 ('v118_cube_K_stagger_20261012','QmqKStaggerConfig','enableKdimReorderLoad',
  'Reduce same-address GM loading conflicts among cores reading the identical right matrix; official MDL K-stagger scheduling.',
  'MDL is retained. A/B are GM INT8, C is GM INT32. No FP32 operation or row mapping changes. Recommendation is large K with neither operand fully loaded; performance for other shapes is not assumed.'),
 ('v119_cube_unit_flag_20261012','QmqUnitFlagConfig','enUnitFlag',
  'Allow Cube computation/output transfer overlap using the documented UnitFlag configuration, disabled by default in MDL.',
  'Retain IterateAll, End, and existing PIPE_FIX cross-core notifications. UnitFlag is internal Matmul synchronization; no application flags are deleted or reordered.'),
]
for name,helper,field,hypothesis,constraints in variants:
    new=f'''constexpr auto {helper}()
{{
    auto config = CFG_MDL;
    config.{field} = true;
    return config;
}}
constexpr auto kInt8MatmulConfig = {helper}();'''
    text=base.replace(old,new)
    assert text.replace(new,old)==base
    folder=root/name;folder.mkdir(exist_ok=True)
    assert not(folder/'submission_attempt.json').exists()
    (folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
    review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
      'base':'v91_latest_control_20261012','only_change':'Copy CFG_MDL and enable '+field,
      'exact_source_inverse':True,'Cube_template_changed_function_text_unchanged':True,
      'vector_tiny_host_precision_mapping_application_flags_byte_identical':True,
      'API_source':docs,'API_support':'CANN9.0 official GetMDLConfig documents both options and Atlas A3 support.',
      'hypothesis':hypothesis,'constraints_and_scope':constraints,
      'custom_UB_allocations_unchanged':True,
      'limitations':'No local CANN compiler, actual TCubeTiling/profile, or CPU simulation of the library schedule. Hardware compile, correctness, and timings remain pending.'}
    (folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=name)),encoding='utf-8')
    (folder/'SUBMIT.md').write_text(hypothesis+'\n'+constraints+'\nAPI: '+docs+'\nOne configuration variable; no post-processing or host tiling change.\n',encoding='utf-8')
    print(json.dumps(review,ensure_ascii=False))
