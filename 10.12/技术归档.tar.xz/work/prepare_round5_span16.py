from pathlib import Path
import hashlib,json,difflib

root=Path(__file__).resolve().parent
base=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='    const uint32_t tileFloor = (tileSpan <= 8U)'
new='    const uint32_t tileFloor = (tileSpan <= 16U)'
assert base.count(old)==1
text=base.replace(old,new)
assert text.replace(new,old)==base

def ceildiv(a,b):return (a+b-1)//b

checked=0;changed=0;strictly_more_groups=0
for cores in range(1,129):
    for m in range(1,4097):
        span=ceildiv(m,cores)
        balanced=ceildiv(m,min(m,2*cores))
        original=min(m,max(max(4,span) if span<=8 else 16,balanced))
        candidate=min(m,max(max(4,span) if span<=16 else 16,balanced))
        active=ceildiv(m,candidate)
        blocks=ceildiv(active,cores)
        groups=ceildiv(active,blocks)
        assert candidate>=balanced and active<=min(m,2*cores)
        assert 1<=blocks<=2 and groups<=cores
        if candidate!=original:
            changed+=1
            assert 8<span<16 and blocks==1
            oldactive=ceildiv(m,original)
            oldgroups=ceildiv(oldactive,ceildiv(oldactive,cores))
            assert groups>=oldgroups
            strictly_more_groups+=(groups>oldgroups)
        # Device mapping uses the API-returned blockM on both sides. Here the
        # requested blockM model checks half splits at every tail and odd block.
        full0=(candidate+1)//2
        assert full0+(candidate-full0)==candidate
        tail=m-(active-1)*candidate
        tail0=min(full0,tail)
        tail1=max(0,tail-full0)
        assert tail0+tail1==tail and tail0<=full0
        checked+=1

folder=root/'v117_mediumM_full_groups_20261012'
folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91_latest_control_20261012','only_change':'Host span threshold 8 -> 16; use tileM=ceil(M/usableCoreNum) for medium M instead of fixed floor16.',
 'exact_source_inverse':True,'device_functions_and_precision_byte_identical':True,
 'requested_mapping_configs':checked,'changed_requested_configs':changed,'strictly_more_active_groups_configs':strictly_more_groups,
 'mapping_model':'M=1..4096,U=1..128; row cover, no extra cross-core flags, blocks/group=1 on every changed case, no expansion beyond2U blocks.',
 'motivation':'For 8<ceil(M/U)<16, fixed16 can leave cores idle. Using the span raises active groups without crossing to two serial blocks/group, unlike a fixed floor8.',
 'historical_distinction':'Historical v38 floor8 could cross to two blocks/group and regress. This changes only 8<ceil(M/U)<16 and guarantees one block/group in the requested tiling model.',
 'API_limitation':'Actual TCubeTiling singleCoreM may be rounded. Original runtime guards and both-side mapping remain unchanged; offline requested mapping is not a hardware tiling/profile result.',
 'device':'PENDING; more cores can duplicate B traffic and hurt bandwidth; compare all15 points.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('独立检查host阶梯划分：8<ceil(M/U)<16时采用span而非固定16，让更多核工作，同时保证请求模型仍是一核组一个M块，避免历史固定8触发两块串行。设备函数、精度链、flags与通用原版逐字节一致。API实际返回划分及B读取带宽影响待15点评测。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
