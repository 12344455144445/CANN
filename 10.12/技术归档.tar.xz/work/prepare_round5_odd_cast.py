from pathlib import Path
import hashlib,json,difflib
import numpy as np
R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='''                Cast(inputLocal, fp32Local, RoundMode::CAST_RINT, pairCount);
                PipeBarrier<PIPE_V>();
                SetDeqScale(static_cast<half>(1.0f));
                LocalTensor<half> halfLocal = halfBuffer.Get<half>();
                Cast(halfLocal, inputLocal, RoundMode::CAST_NONE, pairCount);'''
new='''                // Round-to-odd avoids double rounding at integer half ties.
                // All FP32 values have already been clipped to [0,127].
                LocalTensor<half> halfLocal = halfBuffer.Get<half>();
                Cast(halfLocal, fp32Local, RoundMode::CAST_ODD, pairCount);'''
assert base.count(old)==1
text=base.replace(old,new);assert text.replace(new,old)==base

def round_odd_half(values):
    nearest=values.astype(np.float16)
    exact=nearest.astype(np.float32)==values
    bits=nearest.view(np.uint16).copy()
    # Positive truncation, then jam every inexact result's low significand bit.
    bits-=np.asarray(nearest.astype(np.float32)>values,dtype=np.uint16)
    bits=np.where(exact,bits,bits|np.uint16(1)).astype(np.uint16)
    return bits.view(np.float16).astype(np.float32)

def check(values):
    assert np.all((values>=0)&(values<=127))
    actual=np.rint(round_odd_half(values))
    want=np.rint(values)
    bad=np.flatnonzero(actual!=want)
    assert not len(bad),[(float(values[i]),float(actual[i]),float(want[i])) for i in bad[:8]]
    return len(values)

# Every integer rounding threshold is an exact HALF with an even low bit.
# Any inexact round-to-odd result therefore stays strictly on the same side
# of that threshold; an exact threshold stays exact, preserving tie-to-even.
thresholds=np.arange(127,dtype=np.float32)+np.float32(.5)
assert np.all(thresholds.astype(np.float16).astype(np.float32)==thresholds)
assert np.all((thresholds.astype(np.float16).view(np.uint16)&1)==0)
tested=0
for threshold in thresholds:
    bits=np.asarray(threshold).view(np.uint32).item()
    values=np.arange(bits-32768,bits+32769,dtype=np.uint32).view(np.float32)
    tested+=check(values)
# Cover all positive HALF grid boundaries, including subnormals and exact integers.
last=np.asarray(np.float16(127)).view(np.uint16).item()
grid=np.arange(last+1,dtype=np.uint16).view(np.float16).astype(np.float32)
fixtures=np.concatenate([grid,np.nextafter(grid,np.float32(0)),np.nextafter(grid,np.float32(np.inf))])
tested+=check(fixtures[(fixtures>=0)&(fixtures<=127)])
rng=np.random.default_rng(1111012)
tested+=check(rng.integers(0,0x42fe0001,1000000,dtype=np.uint32).view(np.float32))
# The naive RINT-to-HALF shortcut must fail, proving tests detect double rounding.
sample=np.nextafter(np.float32(.5),np.float32(np.inf))
assert np.rint(np.float32(sample.astype(np.float16)))!=np.rint(sample)
folder=R/'v111_general_odd_cast_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code','only_change':'General quantized FP32 [0,127] -> HALF CAST_ODD -> INT8 CAST_RINT, replacing FP32 -> INT32 -> HALF -> INT8 and SetDeqScale',
 'proof':'Every k+0.5 threshold for k=0..126 is an exact HALF with even low significand bit; inexact round-to-odd cannot land on or cross it. Exact thresholds preserve nearest-even decisions',
 'CPU_conversion_values':tested,'naive_half_RINT_negative_control':True,
 'UB_allocations_unchanged':True,'tiny_host_cube_precision_helpers_unchanged':True,
 'API_source':'https://www.hiascend.com/document/detail/en/CANNCommunityEdition/910/API/ascendcopapi/docs/en/api/SIMD-API/basic_api/memory_vector_compute/type_conversion/Cast.md',
 'API_evidence':'Atlas A2 supports float->half CAST_ODD and half->int8 CAST_RINT. Actual installed CANN compile/runtime still pending',
 'device':'PENDING; CPU math model does not execute CAST_ODD instruction or establish NPU precision'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('官方A2 Cast表支持float->half CAST_ODD。对已夹紧[0,127]的量化值，所有k+0.5阈值为half精确可表示且尾数偶；round-to-odd不把非精确值映到阈值，保证后续half RINT与原float RINT相同。普通half RINT存在双舍入，已用负对照检测。精度三函数/近半修正保持不变。15/15零错误并整体改善后原样复测。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
