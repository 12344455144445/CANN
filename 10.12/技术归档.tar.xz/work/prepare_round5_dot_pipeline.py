from pathlib import Path
import json,hashlib,difflib,re
import numpy as np

R=Path(__file__).resolve().parent
source=(R/'v91_latest_control_20261012/kernel.asc').read_text()
start=source.index('__aicore__ inline bool QmqTryTinyDirect(')
end=source.index('__global__ __vector__ void qmq_tiny_vector_entry(',start)
body=source[start:end]
old='''    TPipe pipe;
    const uint32_t kStride=QmqAlignUp(k,32U);'''
new='''    if (rows > 48U) { return false; }
    TPipe pipe;
    const uint32_t kStride=QmqAlignUp(k,32U);'''
assert body.count(old)==1;body=body.replace(old,new)
body=body.replace('pipe.InitBuffer(productBuffer,n*kStride*sizeof(float));','pipe.InitBuffer(productBuffer,2U*n*kStride*sizeof(float));')
body=body.replace('pipe.InitBuffer(sumBuffer,2U*alignedN*sizeof(float));','pipe.InitBuffer(sumBuffer,4U*alignedN*sizeof(float));')
old='''    for(uint32_t r=0;r<rows;++r){
        float activations[32];
        Mul(products,aFloat[r*kStride],bFloat,static_cast<uint64_t>(firstK),
            static_cast<uint8_t>(n),dotParams);
        if(k>64U){
            Mul(products[64U],aFloat[r*kStride+64U],bFloat[64U],
                static_cast<uint64_t>(k-64U),static_cast<uint8_t>(n),dotParams);
        }
        PipeBarrier<PIPE_V>();
        WholeReduceSum(sums,products,static_cast<int32_t>(firstK),
            static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
        if(k>64U){
            WholeReduceSum(sums[alignedN],products[64U],static_cast<int32_t>(k-64U),
                static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
            PipeBarrier<PIPE_V>();
            Add(sums,sums,sums[alignedN],n);
        }
        PipeBarrier<PIPE_ALL>();
        const float s1=s1Local.GetValue(r);'''
new='''    // Two banks separate the next vector dot from current scalar postprocessing.
    Mul(products,aFloat,bFloat,static_cast<uint64_t>(firstK),
        static_cast<uint8_t>(n),dotParams);
    if(k>64U){
        Mul(products[64U],aFloat[64U],bFloat[64U],
            static_cast<uint64_t>(k-64U),static_cast<uint8_t>(n),dotParams);
    }
    PipeBarrier<PIPE_V>();
    WholeReduceSum(sums,products,static_cast<int32_t>(firstK),
        static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
    if(k>64U){
        WholeReduceSum(sums[alignedN],products[64U],static_cast<int32_t>(k-64U),
            static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
        PipeBarrier<PIPE_V>();
        Add(sums,sums,sums[alignedN],n);
    }
    auto allSums=sums;
    for(uint32_t r=0;r<rows;++r){
        PipeBarrier<PIPE_ALL>();
        auto sums=allSums[(r & 1U)*2U*alignedN];
        if(r+1U<rows){
            auto nextProducts=products[((r+1U)&1U)*n*kStride];
            auto nextSums=allSums[((r+1U)&1U)*2U*alignedN];
            Mul(nextProducts,aFloat[(r+1U)*kStride],bFloat,static_cast<uint64_t>(firstK),
                static_cast<uint8_t>(n),dotParams);
            if(k>64U){
                Mul(nextProducts[64U],aFloat[(r+1U)*kStride+64U],bFloat[64U],
                    static_cast<uint64_t>(k-64U),static_cast<uint8_t>(n),dotParams);
            }
            PipeBarrier<PIPE_V>();
            WholeReduceSum(nextSums,nextProducts,static_cast<int32_t>(firstK),
                static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
            if(k>64U){
                WholeReduceSum(nextSums[alignedN],nextProducts[64U],static_cast<int32_t>(k-64U),
                    static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
                PipeBarrier<PIPE_V>();
                Add(nextSums,nextSums,nextSums[alignedN],n);
            }
        }
        float activations[32];
        const float s1=s1Local.GetValue(r);'''
assert body.count(old)==1
body=body.replace(old,new)
candidate=source[:start]+body+source[end:]
assert candidate[:start]==source[:start]
assert candidate[candidate.index('__global__ __vector__ void qmq_tiny_vector_entry(',start):]==source[end:]
align=lambda x:(x+31)//32*32
peak=0;configs=0;dots=0
rng=np.random.default_rng(991012)
for n in range(1,33):
    for k in range(1,129):
        if n*k>1024:continue
        stride=align(k);an=(n+7)//8*8
        for rows in (1,2,3,4,5,7,8,15,16,31,32,47,48):
            cc=(rows*32+63)//64*64
            sizes=[rows*stride,n*stride,2*rows*stride,2*n*stride,4*rows*stride,4*n*stride,
              8*n*stride,16*an,16*cc,align(cc//8),4*rows*32,align(rows*4),align(n*4),rows*32,align(rows*4)]
            peak=max(peak,sum(map(align,sizes)));assert sum(map(align,sizes))<=196608
            # Model bank writes/reads and lifetime independently of final quantization.
            a=rng.integers(-128,128,(rows,k),dtype=np.int8)
            b=rng.integers(-128,128,(n,k),dtype=np.int8)
            expected=a.astype(np.int32)@b.astype(np.int32).T
            banks=[None,None];owners=[None,None]
            def dot(row):
                aa=a[row].astype(np.float32);bb=b.astype(np.float32)
                lo=(aa[:64]*bb[:,:64]).sum(axis=1,dtype=np.float32)
                if k>64:lo+=(aa[64:]*bb[:,64:]).sum(axis=1,dtype=np.float32)
                assert np.array_equal(lo,expected[row].astype(np.float32))
                bank=row%2;assert owners[bank] is None
                banks[bank]=lo;owners[bank]=row
            dot(0)
            for row in range(rows):
                bank=row%2;assert owners[bank]==row
                current=banks[bank].copy()
                if row+1<rows:dot(row+1)
                assert np.array_equal(current,expected[row].astype(np.float32))
                owners[bank]=None;dots+=n
            assert owners==[None,None];configs+=1
folder=R/'v99_tiny_dot_pipeline_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code','change':'Two product/sum UB banks; issue next row vector dot before current row scalar postprocess; rows>48 use existing fallback',
 'scope':'Only QmqTryTinyDirect buffer sizes and dot schedule changed; scalar dequantization and quantization chain identical',
 'UB_peak_CPU_model_bytes':peak,'dot_bank_cases':configs,'dot_output_values':dots,
 'synchronization':'PIPE_ALL at each row start waits for prepared bank; alternate bank is disjoint and reused only after its scalar readers finish',
 'tutorial_method':'rms_norm_quant_story double buffering and SIMD latency hiding concepts; existing dav-2201 APIs only',
 'compile_correctness_performance':'PENDING; CPU integer and lifetime models do not execute ASC'}
(folder/'review_checks.json').write_text(json.dumps(review,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('预登记：15/15和零错误为必要条件。比较tiny点及整体统一T；下一行dot和本行标量后处理能否重叠需实际设备证据。UB预算已枚举，超过48行使用原workspace回退。收益>0.16分才进入复测；失败不推荐。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
