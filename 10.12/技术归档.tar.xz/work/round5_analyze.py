from pathlib import Path
import re,json,math,csv,hashlib
from datetime import datetime

R=Path(__file__).resolve().parent
out=R.parent/'outputs/第五轮_2026-10-12';out.mkdir(exist_ok=True)
records=[]
for f in sorted(R.glob('v*_20261012*')):
    if not(f/'kernel.asc').exists():continue
    row={'version':f.name,'sha256':hashlib.sha256((f/'kernel.asc').read_bytes()).hexdigest(),'status':'未提交'}
    if(f/'review_checks.json').exists():
        review=json.loads((f/'review_checks.json').read_text(encoding='utf-8-sig'))
        row['source_review_hash_match']=review.get('sha256')==row['sha256']
        row['source_review_pass']=bool(review.get('review_pass')) and row['source_review_hash_match']
        if review.get('post_submission_finding'):row['excluded_reason']=review['post_submission_finding']
    if(f/'web_verified.asc').exists():
        web_source=(f/'web_verified.asc').read_text(encoding='utf-8-sig').replace('\r\n','\n')
        row['submitted_source_sha256']=hashlib.sha256(web_source.encode('utf-8')).hexdigest()
        row['submitted_source_hash_match']=row['submitted_source_sha256']==row['sha256']
    else:
        row['submitted_source_hash_match']=False
    if(f/'submission_info.json').exists():row.update(json.loads((f/'submission_info.json').read_text(encoding='utf-8-sig')));row['status']='评测中'
    if(f/'platform_result.json').exists():
        d=json.loads((f/'platform_result.json').read_text(encoding='utf-8-sig'));row['url']=d['url']
        for name,pat in [('submission_id',r'提交 ID：\s*(\d+)'),('status',r'提交状态：\s*([^\r\n]+)'),('submitted_at',r'提交时间：\s*([^\r\n]+)')]:
            m=re.search(pat,d['text'])
            if m:row[name]=int(m[1]) if name=='submission_id' else m[1]
        pp=re.findall(r'(\d+)\t(Pass|Wrong Answer|Runtime Error|Compile Error)\t([\d.]+)%\t([\d.]+)(μs|µs|ms)\t([\d.]+)(μs|µs|ms)',d['text'])
        row['points']=[{'id':int(x[0]),'status':x[1],'error_pct':float(x[2]),'us':float(x[3])*(1000 if x[4]=='ms' else 1),'ref_us':float(x[5])*(1000 if x[6]=='ms' else 1)} for x in pp]
        row['all_pass']=(row['status']=='Pass' and [p['id'] for p in row['points']]==list(range(1,16))
                         and all(p['status']=='Pass' and p['error_pct']==0 and p['us']>0 and p['ref_us']>0 for p in row['points']))
        row['times_us']=[p['us'] for p in row['points']];row['reference_us']=[p['ref_us'] for p in row['points']]
        row['sum_us']=sum(row['times_us'])
    records.append(row)
base=next((r for r in records if r['version']=='v91_latest_control_20261012' and r.get('all_pass')),None)
def score(t,b):return sum(100 if a<=c else 100/(1+math.log(a/c,1.5)) for a,c in zip(t,b))/15
if base:
    for row in records:
        if row.get('all_pass'):
            row['eligible_for_recommendation']=row.get('source_review_pass',False) and row['submitted_source_hash_match']
            row['estimated_score_common_T']=score(row['times_us'],base['reference_us'])
            row['estimated_score_own_T']=score(row['times_us'],row['reference_us'])
            row['delta_pct_vs_latest_control']=[round(100*(a/b-1),3) for a,b in zip(row['times_us'],base['times_us'])]
            row['estimated_score_delta_vs_latest_control']=row['estimated_score_common_T']-score(base['times_us'],base['reference_us'])
        if 'points' in row:
            (R/row['version']/'hardware_validation.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
summary={'updated_beijing':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'records':records,'common_T':base['reference_us'] if base else [],'reference_version':base['version'] if base else None,'limitation':'统一T估算仅用于本轮横向比较；网页耗时已舍入，第15点ms影响估算。队友并发提交，队伍榜单不能独占归因；无自定义NPU边界测试或profile。'}
(R/'round5_checkpoint.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'评测汇总.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with(out/'逐点耗时.csv').open('w',newline='',encoding='utf-8-sig') as stream:
    w=csv.writer(stream);w.writerow(['version','submission_id','point','status','error_pct','us','ref_us','delta_pct_vs_control'])
    for row in records:
        for i,p in enumerate(row.get('points',[])):w.writerow([row['version'],row.get('submission_id'),p['id'],p['status'],p['error_pct'],p['us'],p['ref_us'],row.get('delta_pct_vs_latest_control',[None]*15)[i]])
lines=['# 第五轮自动优化记录','',summary['limitation'],'','|版本|提交ID|正确性|统一T估算|与本轮控制差|','|---|---:|---|---:|---:|']
for row in records:lines.append('|'+row['version']+'|'+str(row.get('submission_id',''))+'|'+('15/15 零错误' if row.get('all_pass') else row['status'])+'|'+format(row.get('estimated_score_common_T',0),'.4f')+'|'+format(row.get('estimated_score_delta_vs_latest_control',0),'+.4f')+'|')
(out/'实时评测记录.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps([{k:r.get(k) for k in ['version','submission_id','all_pass','status','estimated_score_common_T','estimated_score_delta_vs_latest_control']} for r in records],ensure_ascii=False))
