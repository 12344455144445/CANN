from pathlib import Path
from datetime import datetime
import json, re, sys, hashlib, subprocess

root = Path(__file__).resolve().parent
today = datetime.now().strftime('%Y-%m-%d')
cfg = json.loads((root / 'submission_budget.json').read_text(encoding='utf-8'))
records = {}
uncertain = []
for folder in root.glob('v*_*'):
    if not folder.is_dir():
        continue
    result = folder / 'platform_result.json'
    info = folder / 'submission_info.json'
    if result.exists():
        d = json.loads(result.read_text(encoding='utf-8-sig'))
        match = re.search(r'提交时间：\s*(\d{4}/\d{2}/\d{2})', d['text'])
        if match and match[1].replace('/', '-') == today:
            records[d['url']] = folder.name
    if info.exists():
        d = json.loads(info.read_text(encoding='utf-8-sig'))
        if d['captured_at'].startswith(today):
            records[d['url']] = folder.name
    attempt = folder / 'submission_attempt.json'
    if attempt.exists() and not info.exists() and not result.exists():
        d = json.loads(attempt.read_text(encoding='utf-8-sig'))
        if d['started_at'].startswith(today) and d['state'] == 'submit_invocation_started':
            uncertain.append(folder.name)
external = cfg['other_observed_account_submissions'] if cfg['date'] == today else 0
used = len(records) + external + len(uncertain)
report = {'date': today, 'own_confirmed': len(records), 'other_observed_account_submissions': external,
          'uncertain_submit_attempts': uncertain, 'conservative_account_used': used,
          'daily_limit': cfg['daily_limit'], 'reserve': cfg['reserve'],
          'remaining_by_account_assumption': cfg['daily_limit'] - used,
          'scope': cfg['scope'], 'account_history_observed_at': cfg['observed_at']}
(root / 'submission_budget_status.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
if len(sys.argv) > 1:
    folder = Path(sys.argv[1])
    plan = json.loads((root / 'round5_plan.json').read_text(encoding='utf-8'))
    if plan.get('automatic_submission_enabled') is False:
        raise SystemExit('User stopped competition submissions; a new user instruction is required to resume')
    if uncertain:
        raise SystemExit('Unresolved submit invocation: inspect its visible result before further submission')
    if used >= cfg['daily_limit'] - cfg['reserve']:
        raise SystemExit('Daily submission reserve reached')
    review = json.loads((folder / 'review_checks.json').read_text(encoding='utf-8'))
    digest = hashlib.sha256((folder / 'kernel.asc').read_bytes()).hexdigest()
    if not review.get('review_pass') or review['sha256'] != digest:
        raise SystemExit('Candidate lacks a passing review for its current source')
    subprocess.run([sys.executable,str(root/'audit_round5_shapes.py'),str(folder)],check=True)
print(json.dumps(report, ensure_ascii=False))
