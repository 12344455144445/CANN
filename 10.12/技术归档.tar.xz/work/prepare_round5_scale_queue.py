from pathlib import Path
import hashlib,json,difflib

root=Path(__file__).resolve().parent
base=(root/'v111_general_odd_cast_20261012/kernel.asc').read_text(encoding='utf-8')
changes=[
 ('    TBuf<TPosition::VECCALC> rowScaleBuffer;\n',''),
 ('    pipe.InitBuffer(rowScaleBuffer, alignedRows * sizeof(float));\n',''),
 ('    LocalTensor<float> rowScaleLocal = rowScaleBuffer.Get<float>();',
  '    LocalTensor<float> rowScaleLocal = yScaleQueue.AllocTensor<float>();'),
 ('    LocalTensor<float> yScaleLocal = yScaleQueue.AllocTensor<float>();\n',''),
 ('''    for (uint32_t row = 0; row < rows; ++row) {
        yScaleLocal.SetValue(row, rowScaleLocal.GetValue(row));
    }''','''    // Compute scales directly in the output queue and retain its read-only bank.
    LocalTensor<float> yScaleLocal = rowScaleLocal;'''),
 ('    yScaleQueue.FreeTensor(yScaleLocal);\n',''),
 ('    if (reuseColumnScale) { x2ScaleQueue.FreeTensor(retainedColumnScale); }',
  '    yScaleQueue.FreeTensor(yScaleLocal);\n    if (reuseColumnScale) { x2ScaleQueue.FreeTensor(retainedColumnScale); }'),
]
text=base
for old,new in changes:
    assert text.count(old)==1,old
    text=text.replace(old,new)
# Empty replacements are reconstructed at unique neighboring statements.
inverse=text.replace(changes[-1][1],changes[-1][0])
inverse=inverse.replace(changes[2][1],changes[2][0]).replace(changes[4][1],changes[4][0])
inverse=inverse.replace('    TBuf<TPosition::VECCALC> rowMaxBuffer;\n','    TBuf<TPosition::VECCALC> rowMaxBuffer;\n'+changes[0][0])
inverse=inverse.replace('    pipe.InitBuffer(rowMaxBuffer, alignedRows * sizeof(float));\n',
 '    pipe.InitBuffer(rowMaxBuffer, alignedRows * sizeof(float));\n'+changes[1][0])
inverse=inverse.replace('    // [OPT-V45-B1] AllocTensor 上移（纯顺序变化，内容一字未改）。\n',
 '    // [OPT-V45-B1] AllocTensor 上移（纯顺序变化，内容一字未改）。\n'+changes[3][0])
inverse=inverse.replace('    DataCopyPad(yScaleGm[rowStart], yScaleLocal, yScaleCopy);\n',
 '    DataCopyPad(yScaleGm[rowStart], yScaleLocal, yScaleCopy);\n'+changes[5][0])
assert inverse==base

allocate=text.index('rowScaleLocal = yScaleQueue.AllocTensor<float>()')
correct=text.index('    QmqCorrectDiv(',allocate)
override=text.index('rowScaleLocal.SetValue(row, 1.0f)',correct)
enqueue=text.index('yScaleQueue.EnQue(yScaleLocal)',override)
dequeue=text.index('yScaleQueue.DeQue<float>()',enqueue)
copy=text.index('DataCopyPad(yScaleGm[rowStart]',dequeue)
last_scale_read=text.index('pairRowScalePrefetch[i] = rowScaleLocal.GetValue(group + i)',copy)
release=text.index('yScaleQueue.FreeTensor(yScaleLocal)',last_scale_read)
assert allocate<correct<override<enqueue<dequeue<copy<last_scale_read<release
assert text.count('yScaleQueue.AllocTensor<float>()')==1
assert text.count('yScaleQueue.FreeTensor(yScaleLocal)')==1

folder=root/'v124_scale_output_bank_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v111_general_odd_cast_20261012',
 'only_change':'Use the depth1 yScaleQueue bank directly as rowScaleLocal; remove separate rowScale TBuf and scalar copy; retain queue bank until all quantization reads finish.',
 'exact_source_inverse':True,'scale_division_zero_override_precision_helpers_order_unchanged':True,
 'source_lifetime_order_checked':True,'queue_allocations_and_frees':1,
 'UB_peak_bytes':166784,'UB_reduction_at1024rows_bytes':4096,
 'read_only_after_enqueue':'After GM yScale copy, only scalar GetValue reads occur. The bank is not reallocated or freed until the end of pass2; concurrent MTE3/S reads do not overwrite data.',
 'distinct_other_buffers':'Row maxima, division residual/scratch/mask, activations, quotient and output retain separate allocations; scalar scale overrides happen before enqueue.',
 'hypothesis':'Remove one buffer initialization and rows scalar GetValue/SetValue pairs without altering any FP32 math.',
 'device':'PENDING; source lifetime analysis cannot establish actual queue synchronization/compiler timing.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='v111',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('后处理独立数据流优化：每行scale直接计算在yScale输出队列块，移除独立rowScaleBuffer及逐行复制。输出DMA后继续只读prefetch尺度，量化全部完成才Free。精度函数、零行修正与运算顺序不变；通用UB上界166784B。基于已验证通用ODD输出转换，设备结果待测。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
