from pathlib import Path
import json, hashlib, difflib, re

R = Path(__file__).resolve().parent
base = (R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
padded = (R/'v97_corrected_padded_20261012/kernel.asc').read_text(encoding='utf-8')
start_token = '__aicore__ inline void QmqEnqueueWorkspaceTile('
vector_token = '__aicore__ inline void quant_matmul_relu_quant_vector('
end_token = '__global__ __aicore__ void'
# Use the next global declaration as a boundary, independent of line numbers.
start = padded.index(start_token)
vec = padded.index(vector_token)
end = padded.index('__global__', vec)
block = padded[start:end]
block = block.replace('QmqEnqueueWorkspaceTile', 'QmqEnqueuePaddedWorkspaceTile')
block = block.replace('quant_matmul_relu_quant_vector', 'QmqPaddedVector')
old = 'const bool paddedBatch = n >= 32U && n <= 3072U && n % 32U != 0U;'
assert block.count(old) == 1
block = block.replace(old, 'const bool paddedBatch = true;')
old = '''const uint32_t rowBatchLimit = (n >= 32U && n <= 3072U)
        ? QmqMinValue(4U, kPairCapacity / batchRowStride) : 1U;'''
assert block.count(old) == 1
block = block.replace(old, 'const uint32_t rowBatchLimit = QmqMinValue(4U, kPairCapacity / batchRowStride);')
assert block.count('const bool reuseColumnScale = n <= kVectorTileN;') == 1
block = block.replace('const bool reuseColumnScale = n <= kVectorTileN;', 'const bool reuseColumnScale = true;')
wrapper = '''__aicore__ inline void QmqDispatchVector(
    GM_ADDR workspace, GM_ADDR x1Scale, GM_ADDR x2Scale, GM_ADDR y, GM_ADDR yScale,
    uint32_t m, uint32_t n, uint32_t rowStart, uint32_t rows)
{
    if (n >= 32U && n <= 3072U && n % 32U != 0U) {
        QmqPaddedVector(workspace, x1Scale, x2Scale, y, yScale, m, n, rowStart, rows);
    } else {
        quant_matmul_relu_quant_vector(workspace, x1Scale, x2Scale, y, yScale, m, n, rowStart, rows);
    }
}

'''
bvec = base.index(vector_token)
bend = base.index('__global__', bvec)
prefix = base[:bend]
suffix = base[bend:]
assert suffix.count('quant_matmul_relu_quant_vector(') == 2
suffix = suffix.replace('quant_matmul_relu_quant_vector(', 'QmqDispatchVector(')
candidate = prefix + block + wrapper + suffix
# Check exact original implementation and precision helpers survive insertion.
assert candidate[:bend] == base[:bend]
assert suffix.replace('QmqDispatchVector(', 'quant_matmul_relu_quant_vector(') == base[bend:]
assert candidate.count('const bool paddedBatch = true;') == 1
configs = 0
for n in range(1, 13001):
    route = 32 <= n <= 3072 and n % 32 != 0
    if route:
        stride = (n+31)//32*32
        batch = min(4,6144//stride)
        assert stride * batch <= 6144
        assert stride % 32 == 0
        assert n <= 6144
        configs += 1
folder = R/'v102_specialized_padding_20261012'
folder.mkdir(exist_ok=True)
assert not (folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(candidate, encoding='utf-8', newline='\n')
review = {'review_pass': True, 'sha256': hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base': 'v91 original + separately named v97 passing padded implementation',
 'change': 'Dispatch only nonaligned N33..3071 to compile-time padded path; original vector helper/function kept byte-identical',
 'dispatch_N_cases':13000, 'padded_N_cases':configs,
 'safety': 'Specialized true padding/cache assumptions follow dispatcher; alignment/packing inherited from v97 CPU/device validation',
 'precision_tiny_host_cube_unchanged': True, 'extra_UB_at_runtime': False,
 'device': 'PENDING: compiled function size and performance require competition verification'}
(folder/'review_checks.json').write_text(json.dumps(review, ensure_ascii=False, indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('仅将N非32对齐且32<=N<=3072派发到v97经过设备验证的独立补齐函数。其余形状使用逐字节保留的原始向量函数。固定padded/cache=true依赖派发范围，禁止从其它入口直接调用。要求15/15零错误，改善整体分数后复测。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
