from pathlib import Path
import json, hashlib, re, difflib
from datetime import datetime

R=Path(__file__).resolve().parent
source=(R/'round5_repo/Carl Memory/推荐版本/code/kernel.asc').read_text(encoding='utf-8').rstrip('\n')+'\n'
def fn(s,name):
    start=s.index(name+'('); opening=s.index('{',start); end=opening+1; depth=1
    while depth:
        depth+=(s[end]=='{')-(s[end]=='}');end+=1
    return s[opening:end]

base=(R/'v84_n32_batch4_20261011/kernel.asc').read_text(encoding='utf-8')
unchanged=['QmqQuantizeNearHalf','QmqDiv','QmqCorrectDiv','QmqScaleBy127Exact','QmqTryTinyDirect','QmqComputeTinyC','quant_matmul_relu_quant_cube','quant_matmul_relu_quant_fused','qmq_tiny_vector_entry','run_kernel']
assert all(fn(source,n)==fn(base,n) for n in unchanged)
assert re.findall(r'pipe.InitBuffer\([^;]+;',source)==re.findall(r'pipe.InitBuffer\([^;]+;',base)
api=r'^\s*(?:Cast|Muls|Mul|ReduceMax|ReduceMin|Maxs|Mins|QmqDiv|QmqCorrectDiv|Compares|Compare|Abs|Adds|Sub|Select|SetDeqScale)\([^;]+;'
assert re.findall(api,source,re.M)==re.findall(api,base,re.M)
assert source.count('PipeBarrier<')==base.count('PipeBarrier<')

variants={'v91_latest_control_20261012':source,
 'v92_prefetch16_20261012':source.replace('kPairPrefetchSpan = 64U','kPairPrefetchSpan = 16U'),
 'v93_cache3072_20261012':source.replace('const bool reuseColumnScale = n <= kVectorTileN;','const bool reuseColumnScale = n <= 3072U;').replace('// N<=6144 guarantees one N tile;','// N<=3072 guarantees one N tile;')}

# Ownership through two passes, including the reuse gate and multi-tile fallback.
for gate in (3072,6144):
    for n in range(1,13001):
        live=alloc=free=0; keep=n<=gate
        for stage in (1,2):
            for offset in range(0,n,6144):
                if not(keep and stage==2):live+=1;alloc+=1
                assert live==1
                if not keep:live-=1;free+=1
        if keep:live-=1;free+=1
        assert live==0 and alloc==free

# Exercise changed scalar-group boundaries independently of numerical helpers.
configs=0
for span in (16,64):
    for limit in (1,2,3,4):
        for rows in range(1,1025):
            queued=[(0,min(limit,rows))];seen=[]
            for group in range(0,rows,span):
                group_rows=min(span,rows-group)
                for local in range(0,group_rows,limit):
                    start=group+local; count=min(limit,group_rows-local)
                    offset,loaded=queued.pop(0)
                    assert offset==start and loaded>=count and offset+loaded<=rows
                    if start+count<rows:queued.append((start+count,min(limit,rows-start-count)))
                    seen.extend(range(start,start+count))
            assert seen==list(range(rows)) and not queued
            configs+=1

for name,text in variants.items():
    folder=R/name;folder.mkdir(exist_ok=True)
    assert not(folder/'submission_attempt.json').exists(),'Submitted source immutable'
    (folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
    report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
      'base':'GitHub main 5490e62edf8e57037659cc105327a86b57a9c7bc / Carl Memory/推荐版本/code/kernel.asc',
      'unchanged_functions':unchanged,'UB_allocations_unchanged':True,'numeric_API_sequence_unchanged':True,
      'ownership_N_cases':26000,'queue_boundary_configurations':configs,
      'compile_and_NPU':'PENDING; static/CPU models are not device tests'}
    (folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='latest_code',tofile=name)),encoding='utf-8')
    (folder/'SUBMIT.md').write_text('预登记：15/15且零错误为必要条件；以本日控制版相同T比较逐点耗时。估算增益>0.16分且受影响点多数变快才追加复测；任何精度/运行失败即拒绝。微小单次变化仅记观测，不称稳定收益。保留10次日余量。',encoding='utf-8')
    print(name,report['sha256'])

history=json.loads((R/'account_history_20261012/page1.json').read_text(encoding='utf-8-sig'))
assert '2026/10/12 ' not in history['text']
budget=json.loads((R/'submission_budget.json').read_text(encoding='utf-8'))
budget.update(date='2026-10-12',other_observed_account_submissions=0,observed_account_used=0,observed_at=history['observed_at_beijing'],evidence=['account_history_20261012/page1.json'])
(R/'submission_budget.json').write_text(json.dumps(budget,ensure_ascii=False,indent=2),encoding='utf-8')
prefs=json.loads((R/'workflow_preferences.json').read_text(encoding='utf-8'))
prefs.update(automatic_submission_enabled=True,competition_submissions_stopped_by_user=False,current_work_completed=False,finish_current_work='2026-10-12用户再次要求结合GitHub最新code及两份工作成果继续优化并自动比赛提交。')
(R/'workflow_preferences.json').write_text(json.dumps(prefs,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'round5_plan.json').write_text(json.dumps({'automatic_submission_enabled':True,'source_ref':'5490e62edf8e57037659cc105327a86b57a9c7bc','variants':list(variants),'daily_limit':50,'reserve':10},indent=2),encoding='utf-8')
check=(R/'check_submission_budget.py').read_text().replace('round4_plan.json','round5_plan.json')
(R/'round5_check_budget.py').write_text(check,encoding='utf-8')
for old,new in [('round4_submit_candidate.ps1','round5_submit_candidate.ps1'),('round4_read_result.ps1','round5_read_result.ps1')]:
    text=(R/old).read_text(encoding='utf-8-sig').replace('18943032','5705316').replace('round4_ui_browser','round5_ui_browser').replace('check_submission_budget.py','round5_check_budget.py')
    (R/new).write_text(text,encoding='utf-8-sig')
