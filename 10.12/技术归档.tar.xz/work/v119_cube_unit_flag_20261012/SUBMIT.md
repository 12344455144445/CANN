Allow Cube computation/output transfer overlap using the documented UnitFlag configuration, disabled by default in MDL.
Retain IterateAll, End, and existing PIPE_FIX cross-core notifications. UnitFlag is internal Matmul synchronization; no application flags are deleted or reordered.
API: https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0622.html
One configuration variable; no post-processing or host tiling change.
