from pathlib import Path
import hashlib,json,difflib

root=Path(__file__).resolve().parent
base=(root/'v123_cube_iterate_all_20261012/kernel.asc').read_text(encoding='utf-8')
old='decltype(config.iterateMode)::ITERATE_MODE_ALL'
new='IterateMode::ITERATE_MODE_ALL'
assert base.count(old)==1
text=base.replace(old,new);assert text.replace(new,old)==base
folder=root/'v130_cube_iterate_all_fix_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review=json.loads((root/'v123_cube_iterate_all_20261012/review_checks.json').read_text(encoding='utf-8'))
review.update({'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v123 failed compile variant; intended behavior relative v91 unchanged',
 'compile_failure_diagnosis':'Platform compiler explicitly reports decltype(config.iterateMode) is unsigned char, not an enumeration. The value must be named through IterateMode itself.',
 'only_change_from_failed_source':'Use IterateMode::ITERATE_MODE_ALL instead of qualifying the enum value through the byte storage type.',
 'device':'PENDING; no claim of successful compilation until this exact source is evaluated.'})
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='v123',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('修正已读取平台日志明确的编译错误：iterateMode存储字段为unsigned char，枚举常量应从IterateMode命名。修正限定名，保留失败源码和日志，不硬编码枚举数值。设备编译、正确性及性能待验证。',encoding='utf-8')
print(json.dumps({'variant':folder.name,'sha256':review['sha256'],'diagnosis':review['compile_failure_diagnosis']},ensure_ascii=False))
