from pathlib import Path
import hashlib,json,difflib,re

root=Path(__file__).resolve().parent
base=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
start=base.index('__aicore__ inline bool QmqTryTinyDirect(')
end=base.index('__global__ __vector__ void qmq_tiny_vector_entry(',start)
oldbody=base[start:end]
begin=oldbody.index('    TBuf<TPosition::VECCALC> aBuffer,bBuffer,')
finish=oldbody.index('    auto aLocal=aBuffer.Get<int8_t>();',begin)
block=oldbody[begin:finish]
allocations=re.findall(r'pipe.InitBuffer\((\w+),([^;]+)\);',block)
assert len(allocations)==15
parts=['    const uint32_t activationStride=32U;',
       '    const uint32_t quantCount=rows*activationStride;',
       '    const uint32_t compareCount=QmqAlignUp(quantCount,64U);',
       '    // One allocation, disjoint 32-byte-aligned slices for all tiny buffers.']
previous=None
for name,size in allocations:
    value='0U' if previous is None else f'{previous[0]}Offset + QmqAlignUp({previous[1]},32U)'
    parts.append(f'    const uint32_t {name}Offset={value};')
    previous=(name,size)
parts += [f'    const uint32_t tinyArenaBytes={previous[0]}Offset + QmqAlignUp({previous[1]},32U);',
          '    TBuf<TPosition::VECCALC> tinyArena;',
          '    pipe.InitBuffer(tinyArena,tinyArenaBytes);']
newblock='\n'.join(parts)+'\n'
body=oldbody.replace(block,newblock)
replacements=[]
for name,size in allocations:
    pattern=re.compile(r'\b'+name+r'\.Get<([^>]+)>\(\)')
    matches=list(pattern.finditer(body));assert len(matches)==1,(name,len(matches))
    typ=matches[0][1]
    old=matches[0][0]
    new=f'tinyArena.Get<{typ}>()[{name}Offset/sizeof({typ})]'
    body=body.replace(old,new)
    replacements.append((old,new))
guard_old='    TPipe pipe;\n    const uint32_t kStride=QmqAlignUp(k,32U);'
guard_new='    if(rows>48U){return false;}\n'+guard_old
assert body.count(guard_old)==1
body=body.replace(guard_old,guard_new)
inverse=body.replace(guard_new,guard_old).replace(newblock,block)
for old,new in replacements:inverse=inverse.replace(new,old)
assert inverse==oldbody
text=base[:start]+body+base[end:]

# Interpret the actual generated allocation expressions; establish disjoint
# regions for every admitted tiny N/K and every row count including tail rows.
import ast
def align(value,unit=32):return (value+unit-1)//unit*unit
def expr_value(expr,env):
    expr=expr.replace('sizeof(float)','4').replace('sizeof(half)','2')
    expr=re.sub(r'(\d+)U\b',r'\1',expr)
    tree=ast.parse(expr,mode='eval')
    def visit(t):
        if isinstance(t,ast.Expression):return visit(t.body)
        if isinstance(t,ast.Constant):return t.value
        if isinstance(t,ast.Name):return env[t.id]
        if isinstance(t,ast.BinOp) and isinstance(t.op,ast.Mult):return visit(t.left)*visit(t.right)
        if isinstance(t,ast.BinOp) and isinstance(t.op,ast.Add):return visit(t.left)+visit(t.right)
        if isinstance(t,ast.BinOp) and isinstance(t.op,ast.Div):return visit(t.left)//visit(t.right)
        if isinstance(t,ast.Call) and isinstance(t.func,ast.Name) and t.func.id=='QmqAlignUp':return align(*[visit(x) for x in t.args])
        raise ValueError(ast.dump(t))
    return visit(tree)
checked=0;peak=0
for n in range(1,33):
    for k in range(1,129):
        if n*k>1024:continue
        for rows in range(1,49):
            env={'n':n,'rows':rows,'kStride':align(k),'alignedN':align(n,8),'quantCount':rows*32,'compareCount':align(rows*32,64)}
            cursor=0
            for name,size in allocations:
                actual_offset=re.search(r'const uint32_t '+name+r'Offset=([^;]+);',body)[1]
                offset=expr_value(actual_offset,env)
                assert offset==cursor,(name,offset,cursor)
                env[name+'Offset']=offset
                length=align(expr_value(size,env))
                assert cursor%32==0 and length>0
                cursor+=length
            assert expr_value(re.search(r'const uint32_t tinyArenaBytes=([^;]+);',body)[1],env)==cursor
            assert cursor<=196608
            peak=max(peak,cursor);checked+=1

folder=root/'v120_tiny_single_arena_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91_latest_control_20261012','only_change':'15 tiny TBuf allocations replaced by one allocation and disjoint aligned slices; rows>48 uses existing correct fallback.',
 'exact_source_inverse':True,'all_math_copy_count_barriers_precision_helpers_unchanged':True,
 'shape_layout_configs':checked,'tiny_UB_peak_bytes':peak,'buffer_sizes_offsets':dict(allocations),
 'scope':'Only QmqTryTinyDirect allocation declarations and Get addresses. General/Cube/host unchanged.',
 'lifetime':'Every original tensor owns a distinct slice for the full function; no temporal aliasing. Explicit API counts/strides unchanged.',
 'hypothesis':'Reduce fixed TPipe/TBuf setup work on small inputs without changing the computation schedule.',
 'device':'PENDING; offline interval checks do not establish compiler treatment of subviews or speed.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('小形状固定开销诊断：15个同位置类型TBuf合并为一个连续分配；每块仍独占32B对齐区间，全部运算及屏障不变。rows>48走原正确回退。逐N/K/rows校验容量和区间；实际子视图编译语义与性能需要设备15点验证。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
