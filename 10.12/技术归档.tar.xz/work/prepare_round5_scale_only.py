from pathlib import Path
import hashlib,json,difflib

root=Path(__file__).resolve().parent
candidate=(root/'v124_scale_output_bank_20261012/kernel.asc').read_text(encoding='utf-8')
original=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
odd=(root/'v111_general_odd_cast_20261012/kernel.asc').read_text(encoding='utf-8')
end_marker='                PipeBarrier<PIPE_V>();\n                LocalTensor<int8_t> outputLocal = outputQueue.AllocTensor<int8_t>();'
orig_start=original.index('                Cast(inputLocal, fp32Local, RoundMode::CAST_RINT, pairCount);')
orig_end=original.index(end_marker,orig_start)
original_chain=original[orig_start:orig_end]
odd_start=odd.index('                // Round-to-odd avoids double rounding at integer half ties.')
odd_end=odd.index(end_marker,odd_start)
odd_chain=odd[odd_start:odd_end]
assert candidate.count(odd_chain)==1
text=candidate.replace(odd_chain,original_chain)
assert text.replace(original_chain,odd_chain)==candidate
folder=root/'v131_scale_queue_only_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v124_scale_output_bank_20261012; equivalent to v91 plus only the reviewed scale-bank optimization',
 'only_change_from_v124':'Restore original FP32->INT32->HALF->INT8 conversion sequence and SetDeqScale.',
 'exact_source_inverse':True,
 'purpose':'Isolate the scale-bank improvement from ODD conversion; determine whether the queue optimization benefits the original numerical tail too.',
 'baseline_output_conversion_and_precision_helpers_exact':True,
 'scale_bank_lifetime_and_UB_proof_reused_from_v124':True,'UB_peak_bytes':166784,
 'device':'PENDING; do not infer performance from v124 or from operation counts.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(candidate.splitlines(True),text.splitlines(True),fromfile='v124',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('单独验证尺度队列复用：保留v124已验证的尺度缓冲生命周期，但输出恢复最新原版完整三步转换。用来区分缓存复用与ODD转换的贡献。尺度与量化精度函数完全不变，UB上界166784B。等待独立设备结果。',encoding='utf-8')
print(json.dumps({'version':folder.name,'sha256':review['sha256'],'UB_peak_bytes':166784},ensure_ascii=False))
