"""Compare repeated device timings using one common reference, preserving raw runs."""
from pathlib import Path
import hashlib
import json
import statistics

root = Path(__file__).resolve().parent
checkpoint = json.loads((root / 'round5_checkpoint.json').read_text(encoding='utf-8'))
runs = {r['version']: r for r in checkpoint['records']}
pairs = [
    ('v124_scale_output_bank_20261012', 'v125_adjacent_control_20261012'),
    ('v127_scale_output_repeat_20261012', 'v125_adjacent_control_20261012'),
    ('v129_scale_output_final_repeat_20261012', 'v128_adjacent_control_repeat_20261012'),
]
comparisons = []
for candidate_name, control_name in pairs:
    candidate, control = runs[candidate_name], runs[control_name]
    assert candidate['eligible_for_recommendation'] and control['eligible_for_recommendation']
    for run in (candidate, control):
        assert hashlib.sha256((root / run['version'] / 'kernel.asc').read_bytes()).hexdigest() == run['sha256']
    improvement = [100 * (b - a) / b for a, b in zip(candidate['times_us'], control['times_us'])]
    comparisons.append({
        'candidate': candidate_name, 'control': control_name,
        'candidate_estimate_common_T': candidate['estimated_score_common_T'],
        'control_estimate_common_T': control['estimated_score_common_T'],
        'estimate_delta': candidate['estimated_score_common_T'] - control['estimated_score_common_T'],
        'point_time_improvement_pct': improvement,
        'faster_points': [i + 1 for i, value in enumerate(improvement) if value > 0],
        'equal_points': [i + 1 for i, value in enumerate(improvement) if value == 0],
    })
assert len({runs[a]['sha256'] for a, _ in pairs}) == 1
result = {
    'candidate_sha256': runs[pairs[0][0]]['sha256'],
    'comparisons': comparisons,
    'mean_estimate_delta': statistics.mean(r['estimate_delta'] for r in comparisons),
    'all_three_estimate_deltas_positive': all(r['estimate_delta'] > 0 for r in comparisons),
    'limitation': 'Three identical-source device runs versus two adjacent controls. First two comparisons share one control and are not independent samples. Estimates use the initial v91 reference times; point10/12 public reference times changed later. No claim of statistical significance or universal speedup.',
}
fourth = runs.get('v132_selected_restore_20261012')
if fourth and fourth.get('eligible_for_recommendation'):
    assert fourth['sha256'] == result['candidate_sha256']
    control = runs['v128_adjacent_control_repeat_20261012']
    result['fourth_run'] = {
        'version': fourth['version'], 'estimate_common_T': fourth['estimated_score_common_T'],
        'nearest_earlier_control': control['version'],
        'estimate_delta_vs_earlier_control': fourth['estimated_score_common_T'] - control['estimated_score_common_T'],
        'point_time_improvement_pct_vs_earlier_control': [100 * (b - a) / b for a, b in zip(fourth['times_us'], control['times_us'])],
        'finding': 'Fourth run passes all points but has slower small-point timings and a lower total estimate. Points10..15 remain faster than the earlier control. It is not a new paired control and prevents claiming stable whole-score gains.',
    }
    result['stable_total_score_gain_established'] = False
    scores = [runs[a]['estimated_score_common_T'] for a, _ in pairs] + [fourth['estimated_score_common_T']]
    result['all_four_candidate_score_range'] = [min(scores), max(scores)]
    result['all_four_candidate_mean_estimate'] = statistics.mean(scores)
    result['all_four_candidate_median_estimate'] = statistics.median(scores)
    result['limitation'] += ' Fourth restoration run is included separately and its score regressed; the first-three paired mean must not be presented as evidence of four stable gains.'
(root / 'scale_bank_comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'estimate_deltas': [r['estimate_delta'] for r in comparisons], 'mean': result['mean_estimate_delta'], 'faster_points': [r['faster_points'] for r in comparisons]}, ensure_ascii=False))
