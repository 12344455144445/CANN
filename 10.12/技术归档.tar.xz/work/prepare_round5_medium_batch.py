from pathlib import Path
import hashlib,json,difflib
import numpy as np
R=Path(__file__).resolve().parent
source=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='? QmqMinValue(4U, kPairCapacity / n) : 1U;'
new='? QmqMinValue(n >= 512U && n <= 1024U ? 8U : 4U, kPairCapacity / n) : 1U;'
assert source.count(old)==1
text=source.replace(old,new)
oldbuf='pipe.InitBuffer(scalarMaxBuffer, 4U * kFloatBlock * sizeof(float));'
newbuf='pipe.InitBuffer(scalarMaxBuffer, 8U * kFloatBlock * sizeof(float));'
assert text.count(oldbuf)==1;text=text.replace(oldbuf,newbuf)
assert text.replace(new,old).replace(newbuf,oldbuf)==source
queue_cases=0
limits=set()
for n in range(1,13001):
    gate=32<=n<=3072 and n%32==0
    limit=min(8 if 512<=n<=1024 else 4,6144//n) if gate else 1
    stride=(n+7)//8*8
    assert limit<=8
    if limit>1:assert n%32==0 and n*limit<=6144
    limits.add(limit)
for limit in limits:
    for rows in range(1,1025):
        queue=[(0,min(limit,rows))];seen=[]
        for group in range(0,rows,64):
            count=min(64,rows-group)
            for local in range(0,count,limit):
                start=group+local;take=min(limit,count-local);offset,loaded=queue.pop(0)
                assert offset==start and take<=loaded<=8 and offset+loaded<=rows
                if start+take<rows:queue.append((start+take,min(limit,rows-start-take)))
                # Each ReduceMax result writes a 32-byte block, including r=7.
                for r in range(take):assert (r+1)*8*4<=8*8*4
                seen.extend(range(start,start+take))
        assert seen==list(range(rows)) and not queue
        queue_cases+=1
rng=np.random.default_rng(1061012);elements=0
for n in range(512,1025,32):
    limit=min(8,6144//n)
    for rows in (1,2,3,4,5,6,7,8,9,15,16,17,63,64,65,127,128):
        ints=rng.integers(-30000000,30000001,(rows,n),dtype=np.int32)
        s1=rng.uniform(-2,2,rows).astype(np.float32);s2=rng.uniform(-2,2,n).astype(np.float32)
        act=np.maximum((ints.astype(np.float32)*s1[:,None])*s2,0)
        got=np.empty_like(act)
        for group in range(0,rows,64):
            for row in range(group,min(group+64,rows),limit):
                take=min(limit,min(group+64,rows)-row)
                got[row:row+take]=np.maximum((ints[row:row+take].astype(np.float32)*s1[row:row+take,None])*s2,0)
        assert np.array_equal(got.view(np.uint32),act.view(np.uint32));elements+=rows*n
# Max resource allocation, including the enlarged 8-row ReduceMax output buffer.
peak=2*6144*4+6144*4+1024*4+6144+1024*4+3*6144*4+2*1024*4+8*8*4+6144//8
assert peak<=196608
folder=R/'v106_mediumN_batch8_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code','change':'Aligned N512..1024 batch up to8; enlarge scalarMaxBuffer from4 to8 result blocks',
 'new_vs_v96':'v96 quarantined: did not enlarge per-row reduction output; this candidate fixes that capacity and targets medium N only',
 'queue_cases':queue_cases,'batch_limits':sorted(limits),'CPU_arithmetic_elements':elements,
 'UB_peak_bytes':peak,'added_UB_bytes':128,'scope_inverse_proof':True,'device':'PENDING'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('中等对齐N512..1024最多8行合批，scalarMaxBuffer同步扩至8个32字节结果块。N32..256仍原4行。穷举行预取64分组与6/7行批尾部，要求15/15零错误并性能改善才复测。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
