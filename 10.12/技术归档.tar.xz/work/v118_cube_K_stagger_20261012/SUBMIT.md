Reduce same-address GM loading conflicts among cores reading the identical right matrix; official MDL K-stagger scheduling.
MDL is retained. A/B are GM INT8, C is GM INT32. No FP32 operation or row mapping changes. Recommendation is large K with neither operand fully loaded; performance for other shapes is not assumed.
API: https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0622.html
One configuration variable; no post-processing or host tiling change.
