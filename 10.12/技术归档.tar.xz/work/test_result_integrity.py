"""Regression fixtures for result/source association, without touching device evidence."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('round5_analyze.py')


class ResultIntegrityTests(unittest.TestCase):
    def analyze(self, mode='valid'):
        scratch = SCRIPT.resolve().parent / 'result_test_scratch'
        scratch.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='fixture-', dir=scratch) as temporary:
            root = Path(temporary)
            assert root.resolve().parent == scratch.resolve()
            work = root / 'work'
            work.mkdir()
            (root / 'outputs').mkdir()
            shutil.copyfile(SCRIPT, work / SCRIPT.name)
            folder = work / 'v91_latest_control_20261012'
            folder.mkdir()
            source = b'// synthetic parser fixture; no device execution\n'
            (folder / 'kernel.asc').write_bytes(source if mode != 'mutated_source' else source + b'// changed\n')
            if mode != 'missing_submission_copy':
                (folder / 'web_verified.asc').write_bytes(b'\xef\xbb\xbf' + source.replace(b'\n', b'\r\n'))
            review = {'review_pass': True, 'sha256': hashlib.sha256(source).hexdigest()}
            if mode == 'wrong_review_hash':
                review['sha256'] = '0' * 64
            (folder / 'review_checks.json').write_text(json.dumps(review), encoding='utf-8')
            ids = list(range(1, 16)) if mode != 'duplicate_point' else [1] * 15
            lines = [f'{i}\tPass\t0.00%\t2.00μs\t1.00μs' for i in ids]
            status = 'Running' if mode == 'unfinished' else 'Pass'
            text = '提交状态：' + status + '\n' + '\n'.join(lines)
            (folder / 'platform_result.json').write_text(json.dumps({'url': 'fixture://local', 'text': text}), encoding='utf-8')
            completed = subprocess.run([sys.executable, str(work / SCRIPT.name)], capture_output=True, text=True, encoding='utf-8')
            self.assertEqual(completed.returncode, 0, completed.stderr)
            return json.loads((work / 'round5_checkpoint.json').read_text(encoding='utf-8'))['records'][0]

    def test_bom_and_browser_newlines_preserve_association(self):
        self.assertTrue(self.analyze()['eligible_for_recommendation'])

    def test_changed_source_and_review_are_rejected(self):
        for mode in ('mutated_source', 'wrong_review_hash', 'missing_submission_copy'):
            with self.subTest(mode=mode):
                self.assertFalse(self.analyze(mode)['eligible_for_recommendation'])

    def test_incomplete_or_duplicate_points_do_not_pass(self):
        for mode in ('duplicate_point', 'unfinished'):
            with self.subTest(mode=mode):
                self.assertFalse(self.analyze(mode)['all_pass'])


if __name__ == '__main__':
    unittest.main()
