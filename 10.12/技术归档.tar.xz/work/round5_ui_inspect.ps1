﻿param([string]$Filter='Button|Edit|Document|RadioButton|CheckBox')
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$taskRoot = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]5705316)
if (-not $taskRoot) { throw 'GitHub browser window not found' }
$taskElements = $taskRoot.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)
$taskItems = foreach($taskEl in $taskElements) {
    $taskInfo = $taskEl.Current
    if($taskInfo.ControlType.ProgrammaticName -match $Filter) {
        $taskRect = $taskInfo.BoundingRectangle
        [pscustomobject]@{type=$taskInfo.ControlType.ProgrammaticName;name=$taskInfo.Name;id=$taskInfo.AutomationId;enabled=$taskInfo.IsEnabled;offscreen=$taskInfo.IsOffscreen;x=$taskRect.X;y=$taskRect.Y;w=$taskRect.Width;h=$taskRect.Height}
    }
}
$taskItems | ConvertTo-Json -Depth 3
