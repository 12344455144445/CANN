from pathlib import Path
import hashlib,json,difflib
import numpy as np
R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
start=base.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
end=base.index('__global__',start)
body=base[start:end]
old='    TBuf<TPosition::VECCALC> correctionMaskBuffer;'
new=old+'\n    TBuf<TPosition::VECCALC> activationCacheBuffer;'
assert body.count(old)==1;body=body.replace(old,new)
old='    pipe.InitBuffer(correctionMaskBuffer, kPairCapacity / 8U);'
new=old+'\n    pipe.InitBuffer(activationCacheBuffer, kPairCapacity * sizeof(float));'
assert body.count(old)==1;body=body.replace(old,new)
old='    LocalTensor<float> retainedColumnScale;'
new=old+'''
    const bool cachePartitionActivation = n <= kVectorTileN &&
        rows <= kPairCapacity / QmqAlignUp(n, kFloatBlock);
    auto partitionActivation = activationCacheBuffer.Get<float>();'''
assert body.count(old)==1;body=body.replace(old,new)
split=body.index('    // [OPT-V80]');first=body[:split];second=body[split:]
old='                workspaceQueue.FreeTensor(inputLocal);'
new='''                if (cachePartitionActivation) {
                    DataCopy(partitionActivation[globalRow * alignedN], fp32Local, pairCount);
                    PipeBarrier<PIPE_V>();
                }
'''+old
assert first.count(old)==1;first=first.replace(old,new)
old='''        QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
            static_cast<uint64_t>(rowStart) * n + nOffset,
            currentN * QmqMinValue(rowBatchLimit, rows), alignedN * QmqMinValue(rowBatchLimit, rows));'''
new='''        if (!cachePartitionActivation) {
'''+''.join('    '+line for line in old.splitlines(True))+'''
        }'''
assert second.count(old)==1;second=second.replace(old,new)
old='                LocalTensor<int32_t> inputLocal = workspaceQueue.DeQue<int32_t>();'
new='''                LocalTensor<int32_t> inputLocal;
                if (cachePartitionActivation) { inputLocal = workspaceQueue.AllocTensor<int32_t>(); }
                else { inputLocal = workspaceQueue.DeQue<int32_t>(); }'''
assert second.count(old)==1;second=second.replace(old,new)
old='                if (globalRow + pairRows < rows) {'
new='                if (!cachePartitionActivation && globalRow + pairRows < rows) {'
assert second.count(old)==1;second=second.replace(old,new)
a=second.index('                Cast(fp32Local, inputLocal, RoundMode::CAST_RINT, pairCount);')
b=second.index('                // [OPT-V81]',a)
transform=second[a:b]
new='''                if (cachePartitionActivation) {
                    DataCopy(fp32Local, partitionActivation[globalRow * alignedN], pairCount);
                    PipeBarrier<PIPE_V>();
                } else {
'''+''.join('    '+line for line in transform.splitlines(True))+'''                }
'''
second=second[:a]+new+second[b:]
text=base[:start]+first+second+base[end:]
assert text[:start]==base[:start] and text[text.index('__global__',start):]==base[end:]
cases=0
for n in range(1,13001):
    stride=(n+7)//8*8
    for rows in (1,2,3,4,5,7,8,16,31,32,63,64,127,128,256,384,512,768,1024):
        cache=n<=6144 and rows<=6144//stride
        if cache:assert n<=6144 and stride*rows<=6144;cases+=1
rng=np.random.default_rng(1101012);values_checked=0
for n in (1,7,8,17,31,32,33,63,64,128,256,320,512,768,1024,1536,2048,3072,4096,6144):
    stride=(n+7)//8*8
    for rows in sorted({1,min(8,6144//stride),6144//stride}):
        vals=rng.integers(-30000000,30000001,(rows,n),dtype=np.int32)
        s1=rng.uniform(-2,2,(rows,1)).astype(np.float32);s2=rng.uniform(-2,2,(1,n)).astype(np.float32)
        vals[0]=0
        original=(vals.astype(np.float32)*s1)*s2
        cache=np.zeros((rows,stride),np.float32);cache[:,:n]=original
        got=np.maximum(cache[:,:n],np.float32(0))
        want=np.maximum((vals.astype(np.float32)*s1)*s2,np.float32(0))
        assert np.array_equal(got.view(np.uint32),want.view(np.uint32))
        values_checked+=rows*n
folder=R/'v110_partition_activation_cache_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code','change':'Cache complete local partition FP32 dequantized values when rows*align8(N)<=6144, including partitions with multiple row batches',
 'new_vs_prior':'v104 could retain only one batch; v70 changed scale division. This layout retains original vector scale division and two-pass output order',
 'extra_UB_bytes':24576,'conservative_peak_UB_bytes':195456,'device_UB_limit':196608,
 'queue_ownership':'Pass1 queue unchanged; cached Pass2 allocates/frees one scratch bank per batch without enqueuing GM reads',
 'partition_bounds_cases':cases,'CPU_bitwise_activation_values':values_checked,
 'precision_helpers_tiny_host_cube_unchanged':True,'device':'PENDING; close UB budget and compiler layout require actual device verification'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('完整本地行分区FP32驻留，包含多个原4行批量。新增24KiB UB，保守最大195456<196608。只有rows*align8(N)<=6144且单N块命中，其他回退。保留原尺度算法。15/15零错误与整体收益后复测，否则淘汰。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
