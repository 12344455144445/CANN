from pathlib import Path
import hashlib,json,difflib
R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
tiny=(R/'v95_latest_tinyvector_20261012/kernel.asc').read_text(encoding='utf-8')
scale=(R/'v103_vector_scale_copy_20261012/kernel.asc').read_text(encoding='utf-8')
old='''    PipeBarrier<PIPE_V>();

    for (uint32_t row = 0; row < rows; ++row) {
        yScaleLocal.SetValue(row, rowScaleLocal.GetValue(row));
    }
    yScaleQueue.EnQue(yScaleLocal);'''
new='''    // Publish scalar zero-row overrides before the UB vector copy.
    PipeBarrier<PIPE_ALL>();
    DataCopy(yScaleLocal, rowScaleLocal, alignedRows);
    PipeBarrier<PIPE_V>();
    yScaleQueue.EnQue(yScaleLocal);'''
assert tiny.count(old)==1 and scale==base.replace(old,new)
combined=tiny.replace(old,new)
assert combined.replace(new,old)==tiny
folder=R/'v105_tinyvector_scale_copy_20261012';folder.mkdir(exist_ok=True)
assert not (folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(combined,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'parents':['v95 tiny guarded postprocess (two 15/15 passes)','v103 y-scale UB copy (one 15/15 pass)'],
 'change':'Combine disjoint device-validated changes; not a claim that gains are additive',
 'scope':'Tiny function remains byte-identical to v95; general function differs only by exact v103 copy change',
 'UB_and_sync':'Unchanged allocation sizes; v103 PIPE_ALL before vector copy retained',
 'device':'PENDING combined compilation, correctness, performance'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(tiny.splitlines(True),combined.splitlines(True),fromfile='v95',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('组合互不重叠的v95 tiny向量后处理与v103行scale搬运。组合仍需设备验证，不能把父版本收益相加。15/15零错误并总体改善后复测，否则保留v95。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
