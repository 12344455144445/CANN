from pathlib import Path
import importlib.util,hashlib,json,re,difflib,unittest
import numpy as np

R=Path(__file__).resolve().parent
base=R/'v91_latest_control_20261012/kernel.asc'
source=base.read_text()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

folder=R/'v95_latest_tinyvector_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
b=load(R/'round5_repo/Codex Experiments/2026-10-11-v86/build_v86.py','tiny_build')
b.BASE=base;b.EXPECTED=hashlib.sha256(base.read_bytes()).hexdigest();b.ROOT=folder;b.build()
text=(folder/'v86/kernel.asc').read_text()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
t=load(R/'round5_repo/Codex Experiments/2026-10-11-v86/test_v86.py','tiny_tests')
t.ROOT=folder;t.BASE=base
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(t.Checks))
assert result.wasSuccessful()
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest GitHub code','change':'PR #3 guarded vector postprocessing ported to latest code, preserving current host launch and general cache/batching',
 'CPU_static_groups':4,'precision_helpers_general_cube_host_unchanged':True,'device':'PENDING'}
(folder/'review_checks.json').write_text(json.dumps(review,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='latest',tofile='tiny_vector')),encoding='utf-8')

folder=R/'v96_smallN_batch8_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
old='? QmqMinValue(4U, kPairCapacity / n) : 1U;'
new='? QmqMinValue(n <= 256U ? 8U : 4U, kPairCapacity / n) : 1U;'
assert source.count(old)==1
text=source.replace(old,new);assert text.replace(new,old)==source
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
configs=elements=0
for limit in (1,2,3,4,8):
    for rows in range(1,1025):
        queue=[(0,min(limit,rows))];seen=[]
        for group in range(0,rows,64):
            count=min(64,rows-group)
            for local in range(0,count,limit):
                start=group+local;take=min(limit,count-local);offset,loaded=queue.pop(0)
                assert offset==start and loaded>=take and offset+loaded<=rows
                if start+take<rows:queue.append((start+take,min(limit,rows-start-take)))
                seen.extend(range(start,start+take))
        assert seen==list(range(rows)) and not queue
        configs+=1
rng=np.random.default_rng(961012)
for n in (32,64,96,128,160,192,224,256):
    assert n*8<=6144 and n%32==0
    for rows in (1,2,3,4,5,7,8,9,15,16,17,63,64,65,127,129):
        ints=rng.integers(-30000000,30000001,(rows,n),dtype=np.int32)
        s1=rng.uniform(-2,2,rows).astype(np.float32);s2=rng.uniform(-2,2,n).astype(np.float32);ints[0]=0
        act=np.maximum((ints.astype(np.float32)*s1[:,None])*s2,np.float32(0));maxima=act.max(axis=1)
        scales=np.where(maxima>0,maxima/np.float32(127),np.float32(1));out=np.clip(np.rint(act/scales[:,None]),0,127).astype(np.int8)
        got=np.empty_like(out);gotmax=np.empty_like(maxima)
        for start in range(0,rows,8):
            end=min(start+8,rows);flat=ints[start:end].astype(np.float32).ravel()
            flat*=np.repeat(s1[start:end],n);flat*=np.tile(s2,end-start)
            flat=np.maximum(flat,np.float32(0)).reshape(end-start,n);gotmax[start:end]=flat.max(axis=1)
            got[start:end]=np.clip(np.rint(flat/scales[start:end,None]),0,127).astype(np.int8)
        assert np.array_equal(gotmax.view(np.uint32),maxima.view(np.uint32)) and np.array_equal(got,out)
        elements+=rows*n
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest GitHub code','only_change':'For aligned N32..256, batch up to8 instead of4; all other source byte-identical',
 'inverse_source_proof':True,'UB_allocations_unchanged':True,'queue_configurations':configs,'CPU_arithmetic_elements':elements,'device':'PENDING'}
(folder/'review_checks.json').write_text(json.dumps(review,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='latest',tofile='smallN_batch8')),encoding='utf-8')
for name in ('v95_latest_tinyvector_20261012','v96_smallN_batch8_20261012'):
    (R/name/'SUBMIT.md').write_text('预登记：15/15零错误为必要条件。使用本日控制T比较逐点耗时，增益超过0.16分且相关点多数变快才复测；其他单次差异仅记录。失败退回最新code，不把PR版本号与本地旧版本混同。',encoding='utf-8')
print('tiny vector and bounded eight-row batch candidates reviewed')
