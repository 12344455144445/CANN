from pathlib import Path
import hashlib,json,difflib
import numpy as np

R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
start=base.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
end=base.index('__global__',start)
body=base[start:end]
old='''    LocalTensor<float> retainedColumnScale;

    for (uint32_t nOffset'''
new='''    LocalTensor<float> retainedColumnScale;
    // One N tile and one row batch: retain the dequeued workspace UB bank.
    // Reuse its storage as FP32 activation; no additional UB is allocated.
    const bool retainActivation = n <= kVectorTileN && rows <= rowBatchLimit;
    LocalTensor<int32_t> retainedWorkspace;

    for (uint32_t nOffset'''
assert body.count(old)==1;body=body.replace(old,new)
first_end=body.index('    // [OPT-V80]')
first=body[:first_end];second=body[first_end:]
old='''                workspaceQueue.FreeTensor(inputLocal);'''
new='''                if (retainActivation) {
                    retainedWorkspace = inputLocal;
                    auto cachedActivation = inputLocal.ReinterpretCast<float>();
                    DataCopy(cachedActivation, fp32Local, pairCount);
                    PipeBarrier<PIPE_V>();
                    Maxs(cachedActivation, cachedActivation, 0.0f, pairCount);
                    PipeBarrier<PIPE_V>();
                } else {
                    workspaceQueue.FreeTensor(inputLocal);
                }'''
assert first.count(old)==1;first=first.replace(old,new)
old='''        QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
            static_cast<uint64_t>(rowStart) * n + nOffset,
            currentN * QmqMinValue(rowBatchLimit, rows), alignedN * QmqMinValue(rowBatchLimit, rows));'''
new='''        if (!retainActivation) {
            QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
                static_cast<uint64_t>(rowStart) * n + nOffset,
                currentN * QmqMinValue(rowBatchLimit, rows), alignedN * QmqMinValue(rowBatchLimit, rows));
        }'''
assert second.count(old)==1;second=second.replace(old,new)
old='''                LocalTensor<int32_t> inputLocal = workspaceQueue.DeQue<int32_t>();'''
new='''                LocalTensor<int32_t> inputLocal;
                if (retainActivation) { inputLocal = retainedWorkspace; }
                else { inputLocal = workspaceQueue.DeQue<int32_t>(); }'''
assert second.count(old)==1;second=second.replace(old,new)
transform_start=second.index('                Cast(fp32Local, inputLocal, RoundMode::CAST_RINT, pairCount);')
transform_end=second.index('                LocalTensor<float> activationLocal =',transform_start)
original_transform=second[transform_start:transform_end]
new_transform='''                if (retainActivation) {
                    DataCopy(fp32Local, retainedWorkspace.ReinterpretCast<float>(), pairCount);
                    PipeBarrier<PIPE_V>();
                } else {
'''+''.join('    '+line for line in original_transform.splitlines(True))+'''                }
'''
second=second[:transform_start]+new_transform+second[transform_end:]
text=base[:start]+first+second+base[end:]
assert text[:start]==base[:start]
assert text[text.index('__global__',start):]==base[end:]
# Queue ownership/bounds: retention is entered only for a single entire batch.
cases=0;float_cases=0;rng=np.random.default_rng(1041012)
for n in range(1,13001):
    limit=min(4,6144//n) if 32<=n<=3072 and n%32==0 else 1
    for rows in (1,2,3,4,5,8,16,32,64,128):
        retain=n<=6144 and rows<=limit
        if not retain:continue
        stride=(n+7)//8*8
        assert rows<=4 and rows<=64 and rows*stride<=6144
        assert rows==min(limit,rows)
        assert not (0+rows<rows)  # no next-batch prefetch remains outstanding
        cases+=1
for n in (1,7,8,17,31,32,64,127,128,256,511,512,1000,1536,2048,3072,4096,6144):
    limit=min(4,6144//n) if 32<=n<=3072 and n%32==0 else 1
    for rows in range(1,limit+1):
        for _ in range(8):
            values=rng.integers(-(2**24),2**24,(rows,n),dtype=np.int32)
            s1=rng.uniform(-2,2,(rows,1)).astype(np.float32)
            s2=rng.uniform(-2,2,(1,n)).astype(np.float32)
            # The FP32 products and their order are identical; copying is bitwise.
            first=(values.astype(np.float32)*s1)*s2
            cache=np.maximum(first,np.float32(0)).copy()
            repeated=np.maximum((values.astype(np.float32)*s1)*s2,np.float32(0))
            assert np.array_equal(cache.view(np.uint32),repeated.view(np.uint32))
            scale=np.where(np.maximum(first.max(axis=1),0)>0,np.maximum(first.max(axis=1),0)/np.float32(127),np.float32(1))
            got=np.clip(np.rint(cache/scale[:,None]),0,127).astype(np.int8)
            expected=np.clip(np.rint(repeated/scale[:,None]),0,127).astype(np.int8)
            assert np.array_equal(got,expected);float_cases+=1
folder=R/'v104_retain_single_batch_20261012';folder.mkdir(exist_ok=True)
assert not (folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code','change':'Retain one dequeued workspace UB bank as FP32 ReLU activation when the entire function fits one N tile and one row batch',
 'new_vs_historical':'Unlike whole-partition caches, adds no UB; unlike v70 onepass, retains original vector scale division, loop ordering and quantization algorithm',
 'eligible_shape_cases':cases,'CPU_bitwise_cases':float_cases,
 'queue_lifetime':'One alloc/enqueue/dequeue in Pass1, retained through scale calculation, no Pass2 enqueue/dequeue, original Pass2 FreeTensor releases once',
 'scratch_alias':'Scale calculation uses fp32/half/reduce/mask TBufs; retained workspaceQueue bank is disjoint',
 'extra_UB_bytes':0,'precision_helpers_unchanged':True,
 'device':'PENDING: CPU model is not a device/compiler or extreme-scale precision test'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('新布局：完整调用仅一N块一行批时，把已出队的workspace缓冲保留为FP32激活，不新增UB，不更换除127算法。跨尺度计算生命周期后直接量化，第二遍释放一次。原样回退其它形状。要求15/15零错误，整体提升后原样复测；CPU模型不能证明极端尺度及NPU正确性。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
