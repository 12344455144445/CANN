﻿param([Parameter(Mandatory=$true)][string]$CandidateFolder)
$ErrorActionPreference='Stop'
python '.\work\round5_ui_browser.py' copyurl
if($LASTEXITCODE -ne 0){throw 'Browser URL copy failed'}
$url=(Get-Clipboard -Raw).Trim()
$info=Get-Content -LiteralPath (Join-Path $CandidateFolder 'submission_info.json') -Raw -Encoding utf8 | ConvertFrom-Json
if($url -ne $info.url){throw 'Current page is not the intended submission'}
python '.\work\round5_ui_browser.py' click 600 225
if($LASTEXITCODE -ne 0){throw 'Page focus failed'}
python '.\work\round5_ui_browser.py' copyall
if($LASTEXITCODE -ne 0){throw 'Page copy failed'}
$resultText=Get-Clipboard -Raw
if($resultText -notmatch '提交 ID'){throw 'Copied text is not a submission result'}
@{url=$url;text=$resultText} | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $CandidateFolder 'platform_result.json') -Encoding utf8
$start=$resultText.IndexOf('执行结果')
if($start -ge 0){Write-Output $resultText.Substring($start)}else{Write-Output $resultText.Substring(0,[Math]::Min(400,$resultText.Length))}

