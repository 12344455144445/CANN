from pathlib import Path
import json, hashlib, difflib

R=Path(__file__).resolve().parent
base=(R/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='''    PipeBarrier<PIPE_V>();

    for (uint32_t row = 0; row < rows; ++row) {
        yScaleLocal.SetValue(row, rowScaleLocal.GetValue(row));
    }
    yScaleQueue.EnQue(yScaleLocal);'''
new='''    // Publish scalar zero-row overrides before the UB vector copy.
    PipeBarrier<PIPE_ALL>();
    DataCopy(yScaleLocal, rowScaleLocal, alignedRows);
    PipeBarrier<PIPE_V>();
    yScaleQueue.EnQue(yScaleLocal);'''
assert base.count(old)==1
candidate=base.replace(old,new)
assert candidate.replace(new,old)==base
assert 'pipe.InitBuffer(yScaleQueue, 1, alignedRows * sizeof(float));' in base
assert 'pipe.InitBuffer(rowScaleBuffer, alignedRows * sizeof(float));' in base
assert 'const uint32_t alignedRows = QmqAlignUp(rows, kFloatBlock);' in base
assert 'constexpr uint32_t kFloatBlock = 8' in base
for rows in range(1,1025):
    aligned=(rows+7)//8*8
    assert aligned*4%32==0 and aligned>=rows
folder=R/'v103_vector_scale_copy_20261012';folder.mkdir(exist_ok=True)
assert not (folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 latest code', 'change':'Replace per-row GetValue/SetValue y-scale staging with aligned UB DataCopy',
 'bounds':'Source and destination allocate alignedRows*4 bytes; copy alignedRows elements, GM writes only rows elements',
 'sync':'PIPE_ALL waits for scalar zero-row overrides before UB copy; PIPE_V and queue synchronize copy before MTE3',
 'numerical':'Bitwise transfer; division, zero-row override, quantization chain unchanged',
 'device':'PENDING: CPU checks validate sizes and unchanged source, not compiler/device execution'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('以一次UB DataCopy替换yScale逐行标量读写，保留数值计算与GM写出范围。PIPE_ALL确保零行标量修正可见。要求15/15零错误，再与控制版及复测比较性能。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
