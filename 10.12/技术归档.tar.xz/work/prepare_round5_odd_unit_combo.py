from pathlib import Path
import json,hashlib,difflib

root=Path(__file__).resolve().parent
base=(root/'v111_general_odd_cast_20261012/kernel.asc').read_text(encoding='utf-8')
old='constexpr auto kInt8MatmulConfig = CFG_MDL;'
new='''constexpr auto QmqOddUnitFlagConfig()
{
    auto config = CFG_MDL;
    config.enUnitFlag = true;
    return config;
}
constexpr auto kInt8MatmulConfig = QmqOddUnitFlagConfig();'''
assert base.count(old)==1
text=base.replace(old,new);assert text.replace(new,old)==base
folder=root/'v126_general_odd_unit_flag_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v111_general_odd_cast_20261012',
 'only_increment':'Enable Cube enUnitFlag on the unchanged tested general ODD postprocessor.',
 'component_evidence':'v111/v115 general ODD and v119 Cube UnitFlag each passed15/15 zero errors. Combined speed is not established by individual runs.',
 'exact_source_inverse':True,'precision_helpers_host_tiling_application_flags_unchanged':True,
 'hypothesis':'Combine two independently validated pipeline reductions; examine whether their late-point benefits coexist.',
 'performance_caution':'UnitFlag first-run overall estimate was below adjacent baseline despite several late-point gains; reject combination if whole15-point paired score does not improve.',
 'device':'PENDING; compile/runtime/performance need a separate combination run.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='v111',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('组合验证：基于通用ODD输出转换，只新增已单独15/15通过的Cube UnitFlag设置。两部分各自正确不代表组合有性能收益；需单独精度及相邻原版对照，未改善则回退。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
