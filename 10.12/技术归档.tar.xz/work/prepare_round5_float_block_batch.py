from pathlib import Path
import hashlib,json,difflib
import numpy as np

root=Path(__file__).resolve().parent
base=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='const uint32_t rowBatchLimit = (n >= 32U && n <= 3072U && n % 32U == 0U)'
new='const uint32_t rowBatchLimit = (n >= 32U && n <= 3072U && n % 8U == 0U)'
assert base.count(old)==1
text=base.replace(old,new);assert text.replace(new,old)==base

# Model raw continuous workspace DMA and whole-batch output, explicitly
# covering the newly admitted N=40/48/56/... without introducing row padding.
checks=0;values=0;overfetch=0
for n in range(32,3073,8):
    if n%32==0:continue
    batch=min(4,6144//n)
    assert n*4%32==0 and n*batch<=6144
    rows=129
    data=np.arange(rows*n,dtype=np.int32).reshape(rows,n)
    output=np.full((rows,n),-1,dtype=np.int32)
    queued=(0,min(batch,rows))
    for group in range(0,rows,64):
        for row in range(group,min(rows,group+64),batch):
            count=min(batch,min(rows,group+64)-row)
            assert queued[0]==row and queued[1]>=count,(n,queued,row,count)
            assert n*queued[1]<=6144
            raw=data.ravel()[row*n:(row+queued[1])*n]
            local=raw[:count*n].reshape(count,n)
            overfetch+=queued[1]-count
            assert np.array_equal(local,data[row:row+count])
            # FP32 per-row start is aligned; INT8 conversion is a flat pack,
            # and its tail DMA byte count covers each original GM element once.
            assert all((r*n*4)%32==0 for r in range(count))
            output.ravel()[row*n:(row+count)*n]=local.ravel()
            if row+count<rows:queued=(row+count,min(batch,rows-row-count))
            checks+=1;values+=count*n
    assert np.array_equal(output,data)

folder=root/'v121_fp32_aligned_batch_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91_latest_control_20261012','only_change':'Packed general row-batch alignment gate N%32==0 -> N%8==0; other limits and every operation unchanged.',
 'exact_source_inverse':True,'precision_and_operation_order_unchanged':True,'UB_allocations_unchanged':True,
 'alignment_proof':'INT32 DMA and each FP32 row start require 32 bytes, hence N divisible by8. HALF/INT8 conversion processes the entire contiguous batch from a single aligned base; output DMA is one block with compact rows, so no INT8 per-row UB pointer is used.',
 'new_N_CPU_queue_batches':checks,'new_N_CPU_packed_values':values,
 'prefetch_rows_ignored_at_group_tails':overfetch,
 'prefetch_tail_rule':'The existing prefetch may include extra rows across a64-row group boundary. Consumers use the valid prefix and requeue from the first unprocessed row; capacity and coverage are checked.',
 'edge_coverage':'Every newly admitted N=32..3072 step8 excluding multiples32; rows129 crosses both64-row prefetch boundaries and odd tails. Capacity/buffer source audit separately checks N=1..13000.',
 'not_applicable_to_padded_multiblock_output':'Padded per-row INT8 output keeps its 32-element stride requirement. N not divisible by8 stays on the original one-row path.',
 'device':'PENDING; offline alignment/layout proof cannot replace NPU compile/runtime precision and timing.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('独立按元素宽度重算对齐：行内地址只用于INT32/FP32，8元素即32B对齐；输出是整包转换及单块DataCopyPad，不按int8逐行寻址。因此允许N%8==0的紧凑合批，无额外padding、分配、指令或浮点重排。已验证所有新N与64行边界、尾行。硬件15点待测。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
