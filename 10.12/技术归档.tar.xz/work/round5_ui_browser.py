import ctypes
import json
import pathlib
import sys
import time
from PIL import ImageGrab

user32 = ctypes.windll.user32
hwnd = 5705316
def focus_browser():
    if not user32.IsWindow(hwnd):
        raise RuntimeError('Confirmed browser window no longer exists')
    if user32.GetForegroundWindow()==hwnd:
        return
    current_thread = ctypes.windll.kernel32.GetCurrentThreadId()
    browser_thread = user32.GetWindowThreadProcessId(hwnd, None)
    for attempt in range(8):
        foreground = user32.GetForegroundWindow()
        foreground_thread = user32.GetWindowThreadProcessId(foreground, None)
        attached=[]
        for thread in set((foreground_thread,browser_thread)):
            if thread and thread != current_thread:
                if user32.AttachThreadInput(current_thread,thread,True):
                    attached.append(thread)
        try:
            user32.ShowWindow(hwnd,9)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
            user32.SetActiveWindow(hwnd)
        finally:
            for thread in attached:
                user32.AttachThreadInput(current_thread,thread,False)
        time.sleep(0.08)
        if user32.GetForegroundWindow()==hwnd:
            return
    raise RuntimeError('CANNJudge browser did not receive focus; no keys sent')

focus_browser()
def keys(*codes):
    focus_browser()
    for code in codes:
        user32.keybd_event(code, 0, 0, 0)
    time.sleep(0.1)
    for code in reversed(codes):
        user32.keybd_event(code, 0, 2, 0)

def type_unicode(text):
    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]
    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong), ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]
    class INPUTUNION(ctypes.Union):
        _fields_ = [('ki', KEYBDINPUT), ('mi', MOUSEINPUT)]
    class INPUT(ctypes.Structure):
        _anonymous_ = ('u',)
        _fields_ = [('type', ctypes.c_ulong), ('u', INPUTUNION)]
    events=[]
    encoded=text.encode('utf-16-le')
    for offset in range(0,len(encoded),2):
        code=int.from_bytes(encoded[offset:offset+2],'little')
        for flags in (4, 6):
            events.append(INPUT(type=1,ki=KEYBDINPUT(0,code,flags,0,0)))
    focus_browser()
    items=(INPUT*len(events))(*events)
    written=user32.SendInput(len(events),ctypes.byref(items),ctypes.sizeof(INPUT))
    if written!=len(events):
        raise RuntimeError('Incomplete browser text input; no submit action sent')
    time.sleep(0.15)

if sys.argv[1] == 'console':
    keys(0x7B)
    time.sleep(1)
elif sys.argv[1] == 'eval':
    keys(0x11, 0x10, 0x4A)
    time.sleep(0.5)
    keys(0x11, 0x41)
    keys(0x11, 0x56)
    time.sleep(0.3)
    keys(0x0D)
    time.sleep(1)
elif sys.argv[1] == 'paste':
    keys(0x11, 0x56)
    time.sleep(0.3)
    keys(0x0D)
    time.sleep(1.5)
elif sys.argv[1] == 'type':
    type_unicode(sys.argv[2])
    keys(0x0D)
    time.sleep(0.5)
elif sys.argv[1] in ('copyall', 'replaceall'):
    keys(0x11, 0x41)
    keys(0x11, 0x43 if sys.argv[1] == 'copyall' else 0x56)
    time.sleep(0.8)
elif sys.argv[1] == 'input':
    keys(0x11, 0x41)
    type_unicode(sys.argv[2])
    keys(0x0D)
    time.sleep(1.5)
elif sys.argv[1] == 'navigate':
    keys(0x12, 0x44)
    type_unicode(sys.argv[2])
    keys(0x0D)
    time.sleep(2)
elif sys.argv[1] == 'newtab':
    keys(0x11, 0x54)
    type_unicode(sys.argv[2])
    keys(0x0D)
    time.sleep(2)
elif sys.argv[1] == 'closetab':
    keys(0x11, 0x57)
    time.sleep(0.5)
elif sys.argv[1] == 'snapshot':
    pass
elif sys.argv[1] == 'copyurl':
    keys(0x12, 0x44)
    keys(0x11, 0x41)
    keys(0x11, 0x43)
    time.sleep(0.4)
    keys(0x1B)
elif sys.argv[1] == 'home':
    keys(0x1B)
    keys(0x11, 0x24)
    time.sleep(0.8)
elif sys.argv[1] == 'enter':
    keys(0x0D)
    time.sleep(1.5)
elif sys.argv[1] == 'click':
    focus_browser()
    user32.SetCursorPos(int(sys.argv[2]), int(sys.argv[3]))
    user32.mouse_event(2, 0, 0, 0, 0)
    user32.mouse_event(4, 0, 0, 0, 0)
    time.sleep(0.8)
ImageGrab.grab().save(str(pathlib.Path(__file__).with_name('round5_ui_latest.png')))
