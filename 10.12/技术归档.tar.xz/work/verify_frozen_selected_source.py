"""Independent structural checks of the published, frozen kernel; no source edits."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
baseline_path = root / 'v91_latest_control_20261012/kernel.asc'
selected_path = root / 'v124_scale_output_bank_20261012/kernel.asc'
baseline = baseline_path.read_text(encoding='utf-8')
selected = selected_path.read_text(encoding='utf-8')

def split_function(text, signature):
    start = text.index(signature)
    opening = text.index('{', start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[:start], text[start:end], text[end:]

signature = '__aicore__ inline void quant_matmul_relu_quant_vector('
# Some versions declare the same function without inline; use its actual prefix.
if signature not in baseline:
    line = next(line for line in baseline.splitlines() if 'void quant_matmul_relu_quant_vector(' in line)
    signature = line
before, original_function, after = split_function(baseline, signature)
new_before, function, new_after = split_function(selected, signature)
assert before == new_before and after == new_after, 'Changes escaped the vector function'
assert 'rowScaleBuffer' not in function
assert function.count('yScaleQueue.AllocTensor<float>()') == 1
assert function.count('yScaleQueue.FreeTensor(yScaleLocal)') == 1
allocation = function.index('rowScaleLocal = yScaleQueue.AllocTensor<float>()')
scale_computation = function.index('QmqCorrectDiv(', allocation)
zero_override = function.index('rowScaleLocal.SetValue(row, 1.0f)', scale_computation)
enqueue = function.index('yScaleQueue.EnQue(yScaleLocal)', zero_override)
dequeue = function.index('yScaleQueue.DeQue<float>()', enqueue)
copy = function.index('DataCopyPad(yScaleGm[rowStart]', dequeue)
release = function.index('yScaleQueue.FreeTensor(yScaleLocal)', copy)
scale_reads = [m.start() for m in re.finditer(r'rowScaleLocal.GetValue\(', function)]
assert scale_reads and all(copy < offset < release for offset in scale_reads)
assert not re.search(r'rowScaleLocal.SetValue\(', function[enqueue:release])
assert allocation < scale_computation < zero_override < enqueue < dequeue < copy < release
assert 'Cast(halfLocal, fp32Local, RoundMode::CAST_ODD, pairCount)' in function
assert 'Cast(outputLocal, halfLocal, RoundMode::CAST_RINT, pairCount)' in function
assert function.count('Compares(correctionMaskLocal, residualLocal, kHalfScreenTolerance') == original_function.count('Compares(correctionMaskLocal, residualLocal, kHalfScreenTolerance')
blob = selected_path.read_bytes()
assert hashlib.sha256(blob).hexdigest() == '4010bfbbb0f4d1be969556db956cebad2de65b7784bb5a9da55b57ea25338574'
git_blob = hashlib.sha1(('blob ' + str(len(blob))).encode() + bytes([0]) + blob).hexdigest()
assert git_blob == '94eabc5bdcc9dff908f682198fa5fc5a40daaf95'
result = {'source_sha256': hashlib.sha256(blob).hexdigest(), 'git_blob': git_blob,
          'outside_vector_function_byte_identical': True, 'queue_lifetime_order_pass': True,
          'submitted_four_times': True, 'limitation': 'Structural checks supplement the four independent device executions; they do not emulate NPU synchronization.'}
(root / 'selected_source_structure.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
