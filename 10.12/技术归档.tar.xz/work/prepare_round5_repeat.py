"""Create an immutable repeat from a reviewed, completed device result."""
from pathlib import Path
import json,hashlib,sys

root=Path(__file__).resolve().parent
source=(root/sys.argv[1]).resolve()
target=(root/sys.argv[2]).resolve()
assert source.parent==root and target.parent==root and source!=target
assert not target.exists(),'Refuse to overwrite a prepared/submitted candidate'
review=json.loads((source/'review_checks.json').read_text(encoding='utf-8-sig'))
device=json.loads((source/'hardware_validation.json').read_text(encoding='utf-8-sig'))
data=(source/'kernel.asc').read_bytes()
digest=hashlib.sha256(data).hexdigest()
assert review.get('review_pass') and review['sha256']==digest
assert device.get('all_pass') and device.get('eligible_for_recommendation') and device['sha256']==digest
target.mkdir()
(target/'kernel.asc').write_bytes(data)
review.update({'repeat_source':source.name,'exact_bytes_repeated':True,
              'repeat_purpose':'Adjacent control/candidate device run to separate timing drift from code changes.',
              'repeat_device':'PENDING; original source passed all15 points, this submission needs its own result.'})
(target/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(target/'SUBMIT.md').write_text(f'原样复测：{source.name}；SHA256 {digest}。保持源码每个字节不变，记录独立15点评测，不使用队伍榜单归因。\n',encoding='utf-8')
plan_path=root/'round5_plan.json'
plan=json.loads(plan_path.read_text(encoding='utf-8-sig'))
plan['variants']=sorted(set(plan['variants']+[target.name]))
plan_path.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'repeat':target.name,'source':source.name,'sha256':digest},ensure_ascii=False))
