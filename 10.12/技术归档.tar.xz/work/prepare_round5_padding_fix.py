from pathlib import Path
import hashlib,json,re,difflib
import numpy as np

R=Path(__file__).resolve().parent
parent=R/'v94_latest_padded_20261012/kernel.asc'
source=parent.read_text()
old='const bool paddedBatch = n >= 64U && n <= 3072U && n % 32U != 0U;'
new='const bool paddedBatch = n >= 32U && n <= 3072U && n % 32U != 0U;'
assert source.count(old)==1
fixed=source.replace(old,new);assert fixed.replace(new,old)==source

old_helper='''        // DMA pads only to 8 int32 elements. Initialize the additional row gap.
        Duplicate(input, static_cast<int32_t>(0), alignedCount);
        PipeBarrier<PIPE_ALL>();
        const uint32_t rowN = count / paddedRows;
        const uint32_t naturalStride = QmqAlignUp(rowN, kFloatBlock);'''
new_helper='''        // DMA writes real values and the natural align8 padding.
        // Initialize only the remaining align32 gap in each UB row.
        const uint32_t rowN = count / paddedRows;
        const uint32_t naturalStride = QmqAlignUp(rowN, kFloatBlock);
        if (rowStride > naturalStride) {
            for (uint32_t r = 0; r < paddedRows; ++r) {
                Duplicate(input[r * rowStride + naturalStride],
                    static_cast<int32_t>(0), rowStride - naturalStride);
            }
            PipeBarrier<PIPE_ALL>();
        }'''
assert fixed.count(old_helper)==1
gap=fixed.replace(old_helper,new_helper)
# Initialize only the scale's non-DMA gap, leaving real lanes for DataCopyPad.
pattern=r'(?P<i> *)Duplicate\(x2ScaleLocal, 0\.0f, alignedN\);\n(?P=i)PipeBarrier<PIPE_ALL>\(\);'
def replace_scale(m):
    i=m['i']
    return '\n'.join([i+'const uint32_t naturalScaleN = QmqAlignUp(currentN, kFloatBlock);',i+'if (alignedN > naturalScaleN) {',i+'    Duplicate(x2ScaleLocal[naturalScaleN], 0.0f, alignedN - naturalScaleN);',i+'    PipeBarrier<PIPE_ALL>();',i+'}'])
gap,count=re.subn(pattern,replace_scale,gap);assert count==2
variants={'v97_corrected_padded_20261012':fixed,'v98_padding_gap_only_20261012':gap}

# Bind the packing route to the actual source expressions, including N33..63.
def parse(expression):
    return re.sub(r'(\d+)U',r'\1',expression).replace('&&',' and ').replace('||',' or ')
rng=np.random.default_rng(981012)
case_count=0
for name,text in variants.items():
    gate=re.search(r'const bool paddedBatch = (.*);',text).group(1)
    assert re.search(r'const uint32_t rowBatchLimit = \(n >= 32U && n <= 3072U\)',text)
    for n in range(1,13001):
        padded=bool(eval(parse(gate),{'__builtins__':{}},{'n':n}))
        stride=(n+31)//32*32 if padded else n
        limit=min(4,6144//stride) if 32<=n<=3072 else 1
        if limit>1:
            assert stride%32==0 and (n%32==0 or padded)
        if padded:
            assert stride*limit<=6144 and (stride-(n+7)//8*8)%8==0
    for n in list(range(1,97))+[127,255,511,513,999,1000,1023,1535,2047,2049,3071,3072,3073,6144,6145]:
        padded=bool(eval(parse(gate),{'__builtins__':{}},{'n':n}))
        if not padded:continue
        stride=(n+31)//32*32; natural=(n+7)//8*8
        for rows in (1,2,3,4):
            count=min(rows,min(4,6144//stride))
            values=rng.integers(-30000000,30000001,(count,n),dtype=np.int32)
            # Simulate gap-only fill, then MTE2's real values and explicit pad.
            ub=np.full((count,stride),-123456789,dtype=np.int32)
            ub[:,natural:stride]=0;ub[:,:n]=values;ub[:,n:natural]=0
            whole=np.zeros((count,stride),dtype=np.int32);whole[:,:n]=values
            assert np.array_equal(ub,whole)
            s1=rng.uniform(-2,2,count).astype(np.float32);s2=rng.uniform(-2,2,n).astype(np.float32)
            x2=np.full(stride,np.nan,np.float32);x2[natural:]=0;x2[:n]=s2;x2[n:natural]=0
            got=np.maximum((ub.astype(np.float32)*s1[:,None])*x2,0)
            want=np.maximum((values.astype(np.float32)*s1[:,None])*s2,0)
            assert np.array_equal(got[:,:n].view(np.uint32),want.view(np.uint32))
            assert np.array_equal(got.max(axis=1).view(np.uint32),want.max(axis=1).view(np.uint32))
            case_count+=1
    folder=R/name;folder.mkdir(exist_ok=True);assert not(folder/'submission_attempt.json').exists()
    (folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
    review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
     'base':'latest code with PR padded layout; v94 quarantined due to N33..63 gate omission',
     'change':'Correct padded gate to N>=32'+('; fill only non-DMA row gaps' if name.startswith('v98') else ''),
     'actual_gate_bound_layout_N_cases':13000,'layout_arithmetic_cases':case_count,
     'precision_helpers_tiny_host_cube_unchanged':True,'UB_allocations_unchanged':True,
     'gap_only_safety':'natural row/pad overwritten by MTE2, extra gap zeroed by Vector before queue enqueue; all gap addresses are 32-byte aligned',
     'device':'PENDING; CPU model does not establish device correctness'}
    (folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
    comparison=source if name.startswith('v97') else fixed
    (folder/'source.diff').write_text(''.join(difflib.unified_diff(comparison.splitlines(True),text.splitlines(True),fromfile='parent',tofile=name)),encoding='utf-8')
    (folder/'SUBMIT.md').write_text('预登记：15/15零错误为必要条件；v97先验证边界修正，v98单独验证仅清零gap。使用同窗口控制对照，保留所有候选及错误。N33..63纳入源码门控与布局检查，禁止用15点全通过推断全域正确。',encoding='utf-8')
    print(name,review['sha256'])
