from pathlib import Path
import importlib.util,json,hashlib,re

R=Path(__file__).resolve().parent
builder=R/'round5_repo/Codex Experiments/2026-10-11-v83-v85/build_candidates.py'
spec=importlib.util.spec_from_file_location('pr_padded',builder)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
latest=(R/'v91_latest_control_20261012/kernel.asc').read_text()
v84=(R/'v84_n32_batch4_20261011/kernel.asc').read_text()
assert v84.count('n >= 32U && n <= 3072U && n % 32U == 0U')==1
source=mod.padded_batch(v84.replace('n >= 32U && n <= 3072U && n % 32U == 0U','n >= 64U && n <= 3072U && n % 32U == 0U'))
source=source.replace('const uint32_t rowBatchLimit = (n >= 64U && n <= 3072U)','const uint32_t rowBatchLimit = (n >= 32U && n <= 3072U)')
out=R/'v94_latest_padded_20261012';out.mkdir(exist_ok=True)
assert not(out/'submission_attempt.json').exists()
# Reapply the reviewed two-pass cache transform to the padded source.
program=(R/'operator_schemes/prepare_qmq_scale_reuse.py').read_text()
program=program[program.index('begin = source.index'):program.index('# Verify that the modification')]
scope={'source':source,'out':out,'difflib':__import__('difflib')}
exec(program,scope)
text=scope['candidate'].replace('const bool reuseColumnScale = n <= 3072U;','const bool reuseColumnScale = n <= kVectorTileN;').replace('// N<=3072 guarantees one N tile;','// N<=6144 guarantees one N tile;')
(out/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
def fn(s,name):
    opening=s.index('{',s.index(name+'('));end=opening+1;d=1
    while d:d+=(s[end]=='{')-(s[end]=='}');end+=1
    return s[opening:end]
unchanged=['QmqQuantizeNearHalf','QmqDiv','QmqCorrectDiv','QmqScaleBy127Exact','QmqTryTinyDirect','QmqComputeTinyC','quant_matmul_relu_quant_cube','quant_matmul_relu_quant_fused','qmq_tiny_vector_entry','run_kernel']
assert all(fn(text,n)==fn(latest,n) for n in unchanged)
assert re.findall(r'pipe.InitBuffer\([^;]+;',text)==re.findall(r'pipe.InitBuffer\([^;]+;',latest)
vector=fn(text,'quant_matmul_relu_quant_vector')
assert 'const bool reuseColumnScale = n <= kVectorTileN;' in vector
assert 'const uint32_t rowBatchLimit = (n >= 32U && n <= 3072U)' in vector
assert 'const bool paddedBatch = n >= 64U && n <= 3072U && n % 32U != 0U;' in vector
assert vector.count('if (!reuseColumnScale) { x2ScaleQueue.FreeTensor(x2ScaleLocal); }')==2
assert vector.count('if (reuseColumnScale) { x2ScaleQueue.FreeTensor(retainedColumnScale); }')==1
assert vector.count('nextRows, paddedBatch ? alignedN : 0U')==2
assert 'paddedBatch ? currentN : currentN * pairRows' in vector
review={'review_pass':True,'sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91 GitHub latest code','change':'PR #2/#4 padded general batching ported while preserving latest N=32 batch gate and N<=6144 column-scale reuse',
 'unchanged_functions':unchanged,'UB_allocations_unchanged':True,
 'source_contracts':'PASS; actual DMA padding, output strides, queue ownership and tiny/host scopes bound to generated source',
 'CPU_layout_checks':'PR padded tests 5 groups passed; no NPU proof',
 'device':'PENDING'}
(out/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'source.diff').write_text(''.join(__import__('difflib').unified_diff(latest.splitlines(True),text.splitlines(True),fromfile='latest_code',tofile='latest_padded')),encoding='utf-8')
(out/'SUBMIT.md').write_text('预登记：保持最新code的tiny、Cube、host及列尺度缓存。仅扩展N64..3072非32对齐列的打包；15/15和零错误为必要条件。逐点及统一T分数对照控制；单次微小变化不作为稳定提升证据。若过慢或精度失败回到最新code。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
