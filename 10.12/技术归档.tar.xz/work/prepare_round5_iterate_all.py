from pathlib import Path
import hashlib,json,difflib

root=Path(__file__).resolve().parent
base=(root/'v91_latest_control_20261012/kernel.asc').read_text(encoding='utf-8')
old='constexpr auto kInt8MatmulConfig = CFG_MDL;'
new='''constexpr auto QmqIterateAllConfig()
{
    auto config = CFG_MDL;
    config.iterateMode = decltype(config.iterateMode)::ITERATE_MODE_ALL;
    return config;
}
constexpr auto kInt8MatmulConfig = QmqIterateAllConfig();'''
assert base.count(old)==1
text=base.replace(old,new);assert text.replace(new,old)==base
assert base.count('matmulObj.IterateAll(')==1
assert not any(x in base for x in ('matmulObj.Iterate(','matmulObj.IterateBatch(','matmulObj.IterateNBatch('))
folder=root/'v123_cube_iterate_all_20261012';folder.mkdir(exist_ok=True)
assert not(folder/'submission_attempt.json').exists()
(folder/'kernel.asc').write_text(text,encoding='utf-8',newline='\n')
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
 'base':'v91_latest_control_20261012','only_change':'Copy CFG_MDL and set iterateMode=ITERATE_MODE_ALL.',
 'exact_source_inverse':True,'device_function_text_host_tiling_precision_and_flags_byte_identical':True,
 'actual_API_call_inventory':'One matmulObj.IterateAll call site in the Cube loop. No Iterate/IterateBatch/IterateNBatch calls. Keep Init, SetTail, SetOrgShape, and End enabled.',
 'API_source':'https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0616.html',
 'API_evidence':'Atlas A3 supports iterateMode. ITERATE_MODE_ALL specializes the API for programs that call only IterateAll.',
 'hypothesis':'Reduce library iteration/header overhead by specializing the only iteration API actually used.',
 'device':'PENDING; library implementation/code-size and runtime effect require compilation and device timing.'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='latest',tofile=folder.name)),encoding='utf-8')
(folder/'SUBMIT.md').write_text('独立优化Matmul库迭代配置：当前Cube只调用IterateAll，设置官方支持的ITERATE_MODE_ALL；其余配置、host划分、尾块、所有设备函数与精度链保持一致。收益和正确性待设备验证。',encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
