"""Prepare an isolated, unsubmitted vector replacement for per-row zero-scale writes."""
from pathlib import Path
import difflib
import hashlib
import json
import numpy as np

root = Path(__file__).resolve().parent
base = (root / 'v124_scale_output_bank_20261012/kernel.asc').read_text(encoding='utf-8')
old = '''    for (uint32_t row = 0; row < rows; ++row) {
        if (rowMaxLocal.GetValue(row) <= 0.0f) {
            rowScaleLocal.SetValue(row, 1.0f);
        }
    }'''
new = '''    if (rows >= 64U && alignedRows % 64U == 0U) {
        // The count API requires a full 256-byte FP32 comparison block.
        Compares(scaleMaskLocal, rowMaxLocal, 0.0f, CMPMODE::LE, alignedRows);
        PipeBarrier<PIPE_V>();
        // Row maxima are dead after this comparison; reuse the bank as ones.
        Duplicate(rowMaxLocal, 1.0f, alignedRows);
        PipeBarrier<PIPE_V>();
        Select(rowScaleLocal, scaleMaskLocal, rowMaxLocal, rowScaleLocal,
               SELMODE::VSEL_TENSOR_TENSOR_MODE, alignedRows);
    } else {
        for (uint32_t row = 0; row < rows; ++row) {
            if (rowMaxLocal.GetValue(row) <= 0.0f) {
                rowScaleLocal.SetValue(row, 1.0f);
            }
        }
    }'''
assert base.count(old) == 1
source = base.replace(old, new)
assert source.replace(new, old) == base
assert 'rowMaxLocal' not in source[source.index(new) + len(new):]
assert source.count('pipe.InitBuffer(') == base.count('pipe.InitBuffer(')

rng = np.random.default_rng(1331012)
special = np.asarray([0., -0., 1., -1., np.nextafter(np.float32(0), np.float32(1)), np.inf, -np.inf, np.nan], dtype=np.float32)
elements = vector_cases = 0
for rows in range(1, 1025):
    aligned = (rows + 7) // 8 * 8
    maximum = np.zeros(aligned, dtype=np.float32)
    maximum[:rows] = rng.integers(0, 2**32, rows, dtype=np.uint32).view(np.float32)
    maximum[:min(rows, len(special))] = special[:min(rows, len(special))]
    scales = rng.integers(0, 2**32, aligned, dtype=np.uint32).view(np.float32)
    expected = scales.copy()
    with np.errstate(invalid='ignore'):
        for row in range(rows):
            if maximum[row] <= np.float32(0):
                expected[row] = np.float32(1)
        if rows >= 64 and aligned % 64 == 0:
            assert aligned * 4 % 256 == 0 and aligned <= 1024
            assert (aligned + 7) // 8 <= 6144 // 8
            actual = np.where(maximum <= np.float32(0), np.float32(1), scales)
            vector_cases += 1
        else:
            actual = expected.copy()
    assert np.array_equal(actual[:rows].view(np.uint32), expected[:rows].view(np.uint32)), rows
    elements += rows

folder = root / 'v133_vector_zero_scale_20261012'
folder.mkdir(exist_ok=True)
assert not (folder / 'submission_attempt.json').exists()
(folder / 'kernel.asc').write_text(source, encoding='utf-8', newline='\n')
review = {
    'review_pass': True, 'sha256': hashlib.sha256((folder / 'kernel.asc').read_bytes()).hexdigest(),
    'base': 'v124_scale_output_bank_20261012', 'exact_source_inverse': True,
    'only_change': 'Replace scalar zero-row override with LE comparison, dead-rowMax bank filled with ones and Select mode2, only for256-byte-aligned comparison lengths and rows>=64; retain exact scalar path otherwise.',
    'CPU_row_counts': 1024, 'CPU_vector_dispatch_cases': vector_cases, 'CPU_logical_row_values': elements,
    'CPU_scope': 'IEEE selection model includes signed zero, subnormal, infinity and NaN bit payloads. It does not prove NPU nonfinite comparison behavior.',
    'CMP_count_byte_alignment': 256, 'existing_mask_capacity_bytes': 768,
    'Select_alias_proof': 'dst and src1 are identical for each iteration; consecutive iterations use disjoint elements. No partial or cross-iteration overlap.',
    'rowMax_bank_last_use_proved': True, 'UB_explicit_peak_bytes': 166784,
    'Select_existing_API_reserve_bytes': 8192, 'UB_total_with_API_reserve_bytes': 174976,
    'source_API': [
        'https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0068.html',
        'https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0070.html',
        'https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0004.html',
    ],
    'device': 'NOT SUBMITTED; no CANN compile, NPU correctness or performance claim. Automatic device submission held to preserve the10 remaining daily attempts.',
}
(folder / 'review_checks.json').write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding='utf-8')
(folder / 'source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True), source.splitlines(True), fromfile='v124', tofile=folder.name)), encoding='utf-8')
(folder / 'SUBMIT.md').write_text('独立向量化候选，尚未提交：仅在 rows>=64 且 alignedRows 为64倍数时，将零行尺度覆盖转为 Compares(LE)+Duplicate+Select。复用已经结束生命周期的 rowMaxBuffer，不新增分配。比较count严格满足256B约束，保留所有其他长度的原标量逻辑。Select原有8KB临时预留已纳入，总资源174976B。CPU检查不代表NPU验证或性能提升；当天已用40次，保留10次。', encoding='utf-8')
plan_path = root / 'round5_plan.json'
plan = json.loads(plan_path.read_text(encoding='utf-8'))
if folder.name not in plan['variants']:
    plan['variants'].append(folder.name)
plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'candidate': folder.name, 'sha256': review['sha256'], 'CPU_vector_cases': vector_cases, 'CPU_rows': elements, 'submitted': False}))
