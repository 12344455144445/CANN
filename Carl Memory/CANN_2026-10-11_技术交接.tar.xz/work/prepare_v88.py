from pathlib import Path
import json,hashlib,difflib
from datetime import datetime
import numpy as np

root=Path(__file__).resolve().parent
base=root/'v84_n32_batch4_20261011';folder=root/'v88_float_floor_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source=(base/'kernel.asc').read_text(encoding='utf-8')
old='''                LocalTensor<int32_t> floorLocal = scratchLocal.ReinterpretCast<int32_t>();
                Cast(floorLocal, fp32Local, RoundMode::CAST_FLOOR, pairCount);
                PipeBarrier<PIPE_V>();
                Cast(residualLocal, floorLocal, RoundMode::CAST_NONE, pairCount);
                PipeBarrier<PIPE_V>();'''
new='''                // A3 supports fp32->fp32 FLOOR. Finite normalized values have
                // an exactly representable integer floor; keep the original
                // half-screen arithmetic and final int32 RINT conversion.
                Cast(residualLocal, fp32Local, RoundMode::CAST_FLOOR, pairCount);
                PipeBarrier<PIPE_V>();'''
assert source.count(old)==1
candidate=source.replace(old,new,1)
assert candidate.replace(new,old,1)==source
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v84/kernel.asc',tofile='v88/kernel.asc')),encoding='utf-8')

# Independent edge check of the screening predicate, not just final quantization.
# Every half threshold has seven neighboring fp32 patterns, covering the exact
# correction window; random values include subnormal quotients and signed zeros.
rng=np.random.default_rng(88020261011)
threshold=np.arange(0,256,dtype=np.float32)+np.float32(0.5)
words=threshold.view(np.uint32)
near=np.concatenate([(words.astype(np.int64)+d).astype(np.uint32).view(np.float32) for d in (-3,-2,-1,0,1,2,3)])
samples=np.concatenate([near,rng.uniform(0,256,1048576).astype(np.float32),
    np.array([0,0x80000000,1,0x007fffff,0x00800000],dtype=np.uint32).view(np.float32)])
old_floor=np.floor(samples).astype(np.int32).astype(np.float32)
new_floor=np.floor(samples).astype(np.float32)
old_residual=np.abs(samples-(old_floor+np.float32(0.5)))
new_residual=np.abs(samples-(new_floor+np.float32(0.5)))
assert np.array_equal(old_residual.view(np.uint32),new_residual.view(np.uint32))
assert np.array_equal(old_residual<np.float32(0.00002),new_residual<np.float32(0.00002))
# Nonfinite quotients are screened out in both chains. The original approximate
# quotient is never changed, so the subsequent clamp/RINT and correction guard
# retain their behavior. NaN reduction results force screening, never skipping it.
special=np.array([np.inf,np.nan],dtype=np.float32)
with np.errstate(all='ignore'):
    old_special=np.abs(special-(np.array([2147483647,-2147483648],dtype=np.int32).astype(np.float32)+np.float32(0.5)))
    new_special=np.abs(special-(np.floor(special)+np.float32(0.5)))
assert not np.any(old_special<np.float32(0.00002))
assert not np.any(new_special<np.float32(0.00002))
report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':base.name,'only_live_change':'Replace floor int32 cast + integer-to-float cast with supported fp32-to-fp32 FLOOR for half-screen residual',
    'all_other_source_identical':True,'all_UB_allocations_unchanged':True,
    'precision_helpers_division_threshold_predicate_and_final_RINT_unchanged':True,
    'tiny_cube_host_shape_flags_unchanged':True,
    'normalized_finite_floor_bound':'For positive normal scale, ratio is near127; for rounded positive subnormal scale, ratio<=190 plus division approximation. Every floor fits int32 and fp32 exactly.',
    'zero_scale_or_nonfinite_quotient':'Original quotient unchanged; inf/NaN residual fails LT screen in both paths; QmqQuantizeNearHalf rejects nonfinite/out-of-range approximations; clamp/RINT unchanged',
    'half_screen_bitwise_matches':len(samples),'CPU_screen_status':'PASS',
    'official_source':'https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0073.html',
    'official_support':'Table7 A3 fp32->fp32 supports CAST_FLOOR; A3 direct fp32->int8 is absent, so output conversions retained',
    'hardware_validation':'NOT RUN; hardware FP32 floor and special-value reduction behavior require platform validation',
    'performance_hypothesis':'Remove one conversion and one dependency in every general-vector half-screen batch'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder.name,phase='v87 passed but slower; reject; reviewed single-fp32-floor screening optimization from best v84',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
