from pathlib import Path
import hashlib,json,re,difflib
from datetime import datetime
import numpy as np

root=Path(__file__).resolve().parent
base=root/'v84_n32_batch4_20261011';folder=root/'v87_reuse_capacity8192_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source=(base/'kernel.asc').read_text(encoding='utf-8')
start=source.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
end=source.index('__global__ __mix__(1, 2) void quant_matmul_relu_quant_fused(',start)
vector=source[start:end]
changes=[
 ('constexpr uint32_t kPairCapacity = 6144;', 'constexpr uint32_t kPairCapacity = 8192;\n    constexpr uint32_t kReduceScratchCount = 2048U;'),
 ('(n >= 32U && n <= 3072U && n % 32U == 0U)', '(n >= 32U && n <= 4096U && n % 32U == 0U)'),
 ('QmqMinValue(4U, kPairCapacity / n)', 'QmqMinValue(16U, kPairCapacity / n)'),
 ('pipe.InitBuffer(x2ScaleQueue, 1, kPairCapacity * sizeof(float));', 'pipe.InitBuffer(x2ScaleQueue, 1, kVectorTileN * sizeof(float));'),
 ('pipe.InitBuffer(reduceBuffer, kPairCapacity * sizeof(float));', 'pipe.InitBuffer(reduceBuffer, kReduceScratchCount * sizeof(float));'),
 ('pipe.InitBuffer(scalarMaxBuffer, 4U * kFloatBlock * sizeof(float));', 'pipe.InitBuffer(scalarMaxBuffer, 16U * kFloatBlock * sizeof(float));'),
 ('        const uint32_t alignedN = QmqAlignUp(currentN, kFloatBlock);\n\n',
  '        const uint32_t alignedN = QmqAlignUp(currentN, kFloatBlock);\n'
  '        // Value-only reduction reuses the first-round workspace (CANN 9.0).\n'
  '        // Add 64 floats of margin per row and keep each row 32-byte aligned.\n'
  '        const uint32_t reduceStride = QmqAlignUp(\n'
  '            2U * QmqCeilDiv(alignedN, 64U) + 64U, kFloatBlock);\n\n'),
 ('fp32Local[r * alignedN], reduceBuffer.Get<float>()[r * alignedN], alignedN);',
  'fp32Local[r * alignedN], reduceBuffer.Get<float>()[r * reduceStride], alignedN);'),
 ('LocalTensor<float> residualLocal = reduceBuffer.Get<float>();',
  '// Divisor is dead after QmqDiv. Floor int32 and residual fp32 are both 32-bit;\n'
  '                // each conversion completely overlaps its own input lanes.\n'
  '                LocalTensor<float> residualLocal = halfBuffer.Get<float>();'),
 ('ReduceMin(scalarMinLocal, residualLocal, scratchLocal, pairCount);',
  'ReduceMin(scalarMinLocal, residualLocal, reduceBuffer.Get<float>(), pairCount);')
]
new_vector=vector
for old,new in changes:
    assert new_vector.count(old)==1,old
    new_vector=new_vector.replace(old,new,1)
candidate=source[:start]+new_vector+source[end:]
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v84/kernel.asc',tofile='v87/kernel.asc')),encoding='utf-8')

# Reverse every approved source edit: no math instruction, rounding mode,
# threshold, correction predicate, queue order or GM offset was changed.
reverse=new_vector
for old,new in reversed(changes):
    assert reverse.count(new)==1
    reverse=reverse.replace(new,old,1)
assert reverse==vector
assert candidate[:start]==source[:start] and candidate[candidate.index('__global__ __mix__(1, 2) void quant_matmul_relu_quant_fused('):]==source[end:]
assert new_vector.count('RoundMode::CAST_RINT')==vector.count('RoundMode::CAST_RINT')
assert new_vector.count('RoundMode::CAST_FLOOR')==vector.count('RoundMode::CAST_FLOOR')
assert new_vector.count('RoundMode::CAST_NONE')==vector.count('RoundMode::CAST_NONE')
assert 'Cast(residualLocal, floorLocal, RoundMode::CAST_NONE, pairCount);' in new_vector

align=lambda x,b:(x+b-1)//b*b
max_scratch=0;max_ub=0;max_occupancy=0
for n in range(1,16385):
    limit=min(16,8192//n) if 32<=n<=4096 and n%32==0 else 1
    for offset in range(0,n,6144):
        width=min(6144,n-offset);aligned=align(width,8)
        stride=align(2*((aligned+63)//64)+64,8)
        assert stride>=align(2*((aligned+63)//64),8)
        assert stride*limit<=2048
        assert aligned*limit<=8192
        assert align(aligned*limit,64)<=8192
        max_scratch=max(max_scratch,stride*limit)
        max_occupancy=max(max_occupancy,aligned*limit)
    # Reduction-min value-only scratch <= round-up(2*ceil(count/64),8),
    # plus margin. Even the worst 8192-element mask needs just 256 floats.
    assert align(2*((max_occupancy+63)//64),8)+64<=2048
for rows in range(1,1025):
    aligned_rows=align(rows,8)
    ub=sum([2*8192*4,6144*4,4*aligned_rows*4,8192,
        2*8192*4,2048*4,16*8*4,8192//8])
    max_ub=max(max_ub,ub)
assert max_ub==189952 and max_ub<196608

# Exhaustively model the existing two-slot prefetch queue with the new limits.
# Batch limits 3/5/6/7/10/11 etc can straddle a 64-row group; extra loaded rows
# are harmless and must be loaded again from the correct start in the next group.
configs=0
for n in range(32,4097,32):
    limit=min(16,8192//n)
    for rows in range(1,1025):
        queue=[(0,min(limit,rows))];seen=[]
        for group in range(0,rows,64):
            for row in range(0,min(64,rows-group),limit):
                begin=group+row;pair=min(limit,min(64,rows-group)-row)
                loaded_at,loaded=queue.pop(0)
                assert loaded_at==begin and loaded>=pair and loaded_at+loaded<=rows
                assert loaded*n<=8192
                if begin+pair<rows:queue.append((begin+pair,min(limit,rows-begin-pair)))
                seen.extend(range(begin,begin+pair))
        assert seen==list(range(rows)) and not queue
        configs+=1

# Storage alias proof: do not recompute or simplify the original residual math.
# Include every fp32 half threshold in [0,128] and adjacent representable values.
half=np.arange(0,128,dtype=np.float32)+np.float32(0.5)
words=half.view(np.uint32)
near=np.concatenate([(words.astype(np.int64)+delta).astype(np.uint32).view(np.float32) for delta in (-3,-2,-1,0,1,2,3)])
rng=np.random.default_rng(87020261011)
q=np.concatenate([near,rng.uniform(0,128,262144).astype(np.float32)])
floor=np.floor(q).astype(np.int32)
reference=np.abs(q-(floor.astype(np.float32)+np.float32(0.5)))
scratch=np.empty(len(q),dtype=np.float32)
scratch.view(np.int32)[:]=floor
scratch[:]=scratch.view(np.int32).astype(np.float32)
scratch+=np.float32(0.5)
scratch[:]=q-scratch
np.abs(scratch,out=scratch)
assert np.array_equal(scratch.view(np.uint32),reference.view(np.uint32))
assert np.array_equal(scratch<np.float32(0.00002),reference<np.float32(0.00002))

# Independent reference checks with changed batch widths and boundary rows.
cases=0;elements=0
for n in (32,64,480,512,736,1024,1536,2016,2048,2720,3072,4096):
    limit=min(16,8192//n)
    for rows in (1,2,3,7,15,16,17,63,64,65,66,127,129):
        c=rng.integers(-32000000,32000001,(rows,n),dtype=np.int32)
        s1=rng.uniform(-2,2,rows).astype(np.float32);s2=rng.uniform(-2,2,n).astype(np.float32)
        c[0]=0
        a=np.maximum((c.astype(np.float32)*s1[:,None])*s2[None,:],np.float32(0))
        maximum=a.max(axis=1)
        scale=np.where(maximum>0,maximum/np.float32(127),np.float32(1))
        expected=np.clip(np.rint(a/scale[:,None]),0,127).astype(np.int8)
        actual=np.empty_like(expected)
        for group in range(0,rows,64):
            for row in range(group,min(group+64,rows),limit):
                stop=min(row+limit,group+64,rows)
                packed=c[row:stop].astype(np.float32).reshape(-1)
                packed*=np.repeat(s1[row:stop],n);packed*=np.tile(s2,stop-row)
                packed=np.maximum(packed,np.float32(0))
                ratio=packed/np.repeat(scale[row:stop],n)
                actual[row:stop]=np.clip(np.rint(ratio),0,127).astype(np.int8).reshape(stop-row,n)
        assert np.array_equal(actual,expected)
        cases+=1;elements+=rows*n
report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':base.name,'changes':'Reuse dead divisor/floor/residual storage; bound value-only reduction workspace; raise batch capacity to8192 with16-row ceiling; permit N4096',
    'only_general_vector_changed':True,'precision_helper_functions_tiny_cube_host_flags_identical':True,
    'arithmetic_instructions_and_rounding_modes_unchanged':True,'double_buffer_queue_and_GM_layout_unchanged':True,
    'general_UB_max_bytes':max_ub,'UB_limit_bytes':196608,
    'max_concurrent_row_reduce_scratch_floats':max_scratch,'allocated_reduce_scratch_floats':2048,
    'max_batch_elements':max_occupancy,'scale_correction_workspace_covers_1024_rows':True,
    'no_partial_or_widening_Cast_alias':True,'dead_divisor_overwritten_only_after_QmqDiv_and_barrier':True,
    'ReduceMin_scratch_separate_from_residual':True,'queue_configurations_checked':configs,
    'residual_alias_boundary_samples':len(q),'batched_arithmetic_cases':cases,'batched_arithmetic_elements':elements,
    'cpu_status':'PASS','hardware_validation':'NOT RUN; platform must validate same-width in-place Cast, resource use and timing',
    'official_sources':['https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0073.html','https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0076.html'],
    'performance_risk':'Larger batch and changed buffer locations can change code scheduling; no benefit claimed before hardware result'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder.name,phase='Reviewed memory-reuse capacity candidate; pending platform',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
