from pathlib import Path
import hashlib, json, re, difflib
from datetime import datetime
import numpy as np

root = Path(__file__).resolve().parent
base = root / 'v81_web_20261011'
folder = root / 'v83_tiny_dequant_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source = (base / 'kernel.asc').read_text(encoding='utf-8')
assert hashlib.sha256((base / 'kernel.asc').read_bytes()).hexdigest() == '77aee7b78648ec56566df80356d93bb3fb45027c43e474755c930e07e21b6288'
changes = [
    ('// Scalar multiplications are separated by a volatile fp32 temporary.',
     '// [V83] Two vector fp32 multiplications retain the original evaluation order.'),
    ('    float s2Values[32];\n    for(uint32_t j=0;j<n;++j){s2Values[j]=s2Local.GetValue(j);}\n', ''),
    ('        const float s1=s1Local.GetValue(r);\n        float maximum=0.0f;',
     '        const float s1=s1Local.GetValue(r);\n'
     '        Muls(sums,sums,s1,static_cast<int32_t>(n));\n'
     '        PipeBarrier<PIPE_V>();\n'
     '        Mul(sums,sums,s2Local,static_cast<int32_t>(n));\n'
     '        PipeBarrier<PIPE_ALL>();\n'
     '        float maximum=0.0f;'),
    ('            volatile float firstScaled=sums.GetValue(j)*s1;\n'
     '            const float dequantized=firstScaled*s2Values[j];',
     '            const float dequantized=sums.GetValue(j);')
]
candidate = source
for old, new in changes:
    assert candidate.count(old) == 1, old
    candidate = candidate.replace(old, new, 1)
(folder / 'kernel.asc').write_text(candidate, encoding='utf-8', newline='\n')
(folder / 'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v81/kernel.asc',tofile='v83/kernel.asc')),encoding='utf-8')

def body(text, name):
    at = text.index(name + '(')
    start = text.index('{', at)
    depth, end = 1, start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[at:end]

unchanged = ['QmqTinyShape','QmqQuantizeNearHalf','QmqDiv','QmqCorrectDiv',
    'QmqScaleBy127Exact','QmqTinyRoundExact','QmqComputeTinyC',
    'quant_matmul_relu_quant_vector','quant_matmul_relu_quant_cube',
    'quant_matmul_relu_quant_fused','qmq_tiny_vector_entry','run_kernel']
assert all(body(source,n) == body(candidate,n) for n in unchanged)
assert re.findall(r'pipe.InitBuffer\([^;]+;',source) == re.findall(r'pipe.InitBuffer\([^;]+;',candidate)
assert source[:source.index('// Integer dot products fit')] == candidate[:candidate.index('// Integer dot products fit')]
assert source[source.index('__global__ __vector__ void qmq_tiny_vector_entry'):] == candidate[candidate.index('__global__ __vector__ void qmq_tiny_vector_entry'):]
tiny = body(candidate,'QmqTryTinyDirect')
assert tiny.count('return false;') == 2
assert tiny.rindex('return false;') < tiny.index('DataCopyPad(yGm[')
assert 'Duplicate(activationLocal,0.0f,quantCount);' in tiny
assert '(check.bits&0x7f800000U)==0x7f800000U' in tiny
assert tiny[tiny.index('    PipeBarrier<PIPE_ALL>();\n    for(uint32_t r=0;r<rows;++r){\n        Duplicate(quantDivisor'):] == body(source,'QmqTryTinyDirect')[body(source,'QmqTryTinyDirect').index('    PipeBarrier<PIPE_ALL>();\n    for(uint32_t r=0;r<rows;++r){\n        Duplicate(quantDivisor'):]

# Edge arithmetic: retain two separately rounded fp32 products, including underflow,
# overflow, signed zeros, negative scales and non-finite fallback. Compare against
# an independent per-element scalar evaluation, and detect illegal reassociation.
rng = np.random.default_rng(83020261011)
count = 131072
dots = rng.integers(-2097152,2097153,count,dtype=np.int32).astype(np.float32)
s1 = rng.integers(0,2**32,count,dtype=np.uint32).view(np.float32)
s2 = rng.integers(0,2**32,count,dtype=np.uint32).view(np.float32)
edge = np.array([0,0x80000000,1,0x007fffff,0x00800000,0x3f800000,0xbf800000,0x7f7fffff,0x7f800000,0xff800000,0x7fc00000],dtype=np.uint32).view(np.float32)
s1[:len(edge)**2] = np.repeat(edge,len(edge))
s2[:len(edge)**2] = np.tile(edge,len(edge))
with np.errstate(all='ignore'):
    vector = np.multiply(np.multiply(dots,s1,dtype=np.float32),s2,dtype=np.float32)
    scalar = np.array([np.float32(np.float32(a*b)*c) for a,b,c in zip(dots,s1,s2)],dtype=np.float32)
    reassociated = np.multiply(dots,np.multiply(s1,s2,dtype=np.float32),dtype=np.float32)
finite = np.isfinite(vector)
assert np.array_equal(finite,np.isfinite(scalar))
assert np.array_equal(vector[finite].view(np.uint32),scalar[finite].view(np.uint32))
assert np.array_equal(np.maximum(vector[finite],np.float32(0)).view(np.uint32),np.maximum(scalar[finite],np.float32(0)).view(np.uint32))
different_order = np.count_nonzero(finite & np.isfinite(reassociated) & (vector.view(np.uint32)!=reassociated.view(np.uint32)))
assert different_order > 0

# Model the real padded sum/scale buffers for every accepted N,K and row tail.
# This checks that vector counts cannot touch sums[alignedN], uninitialized
# padding, or another row, and verifies fallback writes occur after validity.
layouts = 0
for n in range(1,33):
    aligned = (n+7)//8*8
    assert aligned*4 % 32 == 0
    for k in range(1,129):
        if n*k > 1024: continue
        scale = np.ones(aligned,dtype=np.float32)
        sums = np.full(2*aligned,np.float32(-321),dtype=np.float32)
        sums[:n] = rng.integers(-2097152,2097153,n,dtype=np.int32).astype(np.float32)
        untouched = sums[n:].copy()
        sums[:n] *= np.float32(0.125)
        sums[:n] *= scale[:n]
        assert np.array_equal(sums[n:],untouched)
        for rows in (1,2,3,7,16,31,48,96):
            activation = np.zeros((rows,32),dtype=np.float32)
            activation[:,:n] = np.maximum(sums[:n],np.float32(0))
            assert not np.any(activation[:,n:])
            layouts += 1
numerics = {'status':'PASS','fp32_edge_samples':count,'finite_bitwise_matches':int(np.count_nonzero(finite)),
    'nonfinite_fallback_matches':int(np.count_nonzero(~finite)),'illegal_reassociation_counterexamples':int(different_order),
    'padded_buffer_layouts':layouts,'scope':'CPU arithmetic/layout checks; NPU subnormal mode, compilation and performance require platform validation'}
(folder/'cpu_checks.json').write_text(json.dumps(numerics,ensure_ascii=False,indent=2),encoding='utf-8')
report = {'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':'v81_web_20261011','base_score_observed':24.90,'unchanged_functions':unchanged,
    'all_UB_allocations_unchanged':True,'no_host_or_shape_gate_changes':True,
    'all_output_writes_after_finite_and_positive_scale_checks':True,
    'quantization_and_exact_rounding_unchanged':True,'two_fp32_products_original_order':True,
    'new_vector_operands_32_byte_aligned':True,'new_counts_only_active_n_lanes':True,
    'in_place_overlap_complete_single_repeat':True,'cpu_checks':numerics,
    'official_api_sources':['https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0037.html','https://asc.gitcode.com/api/SIMD-API/basic_api/memory_vector_compute/basic_arithmetic/Muls.html'],
    'hardware_validation':'NOT RUN; validate with competition before selecting',
    'performance_risk':'Two vector instructions and their dependencies may cost more than the removed scalar operations for very small N.'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection = {'starting_version':'v81_web_20261011','starting_score_observed':24.90,
    'selected_by':'User explicitly requested highest first-run score; cancelled original version repeats',
    'selected_source_sha256':hashlib.sha256((base/'kernel.asc').read_bytes()).hexdigest(),
    'current_candidate':folder.name,'phase':'reviewed novel optimization; await hardware result',
    'updated_beijing':datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
prefs=json.loads((root/'workflow_preferences.json').read_text(encoding='utf-8'))
prefs['finish_current_work']='2026-10-11 最新要求取消原版复测，选首轮最高 v81（24.90）继续优化、自动提交和分析；仅新增经过审查的优化候选。'
(root/'workflow_preferences.json').write_text(json.dumps(prefs,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
