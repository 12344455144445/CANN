from pathlib import Path
import json, hashlib, difflib
from datetime import datetime
import numpy as np

root=Path(__file__).resolve().parent
base=root/'v81_web_20261011'
folder=root/'v84_n32_batch4_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source=(base/'kernel.asc').read_text(encoding='utf-8')
old='(n >= 64U && n <= 3072U && n % 32U == 0U)'
new='(n >= 32U && n <= 3072U && n % 32U == 0U)'
assert source.count(old)==1
candidate=source.replace(old,new,1)
assert candidate.replace(new,old,1)==source
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v81/kernel.asc',tofile='v84/kernel.asc')),encoding='utf-8')

# All changed shapes have exactly one N tile and no input/output padding gap.
# Simulate the double-buffer queue including every 64-row group and final tail.
configs=0
for rows in range(1,1025):
    n=32;limit=4;queue=[(0,min(limit,rows))];seen=[]
    for group in range(0,rows,64):
        group_rows=min(64,rows-group)
        for row in range(0,group_rows,limit):
            pair=min(limit,group_rows-row);global_row=group+row
            offset,loaded=queue.pop(0)
            assert offset==global_row and loaded>=pair
            assert (offset*n*4)%32==0 and (offset*n)%32==0
            assert pair*n<=6144 and pair<=4
            assert offset+loaded<=rows
            if global_row+pair<rows:
                next_rows=min(limit,rows-global_row-pair)
                queue.append((global_row+pair,next_rows))
            seen.extend(range(global_row,global_row+pair))
    assert seen==list(range(rows)) and not queue
    configs+=1

# Independent whole-matrix reference versus differently partitioned vector batches.
# Check per-row scales, non-positive rows and rounding boundaries; no flattening
# may combine the maximum or divisor of different rows.
rng=np.random.default_rng(84020261011)
elements=0
for rows in (1,2,3,4,5,7,8,15,16,63,64,65,66,127,128,129,255,256,257,1023,1024):
    c=rng.integers(-2000000,2000001,(rows,32),dtype=np.int32)
    s1=rng.uniform(-2,2,rows).astype(np.float32)
    s2=rng.uniform(0.01,2,32).astype(np.float32)
    c[0]=0
    if rows>1: c[1]=-abs(c[1]);s1[1]=1
    reference=np.maximum((c.astype(np.float32)*s1[:,None])*s2[None,:],np.float32(0))
    maximum=reference.max(axis=1)
    scales=np.where(maximum>0,maximum/np.float32(127),np.float32(1))
    expected=np.clip(np.rint(reference/scales[:,None]),0,127).astype(np.int8)
    actual=np.empty_like(expected);actual_max=np.empty(rows,dtype=np.float32)
    for begin in range(0,rows,4):
        end=min(begin+4,rows)
        flat=c[begin:end].astype(np.float32).reshape(-1)
        flat*=np.repeat(s1[begin:end],32)
        flat*=np.tile(s2,end-begin)
        activation=np.maximum(flat,np.float32(0)).reshape(end-begin,32)
        actual_max[begin:end]=activation.max(axis=1)
        divisor=np.repeat(scales[begin:end],32)
        actual[begin:end]=np.clip(np.rint(activation.reshape(-1)/divisor),0,127).astype(np.int8).reshape(end-begin,32)
    assert np.array_equal(actual_max.view(np.uint32),maximum.view(np.uint32))
    assert np.array_equal(expected,actual)
    elements+=rows*32
review={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':'v81_web_20261011','only_live_change':'rowBatchLimit gate N>=64 to N>=32; N=32 newly uses existing four-row path',
    'all_other_source_identical':True,'precision_functions_identical':True,'tiny_direct_identical':True,
    'cube_flags_host_tiling_identical':True,'UB_allocations_identical':True,
    'changed_shape_domain':'N=32, general vector path or tiny fallback; no hardcoded test identifier or input values',
    'one_N_tile_no_copy_gaps':True,'queue_and_tail_configurations':configs,
    'independent_batched_arithmetic_elements':elements,'cpu_checks_status':'PASS',
    'hardware_validation':'NOT RUN; CPU checks cannot establish NPU rounding or speed',
    'performance_hypothesis':'Amortize divide/residual/cast instruction dependencies across four rows at N=32'}
(folder/'review_checks.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder.name,phase='v83 passed precision but estimated score 24.4581 below v81 24.9020; rejected; v84 reviewed, pending submission',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(review,ensure_ascii=False))
