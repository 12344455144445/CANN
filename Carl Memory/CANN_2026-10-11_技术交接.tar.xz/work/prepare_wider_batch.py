from pathlib import Path
from datetime import datetime
import sys, json, hashlib, re, difflib
import numpy as np

root=Path(__file__).resolve().parent
base_name=sys.argv[1]
folder_name=sys.argv[2]
maximum_batch=int(sys.argv[3])
assert maximum_batch in (16,64)
base=root/base_name;folder=root/folder_name;folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source=(base/'kernel.asc').read_text(encoding='utf-8')
assert (base/'hardware_validation.json').exists()
assert json.loads((base/'hardware_validation.json').read_text(encoding='utf-8'))['correctness_15_tests']
old_limit=re.search(r'QmqMinValue\((\d+)U, kPairCapacity / n\)',source)
assert old_limit
old_batch=int(old_limit[1]);assert old_batch<maximum_batch
old=f'QmqMinValue({old_batch}U, kPairCapacity / n)'
new=f'QmqMinValue({maximum_batch}U, kPairCapacity / n)'
old_buffer=f'pipe.InitBuffer(scalarMaxBuffer, {old_batch}U * kFloatBlock * sizeof(float));'
new_buffer=f'pipe.InitBuffer(scalarMaxBuffer, {maximum_batch}U * kFloatBlock * sizeof(float));'
assert source.count(old)==1 and source.count(old_buffer)==1
candidate=source.replace(old,new,1).replace(old_buffer,new_buffer,1)
assert candidate.replace(new,old,1).replace(new_buffer,old_buffer,1)==source
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile=base_name+'/kernel.asc',tofile=folder_name+'/kernel.asc')),encoding='utf-8')

# Check every supported width and row count, including batches that cross the
# 64-row prefetch group. An oversized prefetch may be discarded at a group tail,
# but cannot omit, repeat or read outside any valid row.
configs=0;max_loaded=0
for n in range(32,3073,32):
    limit=min(maximum_batch,6144//n)
    assert limit<=64 and n*limit<=6144
    for rows in range(1,1025):
        queue=[(0,min(limit,rows))];seen=[]
        for group in range(0,rows,64):
            group_rows=min(64,rows-group)
            for row in range(0,group_rows,limit):
                pair=min(limit,group_rows-row);global_row=group+row
                offset,loaded=queue.pop(0)
                assert offset==global_row and loaded>=pair
                assert offset+loaded<=rows and loaded*n<=6144
                assert pair<=maximum_batch and (pair-1)*8+1<=maximum_batch*8
                assert offset*n%32==0 and n%8==0
                compare=(pair*n+63)//64*64
                assert compare<=6144 and compare//8<=768
                if global_row+pair<rows:
                    next_rows=min(limit,rows-global_row-pair)
                    queue.append((global_row+pair,next_rows))
                seen.extend(range(global_row,global_row+pair))
                max_loaded=max(max_loaded,loaded*n)
        assert seen==list(range(rows)) and not queue
        configs+=1

rng=np.random.default_rng(85020261011+maximum_batch)
cpu_cases=0;elements=0
for n in (32,64,96,128,256,384,480,512,640,768,992,1024,1536,2016,2048,3072):
    limit=min(maximum_batch,6144//n)
    for rows in (1,2,3,7,15,16,17,31,63,64,65,66,127,129):
        c=rng.integers(-32000000,32000001,(rows,n),dtype=np.int32)
        s1=rng.uniform(-2,2,rows).astype(np.float32)
        s2=rng.uniform(-2,2,n).astype(np.float32)
        c[0]=0
        reference=np.maximum((c.astype(np.float32)*s1[:,None])*s2[None,:],np.float32(0))
        maxima=reference.max(axis=1)
        scales=np.where(maxima>0,maxima/np.float32(127),np.float32(1))
        expected=np.clip(np.rint(reference/scales[:,None]),0,127).astype(np.int8)
        actual=np.empty_like(expected);actual_max=np.zeros(rows,dtype=np.float32)
        for group in range(0,rows,64):
            for row in range(group,min(group+64,rows),limit):
                end=min(row+limit,group+64,rows)
                packed=c[row:end].astype(np.float32).reshape(-1)
                packed*=np.repeat(s1[row:end],n)
                packed*=np.tile(s2,end-row)
                a=np.maximum(packed,np.float32(0)).reshape(end-row,n)
                actual_max[row:end]=a.max(axis=1)
                q=a.reshape(-1)/np.repeat(scales[row:end],n)
                actual[row:end]=np.clip(np.rint(q),0,127).astype(np.int8).reshape(end-row,n)
        assert np.array_equal(actual_max.view(np.uint32),maxima.view(np.uint32))
        assert np.array_equal(expected,actual)
        cpu_cases+=1;elements+=rows*n
ub=170880+(maximum_batch-4)*8*4
assert ub<196608
report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':base_name,'max_batch':maximum_batch,'only_changes':['Increase existing rowBatchLimit bound','Allocate one independent aligned maximum-result slot per allowed row'],
    'all_other_source_identical':True,'precision_tiny_cube_host_flags_identical':True,
    'general_UB_upper_bound_bytes':ub,'maximum_batch_elements_loaded':max_loaded,
    'buffer_queue_configurations_checked':configs,'cpu_independent_arithmetic_cases':cpu_cases,
    'cpu_elements_checked':elements,'cpu_status':'PASS',
    'hardware_validation':'NOT RUN; CPU proofs are not NPU precision/performance evidence',
    'performance_hypothesis':'Amortize the long divide/residual/cast chain; rowwise scales and maxima remain independent',
    'performance_risk':'More rowwise Muls/Mul/ReduceMax calls per batch and changed compiler scheduling can offset the shared-chain savings'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder_name,phase='Novel wider-batch candidate reviewed; awaiting platform validation',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
