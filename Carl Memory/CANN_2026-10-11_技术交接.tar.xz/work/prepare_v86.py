from pathlib import Path
import hashlib,json,difflib
from datetime import datetime
import numpy as np

root=Path(__file__).resolve().parent
base=root/'v84_n32_batch4_20261011';folder=root/'v86_n8_batch4_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source=(base/'kernel.asc').read_text(encoding='utf-8')
old='(n >= 32U && n <= 3072U && n % 32U == 0U)'
new='(n >= 8U && n <= 3072U && n % 8U == 0U)'
assert source.count(old)==1
candidate=source.replace(old,new,1)
assert candidate.replace(new,old,1)==source
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v84/kernel.asc',tofile='v86/kernel.asc')),encoding='utf-8')

# The actual requirement for all rowwise fp32 vector operands is N*4 % 32==0.
# The GM output copy is one contiguous block, and DataCopyPad supports arbitrary
# GM alignment. There are no per-row int8 UB offsets in this existing batch path.
widths=list(range(8,3073,8))
for n in widths:
    limit=min(4,6144//n)
    assert n==(n+7)//8*8
    assert n*4%32==0
    assert n*limit<=6144
    assert ((n*limit+63)//64*64)<=6144
    for row in range(limit):
        assert row*n*4%32==0
        assert row*8*4%32==0
    assert (n*limit)*4%32==0 # UB->UB DataCopy, including single-row tail.
assert 'DataCopyExtParams outputCopy{1, currentN * pairRows, 0, 0, 0};' in candidate
assert 'DataCopyPad(yGm[offset], outputLocal, outputCopy);' in candidate
assert 'DataCopyExtParams copy{1, static_cast<uint32_t>(count * sizeof(int32_t)), 0, 0, 0};' in candidate

# Exercise every row tail/group boundary at the newly admitted small widths,
# plus larger widths with different 6144/N capacity limits.
configurations=0
for n in (8,16,24,40,48,56,72,120,504,1016,1528,1544,2008,2056,3064):
    limit=min(4,6144//n)
    for rows in range(1,1025):
        pending=[(0,min(limit,rows))];seen=[]
        for group in range(0,rows,64):
            group_rows=min(64,rows-group)
            for row in range(0,group_rows,limit):
                start=group+row;pair=min(limit,group_rows-row)
                offset,loaded=pending.pop(0)
                assert offset==start and loaded>=pair and offset+loaded<=rows
                assert loaded*n<=6144
                if start+pair<rows:pending.append((start+pair,min(limit,rows-start-pair)))
                seen.extend(range(start,start+pair))
        assert seen==list(range(rows)) and not pending
        configurations+=1

rng=np.random.default_rng(86020261011)
cases=0;elements=0
for n in (8,16,24,40,48,56,72,120,504,1016,1528,1544,2008,2056,3064):
    for rows in (1,2,3,4,5,7,63,64,65,66,127,129):
        c=rng.integers(-32000000,32000001,(rows,n),dtype=np.int32)
        s1=rng.uniform(-2,2,rows).astype(np.float32);s2=rng.uniform(-2,2,n).astype(np.float32)
        c[0]=0
        ref=np.maximum((c.astype(np.float32)*s1[:,None])*s2[None,:],np.float32(0))
        maxima=ref.max(axis=1)
        scale=np.where(maxima>0,maxima/np.float32(127),np.float32(1))
        expected=np.clip(np.rint(ref/scale[:,None]),0,127).astype(np.int8)
        result=np.empty_like(expected);actual_max=np.zeros(rows,dtype=np.float32)
        limit=min(4,6144//n)
        for group in range(0,rows,64):
            for row in range(group,min(group+64,rows),limit):
                end=min(row+limit,group+64,rows)
                # Model exact contiguous GM byte span and reinterpretation.
                loaded=np.frombuffer(c[row:end].tobytes(),dtype=np.int32).astype(np.float32)
                loaded*=np.repeat(s1[row:end],n)
                loaded*=np.tile(s2,end-row)
                act=np.maximum(loaded,np.float32(0)).reshape(end-row,n)
                actual_max[row:end]=act.max(axis=1)
                q=act.reshape(-1)/np.repeat(scale[row:end],n)
                out=np.clip(np.rint(q),0,127).astype(np.int8)
                result[row:end]=np.frombuffer(out.tobytes(),dtype=np.int8).reshape(end-row,n)
        assert np.array_equal(actual_max.view(np.uint32),maxima.view(np.uint32))
        assert np.array_equal(result,expected)
        cases+=1;elements+=rows*n
report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':base.name,'only_live_change':'Permit existing four-row batch whenever N is a multiple of 8, rather than 32',
    'all_other_source_identical':True,'all_precision_functions_tiny_cube_host_flags_unchanged':True,
    'all_UB_allocations_unchanged':True,'general_UB_upper_bound_bytes':170880,
    'all_fp32_row_operands_32_byte_aligned':True,'all_UB_copy_sizes_multiple_of_32':True,
    'input_and_output_GM_copies_flat_contiguous_no_row_padding':True,
    'DataCopyPad_GM_unaligned_supported':'Official DataCopyPad doc; only UB side needs 32-byte alignment',
    'supported_widths_checked':len(widths),'queue_tail_configurations_checked':configurations,
    'independent_arithmetic_and_byte_layout_cases':cases,'cpu_elements_checked':elements,'cpu_status':'PASS',
    'hardware_validation':'NOT RUN; new width masks and copy sizes require actual NPU result',
    'performance_hypothesis':'Share the long quantization chain across rows for narrow and other N%8==0 shapes previously excluded'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder.name,phase='v85 passed but no improvement; retain v84 starting source; v86 new alignment gate reviewed',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
