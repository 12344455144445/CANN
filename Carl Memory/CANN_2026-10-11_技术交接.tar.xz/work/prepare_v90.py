from pathlib import Path
from datetime import datetime
import json,hashlib,re,difflib
import numpy as np

root=Path(__file__).resolve().parent
base=root/'v84_n32_batch4_20261011';folder=root/'v90_npartition_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
source=(base/'kernel.asc').read_text(encoding='utf-8')
device=(root/'v90_partition_device.txt').read_text(encoding='utf-8')
host=(root/'v90_partition_host.txt').read_text(encoding='utf-8')
device_anchor='// ============================================================================\n// [PATCH-H1] workspace'
host_anchor='    const uint32_t aivCandidate = static_cast<uint32_t>(std::min<uint64_t>(\n'
assert source.count(device_anchor)==1 and source.count(host_anchor)==1
candidate=source.replace(device_anchor,device+device_anchor,1).replace(host_anchor,host+host_anchor,1)
assert candidate.replace(device,'',1).replace(host,'',1)==source
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v84/kernel.asc',tofile='v90/kernel.asc')),encoding='utf-8')
assert 'CrossCore' not in device
assert device.index('mm.SetOrgShape')<device.index('mm.SetTensorA')
assert host.index('qmq_npartition_cube_entry<<<')<host.index('qmq_npartition_vector_entry<<<')<host.index('aclrtSynchronizeStream')
assert host.count('stream>>>')==2
assert 'partTiling.singleCoreN ==' in host and 'partTiling.singleCoreM ==' in host
assert not re.search(r'partTiling\.(singleCoreN|baseN)\s*=(?!=)',host)

geometries=0
for cores in (8,16,20,24,32,48,64):
    for m in range(64,385):
        block_rows=16 if m<=192 else 32
        row_groups=(m+block_rows-1)//block_rows
        for n in (1024,1025,1031,1535,1536,1537,2047,2048,2049,3072,4096,4097,8191,8192,16385,2147483647):
            requested=min(cores//row_groups,n//128)
            if requested<2:continue
            width=((n+requested-1)//requested+15)//16*16
            cols=(n+width-1)//width
            assert cols>=2 and cols*row_groups<=cores
            # Cartesian coverage is exact: disjoint row intervals times
            # disjoint column intervals; the last interval is correctly clipped.
            r_edges=[(i*block_rows,min((i+1)*block_rows,m)) for i in range(row_groups)]
            c_edges=[(i*width,min((i+1)*width,n)) for i in range(cols)]
            assert r_edges[0][0]==0 and r_edges[-1][1]==m
            assert c_edges[0][0]==0 and c_edges[-1][1]==n
            assert all(a[1]==b[0] for a,b in zip(r_edges,r_edges[1:]))
            assert all(a[1]==b[0] for a,b in zip(c_edges,c_edges[1:]))
            seen=[]
            for index in range(2*row_groups*cols):
                slices=2*cols;group=index//slices;slice_index=index%slices
                valid=min(block_rows,m-group*block_rows)
                start=group*block_rows+valid*slice_index//slices
                end=group*block_rows+valid*(slice_index+1)//slices
                assert end-start<=8
                if start<end:seen.extend(range(start,end))
            assert seen==list(range(m))
            assert m*n*4<=2**64-1
            geometries+=1

# Independent physical B[N,K] / ND C row-stride test, including odd N tails.
# Short K reduces CPU time; the same pointer/stride formulas apply at all K.
rng=np.random.default_rng(90020261011);cases=0
for m,n,k,cores in ((64,1024,7,24),(65,1025,3,24),(96,1537,5,24),(127,2049,7,24),(128,3072,3,24),(191,4097,5,32),(192,8191,2,24),(193,4097,3,24),(256,8191,2,24),(383,4097,3,48)):
    block_rows=16 if m<=192 else 32
    row_groups=(m+block_rows-1)//block_rows;requested=min(cores//row_groups,n//128)
    width=((n+requested-1)//requested+15)//16*16;cols=(n+width-1)//width
    a=rng.integers(-128,128,(m,k),dtype=np.int8);b=rng.integers(-128,128,(n,k),dtype=np.int8)
    expected=a.astype(np.int32)@b.astype(np.int32).T
    c=np.zeros((m,n),dtype=np.int32);writes=np.zeros((m,n),dtype=np.uint8)
    for core in range(row_groups*cols):
        r0=(core//cols)*block_rows;c0=(core%cols)*width
        r1=min(r0+block_rows,m);c1=min(c0+width,n)
        block=a[r0:r1].astype(np.int32)@b[c0:c1].astype(np.int32).T
        for row in range(r1-r0):
            # Full N must remain the GM output row stride.
            offset=(r0+row)*n+c0
            c.reshape(-1)[offset:offset+c1-c0]=block[row]
            writes.reshape(-1)[offset:offset+c1-c0]+=1
    assert np.all(writes==1) and np.array_equal(c,expected)
    s1=rng.uniform(-2,2,m).astype(np.float32);s2=rng.uniform(-2,2,n).astype(np.float32)
    act=np.maximum((c.astype(np.float32)*s1[:,None])*s2[None,:],np.float32(0))
    maximum=act.max(axis=1);scale=np.where(maximum>0,maximum/np.float32(127),np.float32(1))
    y=np.clip(np.rint(act/scale[:,None]),0,127).astype(np.int8)
    ref=np.maximum((expected.astype(np.float32)*s1[:,None])*s2[None,:],np.float32(0))
    mx=ref.max(axis=1);rs=np.where(mx>0,mx/np.float32(127),np.float32(1))
    assert np.array_equal(scale.view(np.uint32),rs.view(np.uint32))
    assert np.array_equal(y,np.clip(np.rint(ref/rs[:,None]),0,127).astype(np.int8))
    cases+=1
report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':base.name,'only_additions':'Two explicit execution-space kernels and guarded coherent partial-N tiling host dispatch; all legacy code exact',
    'unchanged_math_tiny_general_vector_precision_helpers_and_original_flags':True,
    'original_host_fallback_exact':True,'no_manual_TCubeTiling_edits':True,
    'dispatch_domain':'64<=M<=384, N>=1024, K>=1024, N*K>=4MiB; >=2 column partitions must fit available cores; M>192 also requires >=25% more Cube groups than legacy ceil(M/16)',
    'stream_ordered_cube_then_vector_then_final_sync':True,'no_intergroup_flag_or_busy_wait':True,
    'GM_C_row_stride_full_N':True,'physical_B_offset_columnOffset_times_K':True,
    'row_and_column_coverage_geometries':geometries,'CPU_exact_matmul_and_quantization_layout_cases':cases,
    'vector_rows_per_call_le_8':True,'same_workspace_allocation_and_size_checks':True,
    'CPU_status':'PASS','hardware_validation':'NOT RUN; NPU compile, partial-N C stride, four-kernel module and timing require platform result; hidden-case branch coverage not observable',
    'official_SetOrgShape_source':'https://www.hiascend.com/document/detail/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0651.html',
    'WorkBuddy_reference':'analysis/43 proposed N-split + global barrier; current version uses same-stream separate launches to wait for complete C',
    'performance_risk':'Extra kernel launch and fewer active vector cores may outweigh improved Cube lane utilization; unchanged paths can also suffer compiler layout changes'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder.name,phase='Reviewed structural N-partition candidate from highest-scoring v84; pending device evaluation',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
