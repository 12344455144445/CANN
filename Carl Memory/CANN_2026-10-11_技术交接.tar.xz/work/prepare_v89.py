from pathlib import Path
import hashlib,json,difflib
from datetime import datetime

root=Path(__file__).resolve().parent
base=root/'v88_float_floor_20261011';folder=root/'v89_all_float_floor_20261011'
folder.mkdir(exist_ok=True)
if (folder/'submission_info.json').exists() or (folder/'submission_attempt.json').exists():
    raise SystemExit('Submitted source is immutable; use a fresh candidate folder')
assert json.loads((base/'hardware_validation.json').read_text(encoding='utf-8'))['correctness_15_tests']
source=(base/'kernel.asc').read_text(encoding='utf-8')
old='''    auto floors=quantScratch.ReinterpretCast<int32_t>();
    Cast(floors,quantLocal,RoundMode::CAST_FLOOR,quantCount);
    PipeBarrier<PIPE_V>();
    Cast(quantResidual,floors,RoundMode::CAST_NONE,quantCount);
    PipeBarrier<PIPE_V>();'''
new='''    // Same exact integer-valued fp32 FLOOR used by the validated general path.
    Cast(quantResidual,quantLocal,RoundMode::CAST_FLOOR,quantCount);
    PipeBarrier<PIPE_V>();'''
assert source.count(old)==1
candidate=source.replace(old,new,1)
assert candidate.replace(new,old,1)==source
(folder/'kernel.asc').write_text(candidate,encoding='utf-8',newline='\n')
(folder/'source.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='v88/kernel.asc',tofile='v89/kernel.asc')),encoding='utf-8')
numerics=json.loads((base/'review_checks.json').read_text(encoding='utf-8'))
report={'review_pass':True,'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest(),
    'base':base.name,'only_live_change':'Use the validated fp32 FLOOR shortcut also in tiny batch half-screen; no other source changes',
    'general_vector_cube_host_flags_shape_gates_unchanged':True,'buffers_and_scratch_regions_unchanged':True,
    'division_exact_correction_predicate_and_final_RINT_unchanged':True,
    'all_tiny_activations_finite_and_row_scales_positive_checked_before_division':True,
    'tiny_padding_zeros_and_compare_tail_initialization_unchanged':True,
    'CPU_edge_screen_validation_reused':{'samples':numerics['half_screen_bitwise_matches'],'status':numerics['CPU_screen_status'],'source':'v88_float_floor_20261011/review_checks.json'},
    'general_FP32_floor_hardware_pass':'v88 15/15, zero error; tiny counts still require independent platform result',
    'performance_hypothesis':'Remove one type conversion and its barrier in each tiny batch'}
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
selection=json.loads((root/'round4_selection.json').read_text(encoding='utf-8'))
selection.update(current_candidate=folder.name,phase='v88 general shortcut passed and sped long points; extend identical shortcut to tiny batch as novel candidate',updated_beijing=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
(root/'round4_selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
