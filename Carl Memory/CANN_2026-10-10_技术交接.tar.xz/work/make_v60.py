from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parent
base = (root/'v53_cube512'/'kernel.asc').read_text(encoding='utf-8')
old = 'constexpr uint32_t kVectorTileN = 6144;'
new = 'constexpr uint32_t kVectorTileN = 4096;'
assert base.count(old) == 1
candidate = base.replace(old, new)
assert candidate.replace(new, old) == base
assert candidate[:candidate.index('__aicore__ inline void quant_matmul_relu_quant_vector(')] .count(new) == 1
folder = root/'v60_tile4096'
folder.mkdir(exist_ok=True)
(folder/'kernel.asc').write_bytes(candidate.replace('\n', '\r\n').encode('utf-8'))
checks = {'only_live_change': 'kVectorTileN: 6144 -> 4096',
          'inverse_transform_exact': True,
          'max_ub_bytes_for_rows_1_to_1024': 25*4096+512+16*1024+32,
          'ub_limit': 196608,
          'critical_functions_and_row_body_unchanged': True,
          'sha256': hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest()}
(folder/'source_checks.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')
(folder/'SUBMIT.md').write_text('''# v60：向量分块 4096 单变量诊断

基线：此前两次 15/15 通过的 v53 cube512，最终正式榜单 23.30。
唯一活代码变化：kVectorTileN 6144→4096。近半值筛选、精度修正、逐行指令顺序均不改。

来源：WorkBuddy NEXT_STEPS §3；先标定多一次 nOffset 循环的代价。
修正其预算口径：103072 B 是 rows≤8 的实例，不是通用上界。
本版本 rows≤1024 时最大119328 B，低于196608 B。

预登记：任意正确性失败立即弃用；若估算分数下降≥0.20或任一点退化≥10%，
不作为最终版本，但继续判断更窄分块是否只适合限定范围。
若持平或改善，下一步测有明确独立缓冲/预取机制的结构改法。
官方15点形状未知，不使用本地样例的N给官方点编号。
''', encoding='utf-8')
print(json.dumps(checks))
