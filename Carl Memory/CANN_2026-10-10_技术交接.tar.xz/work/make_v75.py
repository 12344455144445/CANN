from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).resolve().parent
base=root/'v74_tiny_simd_dot';out=root/'v75_tiny_vector_quant';out.mkdir(exist_ok=True)
assert not (out/'submission_info.json').exists()
src=(base/'kernel.asc').read_text(encoding='utf-8');changes=[]
def change(old,new):
    global src
    assert src.count(old)==1,old[:70]
    src=src.replace(old,new,1);changes.append((old,new))
change('''    pipe.InitBuffer(sumBuffer,2U*alignedN*sizeof(float));''','''    pipe.InitBuffer(sumBuffer,2U*alignedN*sizeof(float));
    TBuf<TPosition::VECCALC> quantBuffer,tinyCorrectionMaskBuffer;
    pipe.InitBuffer(quantBuffer,256U*sizeof(float));
    pipe.InitBuffer(tinyCorrectionMaskBuffer,32U);''')
change('''    pipe.InitBuffer(yBuffer,QmqAlignUp(rows*n,32U));''','''    pipe.InitBuffer(yBuffer,rows*32U);''')
change('''        for(uint32_t j=0;j<n;++j){
            const int32_t rounded=QmqTinyRoundExact(activations[j],rowScale);
            if(rounded<0){return false;}
            yLocal.SetValue(r*n+j,static_cast<int8_t>(rounded));
        }''','''        // Use the baseline vector division, near-half correction and output casts.
        // Each temporary occupies an independent 64-float region.
        for(uint32_t j=0;j<alignedN;++j){
            sums.SetValue(j,j<n?activations[j]:0.0f);
        }
        auto fp32=quantBuffer.Get<float>();
        auto divisor=fp32[64U];
        auto residual=fp32[128U];
        auto scratch=fp32[192U];
        auto correctionMask=tinyCorrectionMaskBuffer.Get<uint8_t>();
        PipeBarrier<PIPE_ALL>();
        Duplicate(divisor,rowScale,alignedN);
        Duplicate(residual,1.0f,64U);
        PipeBarrier<PIPE_V>();
        QmqDiv(fp32,sums,divisor,alignedN);
        PipeBarrier<PIPE_V>();
        auto floors=scratch.ReinterpretCast<int32_t>();
        Cast(floors,fp32,RoundMode::CAST_FLOOR,alignedN);
        PipeBarrier<PIPE_V>();
        Cast(residual,floors,RoundMode::CAST_NONE,alignedN);
        PipeBarrier<PIPE_V>();
        Adds(residual,residual,0.5f,alignedN);
        PipeBarrier<PIPE_V>();
        Sub(residual,fp32,residual,alignedN);
        PipeBarrier<PIPE_V>();
        Abs(residual,residual,alignedN);
        PipeBarrier<PIPE_V>();
        Compares(correctionMask,residual,kHalfScreenTolerance,CMPMODE::LT,64U);
        PipeBarrier<PIPE_V>();
        auto maskWords=correctionMask.ReinterpretCast<uint64_t>();
        uint64_t bits=maskWords.GetValue(0);
        while(bits!=0U){
            const uint32_t lane=static_cast<uint32_t>(AscendC::GetSFFValue<1>(bits));
            if(lane<n){
                const int32_t quantized=QmqQuantizeNearHalf(sums.GetValue(lane),rowScale,fp32.GetValue(lane));
                if(quantized>=0){fp32.SetValue(lane,static_cast<float>(quantized));}
            }
            bits&=bits-1U;
        }
        PipeBarrier<PIPE_V>();
        Maxs(fp32,fp32,0.0f,alignedN);
        Mins(fp32,fp32,127.0f,alignedN);
        PipeBarrier<PIPE_V>();
        auto quantizedInts=sums[alignedN].ReinterpretCast<int32_t>();
        Cast(quantizedInts,fp32,RoundMode::CAST_RINT,alignedN);
        PipeBarrier<PIPE_V>();
        SetDeqScale(static_cast<half>(1.0f));
        auto halfOutput=sums.ReinterpretCast<half>();
        Cast(halfOutput,quantizedInts,RoundMode::CAST_NONE,alignedN);
        PipeBarrier<PIPE_V>();
        Cast(yLocal[r*32U],halfOutput,RoundMode::CAST_RINT,alignedN);
        PipeBarrier<PIPE_ALL>();''')
change('''    DataCopyExtParams yc{1,rows*n,0,0,0},ysc{1,static_cast<uint32_t>(rows*sizeof(float)),0,0,0};''','''    DataCopyExtParams yc{static_cast<uint16_t>(rows),n,0,0,0};
    DataCopyExtParams ysc{1,static_cast<uint32_t>(rows*sizeof(float)),0,0,0};''')
inverse=src
for old,new in reversed(changes):
    assert inverse.count(new)==1;inverse=inverse.replace(new,old,1)
assert inverse==(base/'kernel.asc').read_text(encoding='utf-8')
(out/'kernel.asc').write_bytes(src.replace('\n','\r\n').encode('utf-8'))
for name in ['tiny_checks.json','dot_checks.json']:shutil.copy2(base/name,out/name)
(out/'source_checks.json').write_text(json.dumps({'sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest(),'inverse_diff_exact':True,'changed_function':'QmqTryTinyDirect only','dot_and_dequantization_unchanged':True,'quantization':'Original QmqDiv, near-half criterion and QmqQuantizeNearHalf, then original int32/half/int8 casts','padded_output_rows':'32-byte UB rows stripped by multiblock DataCopyPad into tightly packed GM rows'},ensure_ascii=False,indent=2),encoding='utf-8')
(out/'SUBMIT.md').write_text('''# v75：小矩阵量化向量化

v74 15/15，估算24.4624；前三点9.98/5.04/8.74us，尚未达到30分。
保持SIMD点积、反量化两个fp32乘法、精确rowMax/127和回退路径。
仅把逐元素整数除法量化替换为已验证的通用向量量化片段：
QmqDiv → 原近半残差/容差判据 → 原QmqQuantizeNearHalf → RINT/int32/half/int8。
小N不需要ReduceMin预筛。三个精度函数定义不改。
输出每行占32B对齐槽，最后以rows个n字节DataCopyPad块写GM，源stride0的
含义是按32B对齐块连续，目标stride0的含义是紧密n字节行，禁止按UB填充直接写GM。
四个量化暂存区各64float相互不重叠，sum后一半int32与前半half不重叠。
比较mask读取64lane且残差尾部初始化1，仅真实lane<n可进入精度修正。

判读：15/15且0错误；估算提高≥0.4或多个tiny点明显提速才复测。
若只是持平/退化，回到v74原样复测，避免连续消耗次数。
''',encoding='utf-8')
print('Generated',out.name)
