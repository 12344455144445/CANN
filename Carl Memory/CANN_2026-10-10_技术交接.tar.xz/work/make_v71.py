from pathlib import Path
import hashlib, json

root=Path(__file__).resolve().parent
base=(root/'v64_rowpair_guard'/'kernel.asc').read_text(encoding='utf-8')
marker='// ============================================================================\n// [PATCH-H1] workspace'
helper='''// Pure-vector entry for the existing exact tiny-shape arithmetic.
// Both entries explicitly declare their execution spaces. Exactly one is launched.
__global__ __vector__ void qmq_tiny_vector_entry(
    GM_ADDR x1, GM_ADDR x2, GM_ADDR workspace,
    GM_ADDR x1Scale, GM_ADDR x2Scale, GM_ADDR y, GM_ADDR yScale,
    uint32_t m, uint32_t n, uint32_t k,
    uint32_t blockM, uint32_t groupCount, uint32_t mBlocksPerGroup)
{
    AscendC::InitSocState();
    const uint32_t vectorIndex = GetBlockIdx();
    const uint32_t groupIndex = vectorIndex / 2U;
    const uint32_t subIndex = vectorIndex % 2U;
    if (groupIndex >= groupCount) {
        return;
    }
    const uint32_t halfM = (blockM + 1U) / 2U;
    for (uint32_t tile = 0; tile < mBlocksPerGroup; ++tile) {
        const uint32_t mOffset = (groupIndex * mBlocksPerGroup + tile) * blockM;
        if (mOffset >= m) {
            continue;
        }
        const uint32_t endM = QmqMinValue(mOffset + blockM, m);
        const uint32_t localStart = mOffset + (subIndex == 0U ? 0U : halfM);
        if (localStart >= endM) {
            continue;
        }
        const uint32_t localEnd = subIndex == 0U ? QmqMinValue(mOffset + halfM, endM) : endM;
        const uint32_t localRows = localEnd - localStart;
        QmqComputeTinyC(x1, x2, workspace, m, n, k, localStart, localRows);
        quant_matmul_relu_quant_vector(workspace, x1Scale, x2Scale, y, yScale,
            m, n, localStart, localRows);
    }
}

'''
assert base.count(marker)==1
src=base.replace(marker,helper+marker,1)
a=src.index('    quant_matmul_relu_quant_fused<<<activeGroupCount')
b=src.index('    // 同步交由',a)
launch=src[a:b]
branch='''    const bool hostTinyShape = m <= kQmqTinyMaxM && n <= kQmqTinyMaxN &&
        k <= kQmqTinyMaxK && static_cast<uint64_t>(n) * k <= kQmqTinyMaxNK;
    if (hostTinyShape) {
        qmq_tiny_vector_entry<<<2U * activeGroupCount, 0, stream>>>(
            x1, x2, resultWorkspace, x1Scale, x2Scale, y, yScale,
            m, n, k, static_cast<uint32_t>(tiling.singleCoreM),
            activeGroupCount, mBlocksPerGroup);
    } else {
'''+''.join('    '+line for line in launch.splitlines(True))+'''    }
'''
src=src[:a]+branch+src[b:]
assert src.replace(branch,launch,1).replace(helper,'',1)==base
assert src.count('KERNEL_TASK_TYPE_DEFAULT(')==0
# Exact original helper bodies and fused entry remain present.
out=root/'v71_tiny_vector';out.mkdir(exist_ok=True)
(out/'kernel.asc').write_bytes(src.replace('\n','\r\n').encode('utf-8'))
(out/'source_checks.json').write_text(json.dumps({'inverse_transform_exact':True,'precision_vector_cube_fused_unchanged':True,'runtime_launches':1,'global_declarations':2,'experimental_execution_space':'__vector__ explicit attribute, no default type macros','sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print('Generated v71_tiny_vector')
