from pathlib import Path
import difflib, hashlib, json

root=Path(__file__).resolve().parent
base=root/'v64_rowpair_guard'/'kernel.asc'
src=base.read_text(encoding='utf-8')
start=src.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
end=src.index('__global__ __mix__',start)
old=src[start:end]
first=old.index('    for (uint32_t nOffset = 0;')
second=old.index('    for (uint32_t nOffset = 0;',first+1)
prefix=old[:first]
prefix=prefix.replace('    const uint32_t alignedRows = QmqAlignUp(rows, kFloatBlock);',
    '    const uint32_t alignedRows = QmqAlignUp(rows, kFloatBlock);\n'
    '    const bool onePass = n >= 64U && n <= kVectorTileN;')
p2=old[second:old.index('    x1ScaleQueue.FreeTensor',second)]
cast_end=p2.index('                for (uint32_t r = 0; r < pairRows; ++r) {\n                    if (pairRowMaxPrefetch')
head=p2[:cast_end]
head=head.replace('pairRowMaxPrefetch[i] = rowMaxLocal.GetValue(group + i);',
                  'pairRowMaxPrefetch[i] = phase == 1U ? rowMaxLocal.GetValue(group + i) : 0.0f;')
head=head.replace('pairRowScalePrefetch[i] = rowScaleLocal.GetValue(group + i);',
                  'pairRowScalePrefetch[i] = phase == 1U ? rowScaleLocal.GetValue(group + i) : 1.0f;')
head=head.replace('                LocalTensor<float> fp32Local = fp32Buffer.Get<float>();',
                  '                LocalTensor<float> fp32Local = fp32Buffer.Get<float>();\n'
                  '                LocalTensor<float> scalarMaxLocal = scalarMaxBuffer.Get<float>();')
reduce_start=old.index('                for (uint32_t r = 0; r < pairRows; ++r) {\n                    ReduceMax(')
reduce_end=old.index('                workspaceQueue.FreeTensor(inputLocal);',reduce_start)
reduce=old[reduce_start:reduce_end]
quant=p2[cast_end:p2.index('                workspaceQueue.FreeTensor(inputLocal);')]
tile_end=p2[p2.index('                workspaceQueue.FreeTensor(inputLocal);'):]
scale_start=old.index('    // [OPT-V16/PA]')
scale_end=old.index('    for (uint32_t row = 0; row < rows; ++row) {\n        yScaleLocal.SetValue',scale_start)
scale=old[scale_start:scale_end]
scale=scale.replace('    LocalTensor<float> yScaleLocal = yScaleQueue.AllocTensor<float>();\n','')
ycopy=old[scale_end:second]
ycopy='    LocalTensor<float> yScaleLocal = yScaleQueue.AllocTensor<float>();\n'+ycopy
helper='''// Exact round-to-nearest-even division by the odd integer 127 for positive finite fp32.
// A finite fp32 is an integer mantissa times a power of two. No half-way remainder
// exists after division by 127, because the denominator is odd.
__aicore__ inline float QmqScaleBy127Exact(float value)
{
    union Word { float value; uint32_t bits; } input, output;
    input.value = value;
    const uint32_t exponent = (input.bits >> 23U) & 255U;
    const uint32_t mantissa = (input.bits & 0x7fffffU) |
        (exponent == 0U ? 0U : 0x800000U);
    uint64_t numerator;
    uint32_t outputExponent = 0U;
    if (exponent <= 7U) {
        numerator = static_cast<uint64_t>(mantissa) << (exponent == 0U ? 0U : exponent - 1U);
    } else {
        const bool highMantissa = mantissa >= 16646144U;
        outputExponent = exponent - (highMantissa ? 6U : 7U);
        numerator = static_cast<uint64_t>(mantissa) << (highMantissa ? 6U : 7U);
    }
    uint32_t rounded = static_cast<uint32_t>(numerator / 127ULL);
    const uint32_t remainder = static_cast<uint32_t>(numerator - static_cast<uint64_t>(rounded) * 127ULL);
    if (remainder * 2U > 127U) {
        ++rounded;
    }
    if (outputExponent == 0U) {
        output.bits = rounded;
    } else {
        if (rounded == 0x1000000U) {
            rounded >>= 1U;
            ++outputExponent;
        }
        output.bits = (outputExponent << 23U) | (rounded & 0x7fffffU);
    }
    return output.value;
}

'''
newscale='''                    if (onePass) {
                        bool needsVectorScale = false;
                        float maxima[4];
                        for (uint32_t r = 0; r < pairRows; ++r) {
                            maxima[r] = rowMaxLocal.GetValue(globalRow + r);
                            union { float value; uint32_t bits; } maxWord;
                            maxWord.value = maxima[r];
                            needsVectorScale = needsVectorScale || ((maxWord.bits & 0x7f800000U) == 0x7f800000U);
                        }
                        if (needsVectorScale) {
                            Duplicate(scalarMaxLocal, 0.0f, kFloatBlock);
                            PipeBarrier<PIPE_V>();
                            for (uint32_t r = 0; r < pairRows; ++r) {
                                scalarMaxLocal.SetValue(r, maxima[r]);
                            }
                            PipeBarrier<PIPE_ALL>();
                            Duplicate(halfBuffer.Get<float>(), 127.0f, kFloatBlock);
                            PipeBarrier<PIPE_V>();
                            QmqCorrectDiv(scalarMaxLocal[kFloatBlock], scalarMaxLocal,
                                halfBuffer.Get<float>(), reduceBuffer.Get<float>(),
                                inputLocal.ReinterpretCast<float>(), correctionMaskBuffer.Get<uint8_t>(),
                                kFloatBlock, 64U);
                        }
                        for (uint32_t r = 0; r < pairRows; ++r) {
                            const float rowScale = maxima[r] > 0.0f
                                ? (needsVectorScale ? scalarMaxLocal.GetValue(kFloatBlock + r)
                                                    : QmqScaleBy127Exact(maxima[r]))
                                : 1.0f;
                            rowScaleLocal.SetValue(globalRow + r, rowScale);
                            pairRowMaxPrefetch[row + r] = maxima[r];
                            pairRowScalePrefetch[row + r] = rowScale;
                        }
                    }
'''
def indent(text,n):return ''.join((' '*n+line if line.strip() else line) for line in text.splitlines(True))
new=(prefix+'    const uint32_t phaseCount = onePass ? 1U : 2U;\n'
     +'    for (uint32_t phase = 0; phase < phaseCount; ++phase) {\n'
     +indent(head,4)+'                    if (phase == 0U) {\n'
     +indent(reduce,8)+newscale+'                    }\n'
     +'                    if (onePass || phase == 1U) {\n'+indent(quant,8)
     +'                    }\n'+indent(tile_end,4)
     +'        if (!onePass && phase == 0U) {\n'+indent(scale,8)+'        }\n'
     +'    }\n'+ycopy+old[old.index('    x1ScaleQueue.FreeTensor',second):])
# Keep numeric correction functions, Cube, fused entry, and host bit-for-bit.
candidate=src[:start]+helper+new+src[end:]
for fn in ['QmqQuantizeNearHalf','QmqDiv','QmqCorrectDiv']:
    marker='__aicore__ inline '+('int32_t ' if fn=='QmqQuantizeNearHalf' else 'void ')+fn+'('
    a=src.index(marker); b=src.index('\n}\n',a)+3
    assert src[a:b] in candidate
assert candidate[candidate.index('__global__ __mix__'):]==src[end:]
assert indent(quant,8) in new
assert candidate.replace(helper+new,old,1)==src
out=root/'v70_onepass';out.mkdir(exist_ok=True)
(out/'kernel.asc').write_bytes(candidate.replace('\n','\r\n').encode('utf-8'))
(out/'v70_vs_v64.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),candidate.splitlines(True),fromfile='v64',tofile='v70')),encoding='utf-8')
(out/'source_checks.json').write_text(json.dumps({'precision_bodies_unchanged':True,'cube_host_global_unchanged':True,'max_ub_bytes':170880,'max_batch':4,'onepass_N':[64,6144],'sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print('Generated v70_onepass:',len(candidate),'characters')
