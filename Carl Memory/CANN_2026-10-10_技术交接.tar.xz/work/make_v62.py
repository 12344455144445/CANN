from pathlib import Path
import hashlib, json, re

root=Path(__file__).resolve().parent
base=(root/'v53_cube512'/'kernel.asc').read_text(encoding='utf-8')
start=base.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
end=base.index('__global__ __mix__',start)
original=base[start:end]
pair=original.replace('quant_matmul_relu_quant_vector(', 'QmqVectorRowPair(')
pair=pair.replace('    constexpr uint32_t kPrefetchSpan = 64U;',
                  '    constexpr uint32_t kPrefetchSpan = 64U;\n    constexpr uint32_t kPairCapacity = 4096;')
for line in pair.splitlines():
    if 'pipe.InitBuffer(' in line and 'kVectorTileN' in line:
        if 'x2ScaleQueue' in line:
            replacement=line.replace('kVectorTileN','2048U')
        else:
            replacement=line.replace('kVectorTileN','kPairCapacity')
        pair=pair.replace(line,replacement)
pair=pair.replace('pipe.InitBuffer(scalarMaxBuffer, kFloatBlock * sizeof(float));',
                  'pipe.InitBuffer(scalarMaxBuffer, 2U * kFloatBlock * sizeof(float));')
p1a=pair.index('        // [OPT-V13] Pass-1 行标量预取')
p1b=pair.index('    // [OPT-V16/PA] 补上',p1a)
pair=pair[:p1a]+(root/'rowpair_pass1.txt').read_text(encoding='utf-8')+pair[p1b:]
p2a=pair.index('        QmqEnqueueWorkspaceTile(',pair.index('DataCopyPad(yScaleGm'))
p2b=pair.index('    x1ScaleQueue.FreeTensor(x1ScaleLocal);',p2a)
pair=pair[:p2a]+(root/'rowpair_pass2.txt').read_text(encoding='utf-8')+pair[p2b:]
for old,new in [('kPrefetchSpan','kPairPrefetchSpan'),('x1Prefetch','pairX1Prefetch'),
                ('x1Prefetch2','pairX1Prefetch2'),('rowMaxPrefetch','pairRowMaxPrefetch'),
                ('rowScalePrefetch','pairRowScalePrefetch')]:
    pair=re.sub(r'\b'+old+r'\b',new,pair)
call='''                quant_matmul_relu_quant_vector(
                    workspace,
                    x1Scale,
                    x2Scale,
                    y,
                    yScale,
                    m,
                    n,
                    localStart + rowOffset,
                    currentRows);'''
newcall='''                if (!tinyShape && n <= 2048U && n % 32U == 0U && currentRows >= 2U) {
                    QmqVectorRowPair(workspace, x1Scale, x2Scale, y, yScale,
                        m, n, localStart + rowOffset, currentRows);
                } else {
'''+call+'''
                }'''
assert base.count(call)==1
candidate=base[:end]+pair+base[end:]
candidate=candidate.replace(call,newcall)
header='// QuantMatmulReluQuant v62: two-row vector batches for aligned N <= 2048.\n'
candidate=header+candidate
assert candidate.count('__global__')==base.count('__global__')
assert candidate.count(original)==1
assert pair.count('{')==pair.count('}')
# All modifications have an exact inverse; no change to original numerical code.
inverse=candidate.removeprefix(header).replace(newcall,call)
inverse=inverse.replace(pair,'',1)
assert inverse==base
folder=root/'v62_rowpair';folder.mkdir(exist_ok=True)
(folder/'kernel.asc').write_bytes(candidate.replace('\n','\r\n').encode('utf-8'))
checks={'original_vector_and_critical_functions_unchanged':True,
        'inverse_transform_exact':True,'gate':'!tinyShape && N<=2048 && N%32==0 && rows>=2',
        'paired_max_ub_bytes':111168,'original_max_ub_bytes':170784,
        'ub_limit_bytes':196608,'queue_packets_max_rows':2,
        'max_div_repeats':64,'largest_pairCompareCount':4096,
        'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest()}
(folder/'source_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks))
