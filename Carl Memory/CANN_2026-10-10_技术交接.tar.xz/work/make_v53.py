from pathlib import Path
import difflib,hashlib
root=Path(__file__).resolve().parent
src=(root/'v51_cube256'/'kernel.asc').read_text(encoding='utf-8')
src=src.replace('v51:', 'v53:').replace('256-column', '512-column').replace('n >= 256U', 'n >= 512U').replace('SetFixSplit(-1, 256, -1)', 'SetFixSplit(-1, 512, -1)')
out=root/'v53_cube512'/'kernel.asc';out.parent.mkdir(exist_ok=True)
out.write_bytes(src.replace('\n','\r\n').encode('utf-8'))
print('sha256',hashlib.sha256(out.read_bytes()).hexdigest())
