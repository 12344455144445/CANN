from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).resolve().parent
base=root/'v75_tiny_vector_quant';out=root/'v76_tiny_batch_quant';out.mkdir(exist_ok=True)
assert not (out/'submission_info.json').exists()
src=(base/'kernel.asc').read_text(encoding='utf-8');changes=[]
def change(old,new):
    global src
    assert src.count(old)==1,old[:70]
    src=src.replace(old,new,1);changes.append((old,new))
change('''    TBuf<TPosition::VECCALC> quantBuffer,tinyCorrectionMaskBuffer;
    pipe.InitBuffer(quantBuffer,256U*sizeof(float));
    pipe.InitBuffer(tinyCorrectionMaskBuffer,32U);''','''    const uint32_t activationStride=32U;
    const uint32_t quantCount=rows*activationStride;
    const uint32_t compareCount=QmqAlignUp(quantCount,64U);
    TBuf<TPosition::VECCALC> quantBuffer,tinyCorrectionMaskBuffer,activationBuffer;
    pipe.InitBuffer(quantBuffer,4U*compareCount*sizeof(float));
    pipe.InitBuffer(tinyCorrectionMaskBuffer,QmqAlignUp(compareCount/8U,32U));
    pipe.InitBuffer(activationBuffer,quantCount*sizeof(float));''')
change('''    const uint32_t firstK=QmqMinValue(k,64U);''','''    auto activationLocal=activationBuffer.Get<float>();
    auto quantLocal=quantBuffer.Get<float>();
    auto quantDivisor=quantLocal[compareCount];
    auto quantResidual=quantLocal[2U*compareCount];
    auto quantScratch=quantLocal[3U*compareCount];
    auto correctionMask=tinyCorrectionMaskBuffer.Get<uint8_t>();
    Duplicate(activationLocal,0.0f,quantCount);
    PipeBarrier<PIPE_ALL>();
    const uint32_t firstK=QmqMinValue(k,64U);''')
start=src.index('        // Use the baseline vector division, near-half correction and output casts.')
end=src.index('    PipeBarrier<PIPE_ALL>();\n    DataCopyExtParams yc',start)
old=src[start:end]
new='''        for(uint32_t j=0;j<n;++j){
            activationLocal.SetValue(r*activationStride+j,activations[j]);
        }
    }
    PipeBarrier<PIPE_ALL>();
    for(uint32_t r=0;r<rows;++r){
        Duplicate(quantDivisor[r*activationStride],ysLocal.GetValue(r),activationStride);
    }
    Duplicate(quantResidual,1.0f,compareCount);
    PipeBarrier<PIPE_V>();
    QmqDiv(quantLocal,activationLocal,quantDivisor,quantCount);
    PipeBarrier<PIPE_V>();
    auto floors=quantScratch.ReinterpretCast<int32_t>();
    Cast(floors,quantLocal,RoundMode::CAST_FLOOR,quantCount);
    PipeBarrier<PIPE_V>();
    Cast(quantResidual,floors,RoundMode::CAST_NONE,quantCount);
    PipeBarrier<PIPE_V>();
    Adds(quantResidual,quantResidual,0.5f,quantCount);
    PipeBarrier<PIPE_V>();
    Sub(quantResidual,quantLocal,quantResidual,quantCount);
    PipeBarrier<PIPE_V>();
    Abs(quantResidual,quantResidual,quantCount);
    PipeBarrier<PIPE_V>();
    Compares(correctionMask,quantResidual,kHalfScreenTolerance,CMPMODE::LT,compareCount);
    PipeBarrier<PIPE_V>();
    auto maskWords=correctionMask.ReinterpretCast<uint64_t>();
    for(uint32_t group=0;group<compareCount/64U;++group){
        uint64_t bits=maskWords.GetValue(group);
        while(bits!=0U){
            const uint32_t bit=static_cast<uint32_t>(AscendC::GetSFFValue<1>(bits));
            const uint32_t lane=group*64U+bit;
            if(lane<quantCount && lane%activationStride<n){
                const uint32_t row=lane/activationStride;
                const int32_t quantized=QmqQuantizeNearHalf(
                    activationLocal.GetValue(lane),ysLocal.GetValue(row),quantLocal.GetValue(lane));
                if(quantized>=0){quantLocal.SetValue(lane,static_cast<float>(quantized));}
            }
            bits&=bits-1U;
        }
    }
    PipeBarrier<PIPE_V>();
    Maxs(quantLocal,quantLocal,0.0f,quantCount);
    Mins(quantLocal,quantLocal,127.0f,quantCount);
    PipeBarrier<PIPE_V>();
    auto quantizedInts=activationLocal.ReinterpretCast<int32_t>();
    Cast(quantizedInts,quantLocal,RoundMode::CAST_RINT,quantCount);
    PipeBarrier<PIPE_V>();
    SetDeqScale(static_cast<half>(1.0f));
    auto halfOutput=quantScratch.ReinterpretCast<half>();
    Cast(halfOutput,quantizedInts,RoundMode::CAST_NONE,quantCount);
    PipeBarrier<PIPE_V>();
    Cast(yLocal,halfOutput,RoundMode::CAST_RINT,quantCount);
'''
change(old,new)
inverse=src
for old,new in reversed(changes):
    assert inverse.count(new)==1;inverse=inverse.replace(new,old,1)
assert inverse==(base/'kernel.asc').read_text(encoding='utf-8')
(out/'kernel.asc').write_bytes(src.replace('\n','\r\n').encode('utf-8'))
for name in ['tiny_checks.json','dot_checks.json','quant_checks.json']:shutil.copy2(base/name,out/name)
(out/'source_checks.json').write_text(json.dumps({'sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest(),'inverse_diff_exact':True,'changed_function':'QmqTryTinyDirect only','dot_dequantization_scale_unchanged':True,'row_storage_stride':32,'quantization':'Same vector precision pipeline as v75, across all rows with per-row divisors and correction scales'},ensure_ascii=False,indent=2),encoding='utf-8')
(out/'SUBMIT.md').write_text('''# v76：小矩阵多行合批量化

v74估算24.4624，v75估算24.4110基本持平。v75每行重复量化流水，
本版同一个AIV内先保存各行真实激活和yScale，再合成一个向量批次处理。
存储步长固定32个fp32，整行padding先Duplicate为0；每行32个divisor元素各用自己的scale。
近半候选必须lane<rows*32且lane%32<N，修正读取scale[lane/32]。
量化四个临时区域均按64float对齐，compare尾部残差初始化1；int32/half中转互不重叠。
输出每行32个int8，最后DataCopyPad(rows个N字节块)紧密写GM。
最多rows96，向量全长3072、Div48repeats，均在255以内；mask最多48个uint64词。
原SIMD点积、两次fp32反量化乘法、尺度计算、非有限/尺度下溢回退不改。
三个精度函数与通用vector/cube/融合入口逐字一致。

必须15/15且0错误。若估算或前三点无明确改善，则选v74做最后原样复测。
本版后优先定案并保存最佳结果，避免继续提交微小调整。
''',encoding='utf-8')
print('Generated',out.name)
