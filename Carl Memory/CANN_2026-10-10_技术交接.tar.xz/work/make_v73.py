from pathlib import Path
import shutil,hashlib,json
root=Path(__file__).resolve().parent
base=root/'v72_tiny_direct'
out=root/'v73_tiny_compile_fix'
out.mkdir(exist_ok=True)
assert not (out/'submission_info.json').exists(), 'Submitted source must be immutable'
text=(base/'kernel.asc').read_text(encoding='utf-8')
old='const float exactHalf = static_cast<float>(lower) + 0.5f;'
new='const float exactHalf = static_cast<float>(static_cast<int32_t>(lower)) + 0.5f;'
assert text.count(old)==1
source=text.replace(old,new,1)
assert source.replace(new,old,1)==text
(out/'kernel.asc').write_bytes(source.replace('\n','\r\n').encode('utf-8'))
shutil.copy2(base/'tiny_checks.json',out/'tiny_checks.json')
report={'sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest(),
        'change':'Only insert int32_t conversion between uint32_t lower and float',
        'diagnostic':'ASC forbids scalar unsigned integer to float conversion in aicore functions',
        'equivalence':'lower is clamped to [0,127]; int32 and fp32 both exactly represent every value',
        'inverse_diff_exact':True,'cpu_checks_reused':'All arithmetic and thresholds unchanged'}
(out/'source_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'SUBMIT.md').write_text('''# v73：修复平台明确给出的编译诊断

v72提交704720仅有一条编译错误：aicore内uint32_t直接cast为float被禁止。
此版唯一改动为 lower → int32_t → float；lower已钳制为[0,127]，两次转换均精确。
其余源码逐字不变，逆diff核对通过，CPU数值证明和覆盖检查仍适用。
原v72错误证据保存在其compile_error_ui.txt，不能覆盖原提交源码。
硬件编译与性能仍以本版独立提交结果为准；本次修复不算已获得性能收益。
''',encoding='utf-8')
print(report)
