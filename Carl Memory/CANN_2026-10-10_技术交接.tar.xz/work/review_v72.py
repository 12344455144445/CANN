from pathlib import Path
import hashlib,json,re,sys

root=Path(__file__).resolve().parent
folder=root/(sys.argv[1] if len(sys.argv)>1 else 'v72_tiny_direct')
source=(folder/'kernel.asc').read_text(encoding='utf-8')
base=(root/'v71_tiny_vector'/'kernel.asc').read_text(encoding='utf-8')
def body(text,name):
    at=text.index(name+'(')
    start=text.index('{',at);depth=1;end=start+1
    while depth:
        depth += (text[end]=='{')-(text[end]=='}');end+=1
    return text[at:end]
unchanged=['QmqQuantizeNearHalf','QmqDiv','QmqCorrectDiv',
           'quant_matmul_relu_quant_vector','quant_matmul_relu_quant_cube',
           'quant_matmul_relu_quant_fused']
assert all(body(source,n)==body(base,n) for n in unchanged)
assert source[source.index('extern "C" void run_kernel'):].split('{',1)[0]==base[base.index('extern "C" void run_kernel'):].split('{',1)[0]
assert len(re.findall(r'__global__',re.sub(r'//[^\n]*','',source)))==2
assert '__global__ __vector__ void qmq_tiny_vector_entry' in source
assert '__global__ __mix__(1, 2) void quant_matmul_relu_quant_fused' in source
assert 'KERNEL_TASK_TYPE_DEFAULT(' not in source
align=lambda x:(x+31)//32*32
maximum_ub=0;maximum_fallback=0;shape_count=0
for n in range(1,33):
    for k in range(1,129):
        if n*k>1024:continue
        for m in range(1,97):
            direct=sum(map(align,[m*k,n*k,m*4,n*4,m*n,m*4]))
            if folder.name in ['v74_tiny_simd_dot','v75_tiny_vector_quant','v76_tiny_batch_quant']:
                stride=align(k)
                direct=7*(m+n)*stride+4*n*stride+align(m*4)+align(n*4)+align(m*n)+align(m*4)+8*((n+7)//8*8)
                if folder.name=='v75_tiny_vector_quant':
                    direct+=1056+m*32-align(m*n)
                if folder.name=='v76_tiny_batch_quant':
                    quant_count=m*32;compare=(quant_count+63)//64*64
                    direct+=m*32-align(m*n)+16*compare+align(compare//8)+4*quant_count
            fallback=align(m*k)+align(n*k)+align(m*n*4)
            maximum_ub=max(maximum_ub,direct)
            maximum_fallback=max(maximum_fallback,fallback)
            shape_count+=1
assert maximum_ub<196608 and maximum_fallback<196608
coverage_count=0
for m in range(1,97):
    for block in range(1,129):
        for blocks_per_group in [1,2]:
            groups=((m+block-1)//block+blocks_per_group-1)//blocks_per_group
            counts=[0]*m
            for index in range(groups*2):
                group=index//2;sub=index%2
                for tile in range(blocks_per_group):
                    off=(group*blocks_per_group+tile)*block
                    end=min(off+block,m);half=(block+1)//2
                    start=off+(0 if sub==0 else half)
                    if start>=end:continue
                    finish=min(off+half,end) if sub==0 else end
                    for r in range(start,finish):counts[r]+=1
            assert all(x==1 for x in counts),(m,block,blocks_per_group)
            coverage_count+=1
assert body(source,'QmqTryTinyDirect').index('return false;')<body(source,'QmqTryTinyDirect').index('DataCopyPad(yGm[')
assert 'volatile float firstScaled=' in source
numerics=json.loads((folder/'tiny_checks.json').read_text())
assert numerics['status']=='PASS'
scale=json.loads((root/'v70_onepass'/'scale127_checks.json').read_text())
data=(folder/'kernel.asc').read_bytes()
assert data.count(b'\n')==data.count(b'\r\n')
report={'review_pass':True,'sha256':hashlib.sha256(data).hexdigest(),
        'unchanged_functions':unchanged,'host_signature_unchanged':True,
        'tiny_shape_configurations_checked':shape_count,'row_coverage_configurations_checked':coverage_count,
        'direct_UB_upper_bound_bytes':maximum_ub,'fallback_tiny_UB_upper_bound_bytes':maximum_fallback,
        'general_vector_UB_bytes':170880,'UB_buffers_mutually_exclusive':True,
        'int32_dot_absolute_bound':128*128*128,'dot_exact_in_fp32':True,
        'writes_to_GM_only_after_all_rows_valid':True,'cpu_numerics':numerics,
        'scale127_checks':scale,'hardware_validation':'NOT RUN: platform compile/pass/timing still required',
        'performance_risk':'Scalar array spills, TPipe lifetime, subnormal multiplication behavior and compiler code layout require hardware validation.'}
if folder.name=='v73_tiny_compile_fix':
    failed=(root/'v72_tiny_direct'/'kernel.asc').read_text(encoding='utf-8')
    patched='static_cast<float>(static_cast<int32_t>(lower))'
    assert source.replace(patched,'static_cast<float>(lower)',1)==failed
    assert source.count(patched)==1
    assert 'static_cast<float>(lower)' not in source
    report['ASC_scalar_unsigned_float_diagnostic_fixed']=True
if folder.name in ['v74_tiny_simd_dot','v75_tiny_vector_quant','v76_tiny_batch_quant']:
    dot_checks=json.loads((folder/'dot_checks.json').read_text())
    assert dot_checks['status']=='PASS'
    assert 'bValues' not in body(source,'QmqTryTinyDirect')
    assert 'accumulators' not in body(source,'QmqTryTinyDirect')
    assert 'static_cast<float>(lower)' not in source
    report['SIMD_dot_checks']=dot_checks
    for line in [
        'Cast(aHalf,aLocal,RoundMode::CAST_NONE,rows*kStride);',
        'Cast(bHalf,bLocal,RoundMode::CAST_NONE,n*kStride);',
        'Cast(aFloat,aHalf,RoundMode::CAST_NONE,rows*kStride);',
        'Cast(bFloat,bHalf,RoundMode::CAST_NONE,n*kStride);']:
        assert source.count(line)==1
    report['legacy_submit_check_result']='FAIL: generic CAST_NONE_on_int_to_float counter increases by 4'
    report['resolved_legacy_guard_warning']='Four new casts are int8->half and half->fp32 only. Every INT8 value is exactly representable in both; official A3 Cast API supports CAST_NONE for these types. Original int32->fp32 RINT unchanged; all three precision functions byte-identical. This is a type-insensitive heuristic warning, not a changed precision function.'
    report['performance_risk']='NPU Cast/Mul/WholeReduceSum compilation, resource lifetimes and timing require platform validation.'
if folder.name=='v75_tiny_vector_quant':
    qc=json.loads((folder/'quant_checks.json').read_text())
    assert qc['status']=='PASS'
    assert 'QmqTinyRoundExact(' not in body(source,'QmqTryTinyDirect')
    assert body(source,'QmqTryTinyDirect').count('QmqDiv(')==1
    assert 'DataCopyExtParams yc{static_cast<uint16_t>(rows),n,0,0,0};' in source
    assert 'Cast(yLocal[r*32U],halfOutput,RoundMode::CAST_RINT,alignedN);' in source
    report['vector_quantization_checks']=qc
    report['legacy_submit_check_result']='Generic CAST_NONE count grows: 4 exact int8/half conversions plus a copy of baseline int32 floor->fp32 NONE and int32->half dequantization cast'
    report['additional_cast_proof']='Floors and rounded ints represent values in [0,128] and [0,127] respectively; both casts retain these integers exactly. Original near-half predicate and final cast order retained.'
if folder.name=='v76_tiny_batch_quant':
    bc=json.loads((folder/'batch_checks.json').read_text())
    assert bc['status']=='PASS'
    assert 'QmqTinyRoundExact(' not in body(source,'QmqTryTinyDirect')
    assert 'lane<quantCount && lane%activationStride<n' in source
    assert 'ysLocal.GetValue(row)' in source
    assert 'DataCopyExtParams yc{static_cast<uint16_t>(rows),n,0,0,0};' in source
    assert 'Cast(yLocal,halfOutput,RoundMode::CAST_RINT,quantCount);' in source
    report['batch_quantization_checks']=bc
    report['legacy_submit_check_result']='Type-insensitive CAST_NONE counter increases for exact INT8/half/fp32 conversions and retained original quantization casts; separately verified'
(folder/'review_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['review_pass','sha256','tiny_shape_configurations_checked','row_coverage_configurations_checked','direct_UB_upper_bound_bytes','fallback_tiny_UB_upper_bound_bytes','hardware_validation']},ensure_ascii=False))
