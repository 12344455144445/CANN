from pathlib import Path
import hashlib, json

root=Path(__file__).resolve().parent
base=(root/'v53_cube512'/'kernel.asc').read_text(encoding='utf-8')
src=(root/'v62_rowpair'/'kernel.asc').read_text(encoding='utf-8')
start=src.index('__aicore__ inline void QmqVectorRowPair(')
end=src.index('__global__ __mix__',start)
pair=src[start:end].replace('QmqVectorRowPair(', 'quant_matmul_relu_quant_vector(')
pair=pair.replace('constexpr uint32_t kPairCapacity = 4096;',
                  'constexpr uint32_t kPairCapacity = 6144;\n'
                  '    const uint32_t rowBatchLimit = (n >= 64U && n <= 3072U && n % 32U == 0U) ? 2U : 1U;')
pair=pair.replace('pipe.InitBuffer(x2ScaleQueue, 1, 2048U * sizeof(float));',
                  'pipe.InitBuffer(x2ScaleQueue, 1, kPairCapacity * sizeof(float));')
pair=pair.replace('QmqMinValue(2U,', 'QmqMinValue(rowBatchLimit,')
pair=pair.replace('row += 2U', 'row += rowBatchLimit')
pair=pair.replace('if (lane < pairCount) {',
                  'if (lane < pairCount && lane % alignedN < currentN) {')
a=base.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
b=base.index('__global__ __mix__',a)
header='// QuantMatmulReluQuant v63: one shared vector path, 1/2-row batches, original 6144 buffers.\n'
candidate=header+base[:a]+pair+base[b:]
assert candidate.removeprefix(header).replace(pair,base[a:b],1)==base
assert candidate.count('__global__')==base.count('__global__')
assert candidate.count('void quant_matmul_relu_quant_vector(')==1
assert candidate.count('{')==candidate.count('}')
folder=root/'v63_rowpair_full';folder.mkdir(exist_ok=True)
(folder/'kernel.asc').write_bytes(candidate.replace('\n','\r\n').encode('utf-8'))
checks={'one_vector_function':True,'inverse_transform_exact':True,
        'three_precision_functions_and_cube_unchanged':True,
        'max_ub_bytes':170816,'ub_limit_bytes':196608,
        'pair_gate':'64<=N<=3072 and N%32==0; otherwise one row',
        'max_div_repeats':96,
        'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest()}
(folder/'source_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
(folder/'SUBMIT.md').write_text('''# v63：单一向量路径与原容量复用

依据：v62正确但tiny与多个中点也退化，新增整套内联路径可能有额外代码/资源开销。
本版不增加第二个vector函数，不增加整套缓冲；保留原6144容量，只给scalarMax加32 B。
64≤N≤3072且N整除32时每包两行，其余每包一行；tiny N≤32保证单行。
N非对齐时仅单行原DataCopyPad，近半mask显式排除补齐lane。
零行显式填零；三项精度函数、Cube、全局签名和flags未改。
通用UB峰值170816 B <196608 B，不能将旧基准166.8KB当硬件容量。

预登记：15/15为必要条件；相对下午控制版至少+0.6分才有明确提分证据。
若幅度较小或局部退化，继续收窄到有收益的真实形状范围；若全线退化则撤回。
代码体积/寄存器解释仍为假设，实际原因需profile，不作确定归因。
''',encoding='utf-8')
print(json.dumps(checks))
