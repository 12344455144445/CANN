from pathlib import Path
import json,numpy as np
root=Path(__file__).resolve().parent
rng=np.random.default_rng(2026101075)
maximum=rng.integers(127,0x7f800000,250000,dtype=np.uint32).view(np.float32)
scale=maximum/np.float32(127)
a=(rng.random(maximum.size)*maximum.view(np.uint32)).astype(np.uint32).view(np.float32)
expected=np.clip(np.rint(a/scale),0,127).astype(np.int8)
# Include fp32 values immediately adjacent to half-way quotients.
s=rng.integers(127,0x79000000,25000,dtype=np.uint32).view(np.float32)
lo=rng.integers(0,127,s.size,dtype=np.int32)
half=(lo.astype(np.float32)+np.float32(.5))*s
aa=np.concatenate([np.nextafter(half,-np.inf,dtype=np.float32),half,np.nextafter(half,np.inf,dtype=np.float32)])
ss=np.tile(s,3)
a=np.concatenate([a,aa]);scale=np.concatenate([scale,ss])
expected=np.clip(np.rint(a/scale),0,127).astype(np.int8)
true_q=a/scale
assert np.isfinite(true_q).all()
checked=0
for direction in [-1,0,1]:
    for steps in ([1,2] if direction else [0]):
        approx=true_q.copy()
        for _ in range(steps):approx=np.nextafter(approx,np.inf if direction>0 else -np.inf,dtype=np.float32)
        floors=np.floor(approx).astype(np.int32)
        center=floors.astype(np.float32)+np.float32(.5)
        residue=np.abs(approx-center)
        eligible=residue<np.float32(.00002)
        qword=approx.view(np.uint32);hword=center.view(np.uint32)
        distance=np.abs(qword.astype(np.int64)-hword.astype(np.int64))
        # Unchanged QmqQuantizeNearHalf accepts only approximations within 2 ULPs.
        accepted=eligible&(distance<=2)&(a>0)&(approx>=0)&(approx<=128)
        corrected=approx.copy();corrected[accepted]=np.rint(true_q[accepted])
        actual=np.clip(np.rint(corrected),0,127).astype(np.int8)
        assert np.array_equal(actual,expected),(direction,steps,np.flatnonzero(actual!=expected)[:8])
        checked+=len(a)
layout_cases=0
for rows in range(1,97):
    for n in range(1,33):
        stride=32
        aligned=(n+7)//8*8
        ub=np.full((rows,stride),-99,np.int8)
        values=rng.integers(0,128,(rows,n),dtype=np.int8)
        ub[:,:n]=values;ub[:,n:aligned]=0
        # UB source advances by align_up(blockLen,32), GM advances by blockLen.
        gm=np.concatenate([ub[row,:n] for row in range(rows)])
        assert np.array_equal(gm.reshape(rows,n),values)
        # half output occupies [0,2*aligned), int32 input [4*aligned,8*aligned).
        assert 2*aligned<=4*aligned
        assert 8*aligned<=8*aligned
        layout_cases+=1
report={'status':'PASS','quant_values_with_approximation_variants':checked,'output_packing_and_cast_storage_cases':layout_cases,
        'limitation':'CPU verifies baseline near-half screening for division approximations up to 2 ULP. It cannot establish actual NPU Div error bounds, DMA synchronization or performance; platform regression remains required.'}
(root/'v75_tiny_vector_quant'/'quant_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(report)
