from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
src=(root/'v53_cube512'/'kernel.asc').read_text(encoding='utf-8')
src=src.replace('v53:', 'v54:').replace('512-column','1024-column').replace('n >= 512U','n >= 1024U').replace('SetFixSplit(-1, 512, -1)','SetFixSplit(-1, 1024, -1)')
out=root/'v54_cube1024'/'kernel.asc';out.parent.mkdir(exist_ok=True)
out.write_bytes(src.replace('\n','\r\n').encode('utf-8'))
print('sha256',hashlib.sha256(out.read_bytes()).hexdigest())
