from pathlib import Path
import difflib,hashlib
root=Path(__file__).resolve().parent
src=(root/'v50_cache'/'kernel.asc').read_text(encoding='utf-8')
needle='__aicore__ inline void quant_matmul_relu_quant_vector('
assert src.count(needle)==1
src=src.replace(needle,'template <bool CacheRows>\n'+needle)
src=src.replace('const bool useRowCache = cacheTileN != 0U && cacheUbBytes <= 180224ULL;', 'const bool useRowCache = CacheRows;')
helper='''__aicore__ inline bool QmqEnableRowCache(uint32_t n, uint32_t rows)
{
    if (n == 0U || n > 4096U || rows == 0U || rows > kVectorTileRows) {
        return false;
    }
    const uint32_t alignedRows = QmqAlignUp(rows, kFloatBlock);
    const uint32_t tile = QmqAlignUp(n > alignedRows ? n : alignedRows, 64U);
    const uint64_t bytes = static_cast<uint64_t>(tile) * (25ULL + 4ULL * rows) +
        QmqAlignUp(tile / 8U, 32U) + static_cast<uint64_t>(alignedRows) * 16ULL + 32ULL;
    return bytes <= 180224ULL;
}

'''
src=src.replace('__global__ __mix__(1, 2)',helper+'__global__ __mix__(1, 2)',1)
old='''                quant_matmul_relu_quant_vector(
                    workspace,
                    x1Scale,
                    x2Scale,
                    y,
                    yScale,
                    m,
                    n,
                    localStart + rowOffset,
                    currentRows);'''
assert src.count(old)==1
new='''                if (QmqEnableRowCache(n, currentRows)) {
                    quant_matmul_relu_quant_vector<true>(
                        workspace, x1Scale, x2Scale, y, yScale,
                        m, n, localStart + rowOffset, currentRows);
                } else {
                    quant_matmul_relu_quant_vector<false>(
                        workspace, x1Scale, x2Scale, y, yScale,
                        m, n, localStart + rowOffset, currentRows);
                }'''
src=src.replace(old,new)
src='// QuantMatmulReluQuant v56: compile-time cache/no-cache vector specializations.\n'+src
out=root/'v56_cache_template'/'kernel.asc';out.parent.mkdir(exist_ok=True)
out.write_bytes(src.replace('\n','\r\n').encode('utf-8'))
base=(root/'baseline'/'v49_候选'/'kernel.asc').read_text(encoding='utf-8')
(out.parent/'v56_vs_v49.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),src.splitlines(True),fromfile='v49',tofile='v56')),encoding='utf-8')
print('sha256',hashlib.sha256(out.read_bytes()).hexdigest())
