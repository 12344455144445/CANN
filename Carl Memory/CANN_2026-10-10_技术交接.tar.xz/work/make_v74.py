from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).resolve().parent
base=root/'v73_tiny_compile_fix'
out=root/'v74_tiny_simd_dot';out.mkdir(exist_ok=True)
assert not (out/'submission_info.json').exists()
src=(base/'kernel.asc').read_text(encoding='utf-8')
changes=[]
def change(old,new):
    global src
    assert src.count(old)==1,old[:80]
    src=src.replace(old,new,1);changes.append((old,new))
change('''    TBuf<TPosition::VECCALC> aBuffer,bBuffer,s1Buffer,s2Buffer,yBuffer,ysBuffer;
    pipe.InitBuffer(aBuffer,QmqAlignUp(rows*k,32U));
    pipe.InitBuffer(bBuffer,QmqAlignUp(n*k,32U));''','''    const uint32_t kStride=QmqAlignUp(k,32U);
    const uint32_t alignedN=QmqAlignUp(n,8U);
    TBuf<TPosition::VECCALC> aBuffer,bBuffer,s1Buffer,s2Buffer,yBuffer,ysBuffer;
    TBuf<TPosition::VECCALC> aHalfBuffer,bHalfBuffer,aFloatBuffer,bFloatBuffer,productBuffer,sumBuffer;
    pipe.InitBuffer(aBuffer,rows*kStride);
    pipe.InitBuffer(bBuffer,n*kStride);
    pipe.InitBuffer(aHalfBuffer,rows*kStride*sizeof(half));
    pipe.InitBuffer(bHalfBuffer,n*kStride*sizeof(half));
    pipe.InitBuffer(aFloatBuffer,rows*kStride*sizeof(float));
    pipe.InitBuffer(bFloatBuffer,n*kStride*sizeof(float));
    pipe.InitBuffer(productBuffer,n*kStride*sizeof(float));
    pipe.InitBuffer(sumBuffer,2U*alignedN*sizeof(float));''')
change('''    DataCopyExtParams ac{1,rows*k,0,0,0},bc{1,n*k,0,0,0};''','''    DataCopyExtParams ac{static_cast<uint16_t>(rows),k,0,0,0};
    DataCopyExtParams bc{static_cast<uint16_t>(n),k,0,0,0};''')
change('''    DataCopyPadExtParams<int8_t> ap{true,0,static_cast<uint8_t>(QmqAlignUp(rows*k,32U)-rows*k),0};
    DataCopyPadExtParams<int8_t> bp{true,0,static_cast<uint8_t>(QmqAlignUp(n*k,32U)-n*k),0};''','''    DataCopyPadExtParams<int8_t> ap{true,0,static_cast<uint8_t>(kStride-k),0};
    DataCopyPadExtParams<int8_t> bp{true,0,static_cast<uint8_t>(kStride-k),0};''')
change('''    int32_t bValues[1024];
    float s2Values[32];
    for(uint32_t i=0;i<n*k;++i){bValues[i]=static_cast<int32_t>(bLocal.GetValue(i));}
    for(uint32_t j=0;j<n;++j){s2Values[j]=s2Local.GetValue(j);}
    for(uint32_t r=0;r<rows;++r){
        int32_t accumulators[32];
        float activations[32];
        for(uint32_t j=0;j<n;++j){accumulators[j]=0;}
        for(uint32_t l=0;l<k;++l){
            const int32_t coefficient=static_cast<int32_t>(aLocal.GetValue(r*k+l));
            for(uint32_t j=0;j<n;++j){accumulators[j]+=coefficient*bValues[j*k+l];}
        }''','''    auto aHalf=aHalfBuffer.Get<half>();
    auto bHalf=bHalfBuffer.Get<half>();
    auto aFloat=aFloatBuffer.Get<float>();
    auto bFloat=bFloatBuffer.Get<float>();
    auto products=productBuffer.Get<float>();
    auto sums=sumBuffer.Get<float>();
    Cast(aHalf,aLocal,RoundMode::CAST_NONE,rows*kStride);
    Cast(bHalf,bLocal,RoundMode::CAST_NONE,n*kStride);
    PipeBarrier<PIPE_V>();
    Cast(aFloat,aHalf,RoundMode::CAST_NONE,rows*kStride);
    Cast(bFloat,bHalf,RoundMode::CAST_NONE,n*kStride);
    PipeBarrier<PIPE_V>();
    const uint32_t firstK=QmqMinValue(k,64U);
    const uint8_t rowRepStride=static_cast<uint8_t>(kStride/8U);
    const BinaryRepeatParams dotParams{1,1,1,rowRepStride,0,rowRepStride};
    float s2Values[32];
    for(uint32_t j=0;j<n;++j){s2Values[j]=s2Local.GetValue(j);}
    for(uint32_t r=0;r<rows;++r){
        float activations[32];
        Mul(products,aFloat[r*kStride],bFloat,static_cast<uint64_t>(firstK),
            static_cast<uint8_t>(n),dotParams);
        if(k>64U){
            Mul(products[64U],aFloat[r*kStride+64U],bFloat[64U],
                static_cast<uint64_t>(k-64U),static_cast<uint8_t>(n),dotParams);
        }
        PipeBarrier<PIPE_V>();
        WholeReduceSum(sums,products,static_cast<int32_t>(firstK),
            static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
        if(k>64U){
            WholeReduceSum(sums[alignedN],products[64U],static_cast<int32_t>(k-64U),
                static_cast<int32_t>(n),1,1,static_cast<int32_t>(rowRepStride));
            PipeBarrier<PIPE_V>();
            Add(sums,sums,sums[alignedN],n);
        }
        PipeBarrier<PIPE_ALL>();''')
change('''            volatile float firstScaled=static_cast<float>(accumulators[j])*s1;''','''            volatile float firstScaled=sums.GetValue(j)*s1;''')
original=src
for old,new in reversed(changes):
    assert original.count(new)==1
    original=original.replace(new,old,1)
assert original==(base/'kernel.asc').read_text(encoding='utf-8')
(out/'kernel.asc').write_bytes(src.replace('\n','\r\n').encode('utf-8'))
shutil.copy2(base/'tiny_checks.json',out/'tiny_checks.json')
(out/'source_checks.json').write_text(json.dumps({'sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest(),'inverse_diff_exact':True,'changed_function':'QmqTryTinyDirect only','tiny_gate_unchanged':True,'quantization_unchanged':True,'arithmetic_proof':'All int8 values exact in half and fp32; products and any sum for K<=128 exact in fp32; binary repeat broadcasts A over all N rows; K>64 split into two exact sums.'},ensure_ascii=False,indent=2),encoding='utf-8')
(out/'SUBMIT.md').write_text('''# v74：小矩阵点积SIMD化

v73正确但前三点23.56/16.78/19.50us比基线慢；不保留为最终版。
本版仅改QmqTryTinyDirect的点积实现，避免N*K次B标量读取和大栈数组。
int8→half→fp32逐位精确，再以Mul广播A行、WholeReduceSum归约K，同时处理N列。
K≤128，每项积绝对值≤16384，任何归约中间和≤2097152<2^24，fp32仍精确。
K>64时分两段，两个部分之和同样精确；反量化的两次fp32乘法和舍入函数不改。
每个K行补齐32元素，DataCopyPad自定义补0≤31B；repeatStride单位32B，
fp32每行kStride元素所以stride=kStride/8，A stride=0实现广播。
WholeReduceSum dstRepStride=1以fp32元素为单位，输出N个连续和。
特殊值/尺度下溢仍退出到原C+向量路径，输出GM写入保持最后统一提交。

API依据：
https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0081.html
https://www.hiascend.com/document/detail/zh/canncommercial/83RC1/API/ascendcopapi/atlasascendc_api_07_0072.html
https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/900/API/ascendcopapi/atlasascendc_api_07_0265.html

判读：必须15/15且0错误。前三点接近或优于v64才继续；明显退化则结束该点积路径，
收益达到约0.4分才考虑原样复测。未硬件验证前不将此版称为推荐。
''',encoding='utf-8')
print('Generated',out.name)
