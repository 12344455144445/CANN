from pathlib import Path
import difflib
import hashlib
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'baseline' / 'v49_候选' / 'kernel.asc'
OUT = ROOT / 'v50_cache' / 'kernel.asc'
src = BASE.read_text(encoding='utf-8')
start = src.index('__aicore__ inline void quant_matmul_relu_quant_vector(')
end = src.index('__global__ __mix__', start)
body = src[start:end]

def replace_once(old, new):
    global body
    assert body.count(old) == 1, (old[:100], body.count(old))
    body = body.replace(old, new, 1)

replace_once('    const uint32_t alignedRows = QmqAlignUp(rows, kFloatBlock);', '''    const uint32_t alignedRows = QmqAlignUp(rows, kFloatBlock);
    // Cache exact fp32 dequantization only when the full N dimension fits.
    // Queue/buffer sizes include 32-byte allocation alignment.
    const uint32_t cacheTileN = n <= 4096U
        ? QmqAlignUp(n > alignedRows ? n : alignedRows, 64U) : 0U;
    const uint64_t cacheUbBytes = static_cast<uint64_t>(cacheTileN) *
        (25ULL + 4ULL * rows) + QmqAlignUp(cacheTileN / 8U, 32U) +
        static_cast<uint64_t>(alignedRows) * 16ULL + 32ULL;
    const bool useRowCache = cacheTileN != 0U && cacheUbBytes <= 180224ULL;
    const uint32_t vectorTileN = useRowCache ? cacheTileN : kVectorTileN;''')
# Change only this function's buffer capacity and tile stride.
body = body.replace('kVectorTileN', 'vectorTileN')
body = body.replace('useRowCache ? cacheTileN : vectorTileN', 'useRowCache ? cacheTileN : kVectorTileN')
replace_once('    TBuf<TPosition::VECCALC> correctionMaskBuffer;', '''    TBuf<TPosition::VECCALC> correctionMaskBuffer;
    TBuf<TPosition::VECCALC> rowCacheBuffer;''')
replace_once('    pipe.InitBuffer(correctionMaskBuffer, vectorTileN / 8U);', '''    pipe.InitBuffer(correctionMaskBuffer, QmqAlignUp(vectorTileN / 8U, 32U));
    if (useRowCache) {
        pipe.InitBuffer(rowCacheBuffer, rows * vectorTileN * sizeof(float));
    }''')
pass1_end = body.index('    // [OPT-V16/PA] 补上')
p1, p2 = body[:pass1_end], body[pass1_end:]
needle = '                Mul(fp32Local, fp32Local, x2ScaleLocal, alignedN);\n                PipeBarrier<PIPE_V>();'
assert p1.count(needle) == 1
p1 = p1.replace(needle, needle + '''
                if (useRowCache) {
                    LocalTensor<float> cachedRow =
                        rowCacheBuffer.Get<float>()[globalRow * vectorTileN];
                    DataCopy(cachedRow, fp32Local, alignedN);
                    PipeBarrier<PIPE_V>();
                }''', 1)
body = p1+p2

replace_once('''        QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
            static_cast<uint64_t>(rowStart) * n + nOffset, currentN, alignedN);

        // [OPT-V14]''', '''        if (!useRowCache) {
            QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
                static_cast<uint64_t>(rowStart) * n + nOffset, currentN, alignedN);
        }

        // [OPT-V14]''')
replace_once('''                LocalTensor<int32_t> inputLocal = workspaceQueue.DeQue<int32_t>();
                if (globalRow + 1U < rows) {
                    QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
                        static_cast<uint64_t>(rowStart + globalRow + 1U) * n + nOffset,
                        currentN, alignedN);
                }

                LocalTensor<float> fp32Local = fp32Buffer.Get<float>();
                Cast(fp32Local, inputLocal, RoundMode::CAST_RINT, alignedN);
                PipeBarrier<PIPE_V>();
                Muls(fp32Local, fp32Local, x1Prefetch2[row], alignedN);
                PipeBarrier<PIPE_V>();
                Mul(fp32Local, fp32Local, x2ScaleLocal, alignedN);
                PipeBarrier<PIPE_V>();''', '''                LocalTensor<int32_t> inputLocal;
                if (useRowCache) {
                    inputLocal = workspaceQueue.AllocTensor<int32_t>();
                } else {
                    inputLocal = workspaceQueue.DeQue<int32_t>();
                    if (globalRow + 1U < rows) {
                        QmqEnqueueWorkspaceTile(workspaceQueue, workspaceGm,
                            static_cast<uint64_t>(rowStart + globalRow + 1U) * n + nOffset,
                            currentN, alignedN);
                    }
                }

                LocalTensor<float> fp32Local = fp32Buffer.Get<float>();
                if (useRowCache) {
                    LocalTensor<float> cachedRow =
                        rowCacheBuffer.Get<float>()[globalRow * vectorTileN];
                    DataCopy(fp32Local, cachedRow, alignedN);
                    PipeBarrier<PIPE_V>();
                } else {
                    Cast(fp32Local, inputLocal, RoundMode::CAST_RINT, alignedN);
                    PipeBarrier<PIPE_V>();
                    Muls(fp32Local, fp32Local, x1Prefetch2[row], alignedN);
                    PipeBarrier<PIPE_V>();
                    Mul(fp32Local, fp32Local, x2ScaleLocal, alignedN);
                    PipeBarrier<PIPE_V>();
                }''')

# The entire precision-sensitive scan and conversion tail must remain literal.
scan_start = src.index('                if (rowMaxPrefetch[row] > 0.0f) {', start)
scan_end = src.index('            workspaceQueue.FreeTensor(inputLocal);', scan_start)
assert src[scan_start:scan_end] in body
candidate = src[:start] + body + src[end:]
header = '''// QuantMatmulReluQuant v50: exact per-row fp32 reuse across the two passes.
// Baseline: v49. Only runtime shapes whose full rows fit the UB budget use cache.
// Cast-RINT -> x1Scale multiply -> x2Scale multiply ordering is unchanged.
// QmqDiv, QmqCorrectDiv, QmqQuantizeNearHalf and correction scan are unchanged.
// Other shapes retain the original 6144-column two-pass dataflow.
'''
candidate = header + candidate
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(candidate.replace('\n','\r\n').encode('utf-8'))
(OUT.parent/'v50_vs_v49.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True), candidate.splitlines(True),fromfile='v49/kernel.asc',tofile='v50/kernel.asc')),encoding='utf-8')
print(OUT)
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('scan + quantization tail literal match: PASS')
