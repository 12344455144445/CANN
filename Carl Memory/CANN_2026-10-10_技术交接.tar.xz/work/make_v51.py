from pathlib import Path
import hashlib
import difflib
root=Path(__file__).resolve().parent
src=(root/'baseline'/'v49_候选'/'kernel.asc').read_text(encoding='utf-8')
needle='    tilingApi.SetBufferSpace(-1, -1, -1);'
assert src.count(needle)==1
patch='''
    // Keep the row/core mapping; let the API derive a coherent K/L1 schedule
    // for a 256-column Cube base tile. The full single-core N remains n.
    if (n >= 256U) {
        if (tilingApi.SetFixSplit(-1, 256, -1) == -1) {
            tilingApi.SetFixSplit(-1, -1, -1);
        }
    }
'''
candidate='// QuantMatmulReluQuant v51: 256-column Cube base tile, v49 numeric path.\n'+src.replace(needle,needle+'\n'+patch)
out=root/'v51_cube256'/'kernel.asc'
out.parent.mkdir(exist_ok=True)
out.write_bytes(candidate.replace('\n','\r\n').encode('utf-8'))
(out.parent/'v51_vs_v49.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),candidate.splitlines(True),fromfile='v49',tofile='v51')),encoding='utf-8')
print('sha256',hashlib.sha256(out.read_bytes()).hexdigest())
