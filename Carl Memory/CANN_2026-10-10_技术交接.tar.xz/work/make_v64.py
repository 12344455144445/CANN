from pathlib import Path
import hashlib,json

root=Path(__file__).resolve().parent
base=(root/'v63_rowpair_full'/'kernel.asc').read_text(encoding='utf-8')
old='const uint32_t rowBatchLimit = (n >= 64U && n <= 3072U && n % 32U == 0U) ? 2U : 1U;'
new='const uint32_t rowBatchLimit = (n >= 64U && n <= 3072U && n % 32U == 0U)\n        ? QmqMinValue(4U, kPairCapacity / n) : 1U;'
old_scalar='pipe.InitBuffer(scalarMaxBuffer, 2U * kFloatBlock * sizeof(float));'
new_scalar='pipe.InitBuffer(scalarMaxBuffer, 4U * kFloatBlock * sizeof(float));'
assert base.count(old)==1 and base.count(old_scalar)==1
candidate=base.replace(old,new).replace(old_scalar,new_scalar)
assert candidate.replace(new,old).replace(new_scalar,old_scalar)==base
folder=root/'v64_rowpair_guard';folder.mkdir(exist_ok=True)
(folder/'kernel.asc').write_bytes(candidate.replace('\n','\r\n').encode('utf-8'))
# Model the queue packets, including a 3-row batch straddling a 64-row group.
for rows in range(1,1025):
    for limit in range(1,5):
        packet=(0,min(limit,rows))
        covered=[]
        for group in range(0,rows,64):
            for row in range(group,min(group+64,rows),limit):
                active=min(limit,min(group+64,rows)-row)
                assert packet[0]==row and packet[1]>=active
                assert packet[0]+packet[1]<=rows
                covered.extend(range(row,row+active))
                if row+active<rows:packet=(row+active,min(limit,rows-row-active))
        assert covered==list(range(rows))
for n in range(64,3073,32):
    limit=min(4,6144//n)
    assert limit*n<=6144 and (limit*n+63)//64*64<=6144
report={'single_change':'batch ceiling 2 -> min(4,6144/N); scalarMax supports 4 slots',
        'max_ub_bytes':170880,'ub_limit_bytes':196608,'queue_shapes_checked':4096,
        'max_div_repeats':96,'inverse_transform_exact':True,
        'sha256':hashlib.sha256((folder/'kernel.asc').read_bytes()).hexdigest()}
(folder/'source_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
(folder/'SUBMIT.md').write_text('''# v64：按容量扩大到最多四行合批

基于v63已实测15/15及第4/5/6点的局部收益，只将同一流水的批量上限从2行
扩大到min(4,6144/N)，scalarMax相应扩到4个独立32B槽。
其他全部活代码与v63一致，精度函数零改动。
只在64≤N≤3072、N整除32时生效；活动元素数始终≤6144。
UB170880 B<196608 B。对rows1..1024、batch1..4的队列模拟覆盖4096种组合。
三行合批遇64行边界时，前一包可能预取后组的两行，但当前计算只使用当前组
有效前缀，并为下一组重新预取；所有读取仍在本AIV已经就绪的rows范围内。

预登记：必须15/15且0错误；如果相对v63没有一致改善，则最终退回v63并复测。
如果收益明确，最后原样复测v64，确认后作为推荐版本。
''',encoding='utf-8')
print(json.dumps(report))
