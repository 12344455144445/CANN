from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
base=(root/'v71_tiny_vector'/'kernel.asc').read_text(encoding='utf-8')
v70=(root/'v70_onepass'/'kernel.asc').read_text(encoding='utf-8')
a=v70.index('// Exact round-to-nearest-even division')
b=v70.index('__aicore__ inline void quant_matmul_relu_quant_vector(',a)
scale=v70[a:b]
helper='''// Exact fp32 rint for a positive activation/scale, using the original half-threshold predicate.
__aicore__ inline int32_t QmqTinyRoundExact(float activation, float scale)
{
    if (!(activation > 0.0f)) {
        return 0;
    }
    union { float value; uint32_t bits; } aw, sw;
    aw.value = activation;
    sw.value = scale;
    const uint32_t ae = (aw.bits >> 23U) & 255U;
    const uint32_t se = (sw.bits >> 23U) & 255U;
    const uint32_t am = (aw.bits & 0x7fffffU) | (ae == 0U ? 0U : 0x800000U);
    const uint32_t sm = (sw.bits & 0x7fffffU) | (se == 0U ? 0U : 0x800000U);
    const int32_t shift = static_cast<int32_t>(ae == 0U ? 1U : ae) -
                          static_cast<int32_t>(se == 0U ? 1U : se);
    if (shift <= -2) {
        return 0;
    }
    if (shift >= 9) {
        return 127;
    }
    const uint32_t numerator = shift >= 0 ? am << static_cast<uint32_t>(shift) : am;
    const uint32_t denominator = shift >= 0 ? sm : sm << static_cast<uint32_t>(-shift);
    const uint32_t lower = QmqMinValue(numerator / denominator, 127U);
    const float exactHalf = static_cast<float>(lower) + 0.5f;
    const int32_t rounded = QmqQuantizeNearHalf(activation, scale, exactHalf);
    return rounded > 127 ? 127 : rounded;
}

// Integer dot products fit int32 and fp32 exactly because K<=128.
// Scalar multiplications are separated by a volatile fp32 temporary.
__aicore__ inline bool QmqTryTinyDirect(
    GM_ADDR x1, GM_ADDR x2, GM_ADDR x1Scale, GM_ADDR x2Scale, GM_ADDR y, GM_ADDR yScale,
    uint32_t m, uint32_t n, uint32_t k, uint32_t rowStart, uint32_t rows)
{
    GlobalTensor<int8_t> aGm, bGm, yGm;
    GlobalTensor<float> s1Gm, s2Gm, ysGm;
    aGm.SetGlobalBuffer(reinterpret_cast<__gm__ int8_t*>(x1), static_cast<uint64_t>(m)*k);
    bGm.SetGlobalBuffer(reinterpret_cast<__gm__ int8_t*>(x2), static_cast<uint64_t>(n)*k);
    s1Gm.SetGlobalBuffer(reinterpret_cast<__gm__ float*>(x1Scale),m);
    s2Gm.SetGlobalBuffer(reinterpret_cast<__gm__ float*>(x2Scale),n);
    yGm.SetGlobalBuffer(reinterpret_cast<__gm__ int8_t*>(y),static_cast<uint64_t>(m)*n);
    ysGm.SetGlobalBuffer(reinterpret_cast<__gm__ float*>(yScale),m);
    TPipe pipe;
    TBuf<TPosition::VECCALC> aBuffer,bBuffer,s1Buffer,s2Buffer,yBuffer,ysBuffer;
    pipe.InitBuffer(aBuffer,QmqAlignUp(rows*k,32U));
    pipe.InitBuffer(bBuffer,QmqAlignUp(n*k,32U));
    pipe.InitBuffer(s1Buffer,QmqAlignUp(rows*sizeof(float),32U));
    pipe.InitBuffer(s2Buffer,QmqAlignUp(n*sizeof(float),32U));
    pipe.InitBuffer(yBuffer,QmqAlignUp(rows*n,32U));
    pipe.InitBuffer(ysBuffer,QmqAlignUp(rows*sizeof(float),32U));
    auto aLocal=aBuffer.Get<int8_t>();
    auto bLocal=bBuffer.Get<int8_t>();
    auto s1Local=s1Buffer.Get<float>();
    auto s2Local=s2Buffer.Get<float>();
    auto yLocal=yBuffer.Get<int8_t>();
    auto ysLocal=ysBuffer.Get<float>();
    DataCopyExtParams ac{1,rows*k,0,0,0},bc{1,n*k,0,0,0};
    DataCopyExtParams s1c{1,static_cast<uint32_t>(rows*sizeof(float)),0,0,0},s2c{1,static_cast<uint32_t>(n*sizeof(float)),0,0,0};
    DataCopyPadExtParams<int8_t> ap{true,0,static_cast<uint8_t>(QmqAlignUp(rows*k,32U)-rows*k),0};
    DataCopyPadExtParams<int8_t> bp{true,0,static_cast<uint8_t>(QmqAlignUp(n*k,32U)-n*k),0};
    DataCopyPadExtParams<float> s1p{true,0,static_cast<uint8_t>(QmqAlignUp(rows,8U)-rows),0.0f};
    DataCopyPadExtParams<float> s2p{true,0,static_cast<uint8_t>(QmqAlignUp(n,8U)-n),0.0f};
    DataCopyPad(aLocal,aGm[static_cast<uint64_t>(rowStart)*k],ac,ap);
    DataCopyPad(bLocal,bGm,bc,bp);
    DataCopyPad(s1Local,s1Gm[rowStart],s1c,s1p);
    DataCopyPad(s2Local,s2Gm,s2c,s2p);
    PipeBarrier<PIPE_ALL>();
    int32_t bValues[1024];
    float s2Values[32];
    for(uint32_t i=0;i<n*k;++i){bValues[i]=static_cast<int32_t>(bLocal.GetValue(i));}
    for(uint32_t j=0;j<n;++j){s2Values[j]=s2Local.GetValue(j);}
    for(uint32_t r=0;r<rows;++r){
        int32_t accumulators[32];
        float activations[32];
        for(uint32_t j=0;j<n;++j){accumulators[j]=0;}
        for(uint32_t l=0;l<k;++l){
            const int32_t coefficient=static_cast<int32_t>(aLocal.GetValue(r*k+l));
            for(uint32_t j=0;j<n;++j){accumulators[j]+=coefficient*bValues[j*k+l];}
        }
        const float s1=s1Local.GetValue(r);
        float maximum=0.0f;
        for(uint32_t j=0;j<n;++j){
            volatile float firstScaled=static_cast<float>(accumulators[j])*s1;
            const float dequantized=firstScaled*s2Values[j];
            union { float value; uint32_t bits; } check;
            check.value=dequantized;
            if((check.bits&0x7f800000U)==0x7f800000U){return false;}
            activations[j]=dequantized>0.0f?dequantized:0.0f;
            if(activations[j]>maximum){maximum=activations[j];}
        }
        const float rowScale=maximum>0.0f?QmqScaleBy127Exact(maximum):1.0f;
        if(!(rowScale>0.0f)){return false;}
        ysLocal.SetValue(r,rowScale);
        for(uint32_t j=0;j<n;++j){
            const int32_t rounded=QmqTinyRoundExact(activations[j],rowScale);
            if(rounded<0){return false;}
            yLocal.SetValue(r*n+j,static_cast<int8_t>(rounded));
        }
    }
    PipeBarrier<PIPE_ALL>();
    DataCopyExtParams yc{1,rows*n,0,0,0},ysc{1,static_cast<uint32_t>(rows*sizeof(float)),0,0,0};
    DataCopyPad(yGm[static_cast<uint64_t>(rowStart)*n],yLocal,yc);
    DataCopyPad(ysGm[rowStart],ysLocal,ysc);
    PipeBarrier<PIPE_ALL>();
    return true;
}

'''
old='''        QmqComputeTinyC(x1, x2, workspace, m, n, k, localStart, localRows);
        quant_matmul_relu_quant_vector(workspace, x1Scale, x2Scale, y, yScale,
            m, n, localStart, localRows);'''
new='''        if (!QmqTryTinyDirect(x1, x2, x1Scale, x2Scale, y, yScale,
                             m, n, k, localStart, localRows)) {
            QmqComputeTinyC(x1, x2, workspace, m, n, k, localStart, localRows);
            quant_matmul_relu_quant_vector(workspace, x1Scale, x2Scale, y, yScale,
                m, n, localStart, localRows);
        }'''
assert base.count(old)==1
src=base.replace('__global__ __vector__ void qmq_tiny_vector_entry(',scale+helper+'__global__ __vector__ void qmq_tiny_vector_entry(',1).replace(old,new,1)
oldgate='k <= kQmqTinyMaxK && static_cast<uint64_t>(n) * k <= kQmqTinyMaxNK;'
newgate='k <= 128U && static_cast<uint64_t>(n) * k <= 1024U;'
assert src.count(oldgate)==1
src=src.replace(oldgate,newgate,1)
assert src.count('float x2Values[kQmqTinyMaxNK];')==1
src=src.replace('float x2Values[kQmqTinyMaxNK];','float x2Values[1024];',1)
assert src.replace('float x2Values[1024];','float x2Values[kQmqTinyMaxNK];',1).replace(newgate,oldgate,1).replace(new,old,1).replace(scale+helper,'',1)==base
out=root/'v72_tiny_direct';out.mkdir(exist_ok=True)
(out/'kernel.asc').write_bytes(src.replace('\n','\r\n').encode('utf-8'))
(out/'source_checks.json').write_text(json.dumps({'precision_functions_unchanged':True,'inverse_transform_exact':True,'max_dot_product':128*128*128,'tiny_shape_gate':'M<=96,N<=32,K<=128,N*K<=1024','runtime_launches':1,'fallback':'Original C computation and vector quantization for nonfinite activation or scale underflow','sha256':hashlib.sha256((out/'kernel.asc').read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print('Generated v72_tiny_direct')
